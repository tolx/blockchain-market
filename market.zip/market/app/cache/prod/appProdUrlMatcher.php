<?php

use Symfony\Component\Routing\Exception\MethodNotAllowedException;
use Symfony\Component\Routing\Exception\ResourceNotFoundException;
use Symfony\Component\Routing\RequestContext;

/**
 * appProdUrlMatcher.
 *
 * This class has been auto-generated
 * by the Symfony Routing Component.
 */
class appProdUrlMatcher extends Symfony\Bundle\FrameworkBundle\Routing\RedirectableUrlMatcher
{
    /**
     * Constructor.
     */
    public function __construct(RequestContext $context)
    {
        $this->context = $context;
    }

    public function match($pathinfo)
    {
        $allow = array();
        $pathinfo = rawurldecode($pathinfo);
        $context = $this->context;
        $request = $this->request;

        // _homepage
        if (rtrim($pathinfo, '/') === '') {
            if (substr($pathinfo, -1) !== '/') {
                return $this->redirect($pathinfo.'/', '_homepage');
            }

            return array (  '_controller' => 'Market\\DigitalBundle\\Controller\\DefaultController::indexAction',  '_route' => '_homepage',);
        }

        // indexFixed
        if ($pathinfo === '/indexFixed') {
            return array (  '_controller' => 'Market\\DigitalBundle\\Controller\\DefaultController::indexFixedAction',  '_route' => 'indexFixed',);
        }

        // menu
        if ($pathinfo === '/system/menu') {
            return array (  '_controller' => 'Market\\DigitalBundle\\Controller\\DefaultController::menuAction',  '_route' => 'menu',);
        }

        if (0 === strpos($pathinfo, '/oauth/sign_')) {
            // register
            if (0 === strpos($pathinfo, '/oauth/sign_up') && preg_match('#^/oauth/sign_up(?:/(?P<fb>[^/]++))?$#s', $pathinfo, $matches)) {
                return $this->mergeDefaults(array_replace($matches, array('_route' => 'register')), array (  '_controller' => 'Market\\DigitalBundle\\Controller\\UsersController::registerAction',  'fb' => 0,));
            }

            // _login
            if ($pathinfo === '/oauth/sign_in') {
                return array (  '_controller' => 'Market\\DigitalBundle\\Controller\\UsersController::loginAction',  '_route' => '_login',);
            }

            // _logout
            if ($pathinfo === '/oauth/sign_out') {
                return array (  '_controller' => 'Market\\DigitalBundle\\Controller\\UsersController::logoutAction',  '_route' => '_logout',);
            }

        }

        if (0 === strpos($pathinfo, '/user')) {
            // menuUser
            if ($pathinfo === '/user/userMenu') {
                return array (  '_controller' => 'Market\\DigitalBundle\\Controller\\UsersController::menuUserAction',  '_route' => 'menuUser',);
            }

            // _password
            if ($pathinfo === '/user/password') {
                return array (  '_controller' => 'Market\\DigitalBundle\\Controller\\UsersController::passwordAction',  '_route' => '_password',);
            }

            // menuAdmin
            if ($pathinfo === '/user/menuAdmin') {
                return array (  '_controller' => 'Market\\DigitalBundle\\Controller\\UsersController::menuAdminAction',  '_route' => 'menuAdmin',);
            }

        }

        if (0 === strpos($pathinfo, '/admin')) {
            if (0 === strpos($pathinfo, '/admin/categories')) {
                // _admin_categories
                if ($pathinfo === '/admin/categories') {
                    return array (  '_controller' => 'Market\\DigitalBundle\\Controller\\AdminController::categoriesIndexAction',  '_route' => '_admin_categories',);
                }

                // _admin_add_categories
                if ($pathinfo === '/admin/categories/add') {
                    return array (  '_controller' => 'Market\\DigitalBundle\\Controller\\AdminController::categoriesAddAction',  '_route' => '_admin_add_categories',);
                }

                // edit_categories
                if (0 === strpos($pathinfo, '/admin/categories/edit') && preg_match('#^/admin/categories/edit(?:\\-(?P<id>[^/]++))?$#s', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, array('_route' => 'edit_categories')), array (  '_controller' => 'Market\\DigitalBundle\\Controller\\AdminController::categoriesEditAction',  'id' => 0,));
                }

                // del_categories
                if (0 === strpos($pathinfo, '/admin/categories/del') && preg_match('#^/admin/categories/del(?:\\-(?P<id>[^/]++))?$#s', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, array('_route' => 'del_categories')), array (  '_controller' => 'Market\\DigitalBundle\\Controller\\AdminController::categoriesDeleteAction',  'id' => 0,));
                }

            }

            // newsletter
            if ($pathinfo === '/admin/newsletter') {
                return array (  '_controller' => 'Market\\DigitalBundle\\Controller\\AdminController::newsletterAction',  '_route' => 'newsletter',);
            }

            if (0 === strpos($pathinfo, '/admin/products')) {
                // _admin_products
                if ($pathinfo === '/admin/products') {
                    return array (  '_controller' => 'Market\\DigitalBundle\\Controller\\AdminController::productsIndexAction',  '_route' => '_admin_products',);
                }

                // edit_products
                if (0 === strpos($pathinfo, '/admin/products/edit') && preg_match('#^/admin/products/edit(?:\\-(?P<id>[^/]++))?$#s', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, array('_route' => 'edit_products')), array (  '_controller' => 'Market\\DigitalBundle\\Controller\\AdminController::productsEditAction',  'id' => 0,));
                }

            }

            if (0 === strpos($pathinfo, '/admin/users')) {
                // _admin_users
                if ($pathinfo === '/admin/users') {
                    return array (  '_controller' => 'Market\\DigitalBundle\\Controller\\AdminController::usersIndexAction',  '_route' => '_admin_users',);
                }

                // edit_users
                if (0 === strpos($pathinfo, '/admin/users/edit') && preg_match('#^/admin/users/edit(?:\\-(?P<id>[^/]++))?$#s', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, array('_route' => 'edit_users')), array (  '_controller' => 'Market\\DigitalBundle\\Controller\\AdminController::usersEditAction',  'id' => 0,));
                }

            }

            // _admin_homepage
            if ($pathinfo === '/admin/dashboard') {
                return array (  '_controller' => 'Market\\DigitalBundle\\Controller\\AdminController::indexAction',  '_route' => '_admin_homepage',);
            }

            if (0 === strpos($pathinfo, '/admin/help')) {
                // _admin_help
                if ($pathinfo === '/admin/help') {
                    return array (  '_controller' => 'Market\\DigitalBundle\\Controller\\AdminController::helpIndexAction',  '_route' => '_admin_help',);
                }

                // _admin_add_help
                if ($pathinfo === '/admin/help/add') {
                    return array (  '_controller' => 'Market\\DigitalBundle\\Controller\\AdminController::helpAddAction',  '_route' => '_admin_add_help',);
                }

                // edit_help
                if (0 === strpos($pathinfo, '/admin/help/edit') && preg_match('#^/admin/help/edit(?:\\-(?P<id>[^/]++))?$#s', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, array('_route' => 'edit_help')), array (  '_controller' => 'Market\\DigitalBundle\\Controller\\AdminController::helpEditAction',  'id' => 0,));
                }

                // del_help
                if (0 === strpos($pathinfo, '/admin/help/del') && preg_match('#^/admin/help/del(?:\\-(?P<id>[^/]++))?$#s', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, array('_route' => 'del_help')), array (  '_controller' => 'Market\\DigitalBundle\\Controller\\AdminController::helpDeleteAction',  'id' => 0,));
                }

            }

        }

        if (0 === strpos($pathinfo, '/user')) {
            if (0 === strpos($pathinfo, '/user/products')) {
                // _upload
                if ($pathinfo === '/user/products/new') {
                    return array (  '_controller' => 'Market\\DigitalBundle\\Controller\\UploadController::formAction',  '_route' => '_upload',);
                }

                // _edit_product
                if (0 === strpos($pathinfo, '/user/products/edit') && preg_match('#^/user/products/edit(?:\\-(?P<id>[^/]++))?$#s', $pathinfo, $matches)) {
                    return $this->mergeDefaults(array_replace($matches, array('_route' => '_edit_product')), array (  '_controller' => 'Market\\DigitalBundle\\Controller\\UploadController::formUpdateAction',  'id' => 0,));
                }

            }

            // _upload_file
            if ($pathinfo === '/user/upload_file') {
                return array (  '_controller' => 'Market\\DigitalBundle\\Controller\\UploadController::fileAction',  '_route' => '_upload_file',);
            }

            if (0 === strpos($pathinfo, '/user/p')) {
                // _user
                if ($pathinfo === '/user/profile') {
                    return array (  '_controller' => 'Market\\DigitalBundle\\Controller\\UsersController::profileAction',  '_route' => '_user',);
                }

                // _user_payment
                if ($pathinfo === '/user/payment') {
                    return array (  '_controller' => 'Market\\DigitalBundle\\Controller\\UsersController::paymentAction',  '_route' => '_user_payment',);
                }

            }

            // _user_email
            if ($pathinfo === '/user/email-template') {
                return array (  '_controller' => 'Market\\DigitalBundle\\Controller\\UsersController::emailAction',  '_route' => '_user_email',);
            }

        }

        // _view_products
        if (0 === strpos($pathinfo, '/item') && preg_match('#^/item/(?P<id>[^/\\-]++)\\-(?P<title>[^/\\.]++)\\.html$#s', $pathinfo, $matches)) {
            return $this->mergeDefaults(array_replace($matches, array('_route' => '_view_products')), array (  '_controller' => 'Market\\DigitalBundle\\Controller\\ProductsController::productsAction',  'id' => 0,  'title' => NULL,));
        }

        // _footer
        if ($pathinfo === '/admin/footer') {
            return array (  '_controller' => 'Market\\DigitalBundle\\Controller\\InitController::footerAction',  '_route' => '_footer',);
        }

        // _ipn
        if ($pathinfo === '/system/ipn') {
            return array (  '_controller' => 'Market\\DigitalBundle\\Controller\\IpnController::ipnAction',  '_route' => '_ipn',);
        }

        if (0 === strpos($pathinfo, '/user')) {
            // _purchases
            if ($pathinfo === '/user/purchases') {
                return array (  '_controller' => 'Market\\DigitalBundle\\Controller\\ProductsController::purchasesAction',  '_route' => '_purchases',);
            }

            // _download
            if (0 === strpos($pathinfo, '/user/download') && preg_match('#^/user/download/(?P<id>[^/]+)d(?P<title>[^/\\.]++)\\.html$#s', $pathinfo, $matches)) {
                return $this->mergeDefaults(array_replace($matches, array('_route' => '_download')), array (  '_controller' => 'Market\\DigitalBundle\\Controller\\ProductsController::getFileAction',  'id' => 0,  'title' => NULL,));
            }

            // _sales
            if ($pathinfo === '/user/products') {
                return array (  '_controller' => 'Market\\DigitalBundle\\Controller\\ProductsController::myProductsAction',  '_route' => '_sales',);
            }

            // _upload_image
            if ($pathinfo === '/user/upload_image') {
                return array (  '_controller' => 'Market\\DigitalBundle\\Controller\\UploadController::imageAction',  '_route' => '_upload_image',);
            }

        }

        // _view_categories
        if (0 === strpos($pathinfo, '/category') && preg_match('#^/category/(?P<id>[^/\\-]++)\\-(?P<title>[^/\\.]++)\\.html$#s', $pathinfo, $matches)) {
            return $this->mergeDefaults(array_replace($matches, array('_route' => '_view_categories')), array (  '_controller' => 'Market\\DigitalBundle\\Controller\\CategoriesController::listProductsAction',  'id' => 0,  'title' => NULL,));
        }

        // _view_author
        if (preg_match('#^/(?P<title>[^/]++)?$#s', $pathinfo, $matches)) {
            return $this->mergeDefaults(array_replace($matches, array('_route' => '_view_author')), array (  '_controller' => 'Market\\DigitalBundle\\Controller\\CategoriesController::authorProductsAction',  'title' => NULL,));
        }

        // _view_search
        if ($pathinfo === '/products/search') {
            return array (  '_controller' => 'Market\\DigitalBundle\\Controller\\CategoriesController::searchAction',  '_route' => '_view_search',);
        }

        // _view_system
        if (0 === strpos($pathinfo, '/systems') && preg_match('#^/systems(?:/(?P<title>[^/]++))?$#s', $pathinfo, $matches)) {
            return $this->mergeDefaults(array_replace($matches, array('_route' => '_view_system')), array (  '_controller' => 'Market\\DigitalBundle\\Controller\\InitController::systemAction',  'title' => NULL,));
        }

        throw 0 < count($allow) ? new MethodNotAllowedException(array_unique($allow)) : new ResourceNotFoundException();
    }
}
