<?php

namespace Market\DigitalBundle\Controller;

use Symfony\Component\HttpFoundation\Request;
use Market\DigitalBundle\Entity\Products;
use Market\DigitalBundle\MarketDigitalBundle as MiniLib;

class UploadController extends BaseController {

    public function formUpdateAction(Request $request, $id = 0) {
        $em = $this->getDoctrine()->getManager();
        $session = $request->getSession();

        $session->set("userMenu", "_upload");

        $username = $session->get('username', "");
        $password = $session->get('password', "");

        $tmp = dirname(dirname(dirname(dirname(dirname(__FILE__))))) . "/web";

        $checkUser = $em->getRepository('MarketDigitalBundle:Users')->findOneBy(array("email" => $username, "password" => $password));
        if (!$checkUser) {
            $session->clear();
            return $this->redirect($this->generateUrl("_homepage"));
        }

        $products = $em->getRepository('MarketDigitalBundle:Products')->findOneBy(array("id" => $id));
        if (!$products) {
            return $this->redirect($this->generateUrl("_sales"));
        }
        if ($products->getUId() != $checkUser->getId()) {
            return $this->redirect($this->generateUrl("_sales"));
        }

        $targetFolder = $tmp . '/uploads/tmp/' . $checkUser->getId() . "/";

        $category1 = $em->getRepository('MarketDigitalBundle:Categories')->findBy(array("active" => 1));

        $error = 0;

        $uploadFail = array();

        $fileUpload = $session->get('fileUpload', array());

        if ($request->getMethod() == 'POST') {

            $title = $request->request->get("title", "");
            $details = $request->request->get("details", "");
            //$preview = $request->request->get("heroImage", "");
            //$main_file = $request->request->get("mainFile", "");
            $category = (int) $request->request->get("category", 0);
            $active = (int) $request->request->get("active", 0);
            $videoUrl = $request->request->get("video_url", "");

            $mFile = $products->getMainFile();
            $mPreview = $products->getImage();
            $mCid = $products->getCId();

            $price = round(floatval($request->request->get("price", 0)), 2, PHP_ROUND_HALF_DOWN);
            if ($price < 0) {
                $price = 0;
            }

            if ($preview != $mPreview) {
                if (preg_match("/png/i", $targetFolder . $preview)) {
                    $size = getimagesize($targetFolder . $preview);
                    if ($size[0] != 750 || $size[1] != 500) {
                        $uploadFail[0] = 1;
                    }
                } else {
                    $uploadFail[0] = 0;
                }
            }

            if ($main_file != $mFile) {
                if (preg_match("/zip/i", $targetFolder . $main_file)) {
                    $sizeUpload = (int) $this->container->getParameter('maxMain');
                    $size = @filesize($targetFolder . $main_file) / (1024 * 1024);
                    if ($size > $sizeUpload) {
                        $uploadFail[1] = 1;
                    }
                } else {
                    $uploadFail[1] = 0;
                }
            }

            $checkCid = $em->getRepository('MarketDigitalBundle:Categories')->findOneBy(array("id" => $category));

            if ($title && $details &&  $category && $price && $checkCid) {
                if (count($uploadFail) == 0) {
                    try {

                        $products->setTitle($title)->setDetails($details);
                        $products->setCategories($checkCid);
                        $products->setCId($category);
                        $products->setActive($active);

                        if ($preview && $mPreview != $preview) {
                            $products->setImage($preview);
                        }

                        $products->setPreview($videoUrl);

                        if ($main_file && $mFile != $main_file) {
                            $products->setMainFile($main_file);
                        }

                        $products->setTags("");
                        $products->setPrice($price);

                        $em->persist($products);


                        $path = dirname(dirname(dirname(dirname(dirname(__FILE__)))));
                        $tmp = $path . "/web/uploads/tmp/" . $checkUser->getId() . "/";
                        $disImg = $path . "/web/uploads/items/";
                        $disFile = $path . "/items/";

                        if ($preview && $mPreview != $preview) {
                            @copy($tmp . $preview, $disImg . $preview);
                            @unlink($tmp . $preview);
                            @unlink($disImg . $mPreview);
                        }

                        if ($main_file && $mFile != $main_file) {
                            @copy($tmp . $main_file, $disFile . $main_file);
                            @unlink($tmp . $main_file);
                            @unlink($disFile . $mFile);
                        }

                        $em->flush();

                        $em->getRepository('MarketDigitalBundle:Categories')->updateCategories('c.total', $mCid, -1);

                        $em->getRepository('MarketDigitalBundle:Categories')->updateCategories('c.total', $category);


                        $session->set('done', 1);
                        $session->remove("fileUpload");
                        return $this->redirect($this->generateUrl("_sales"));
                    } catch (Exception $ex) {
                        $error = 1;
                    }
                } else {
                    $error = 1;
                }
            } else {
                $error = 1;
            }
        }

        $arrReturn = array(
            'category' => $category1,
            "error" => $error,
            'uploadFail' => $uploadFail,
            'fileUpload' => $fileUpload,
            "product" => $products
        );
        return $this->render('MarketDigitalBundle:Upload:form.html.php', $arrReturn);
    }

    public function formAction(Request $request) {
        $em = $this->getDoctrine()->getManager();
        $session = $request->getSession();

        $session->set("userMenu", "_upload");

        $username = $session->get('username', "");
        $password = $session->get('password', "");

        $tmp = dirname(dirname(dirname(dirname(dirname(__FILE__))))) . "/web";

        $checkUser = $em->getRepository('MarketDigitalBundle:Users')->findOneBy(array("email" => $username, "password" => $password));
        if (!$checkUser) {
            $session->clear();
            return $this->redirect($this->generateUrl("_homepage"));
        }

        $targetFolder = $tmp . '/uploads/tmp/' . $checkUser->getId() . "/";

        $category1 = $em->getRepository('MarketDigitalBundle:Categories')->findBy(array("active" => 1));

        $error = 0;

        $uploadFail = array();

        $fileUpload = $session->get('fileUpload', array());

        if ($request->getMethod() == 'POST') {

            $title = $request->request->get("title", "");
            $details = $request->request->get("details", "");
            //$preview = $request->request->get("heroImage", "");
            //$main_file = $request->request->get("mainFile", "");
            //$category = (int) $request->request->get("category", 0);
            $active = (int) $request->request->get("active", 0);
            $videoUrl = $request->request->get("video_url", "");


            $price = floatval($request->request->get("price", 0));
            if ($price < 0) {
                $price = 0;
            }
            $price = round($price, 2, PHP_ROUND_HALF_DOWN);

            if (preg_match("/png/i", $targetFolder . $preview)) {
                $size = getimagesize($targetFolder . $preview);
                if ($size[0] != 750 || $size[1] != 500) {
                    $uploadFail[0] = 1;
                }
            } else {
                $uploadFail[0] = 1;
            }

            if (preg_match("/zip/i", $targetFolder . $main_file)) {
                $sizeUpload = (int) $this->container->getParameter('maxMain');
                $size = @filesize($targetFolder . $main_file) / (1024 * 1024);
                if ($size > $sizeUpload) {
                    $uploadFail[1] = 1;
                }
            } else {
                $uploadFail[1] = 1;
            }

            $checkCid = $em->getRepository('MarketDigitalBundle:Categories')->findOneBy(array("id" => $category));

            if ($title && $details && $preview && $main_file && $category && $price && $checkCid) {
                if (count($uploadFail) == 0) {
                    try {
                        $newProduct = new Products();
                        $newProduct->setTitle($title)->setDetails($details);
                        $newProduct->setCategories($checkCid);
                        $newProduct->setCId($category);
                        $newProduct->setActive($active);
                        $newProduct->setImage($preview);
                        $newProduct->setPreview($videoUrl);
                        $newProduct->setFeature(0);
                        $newProduct->setTrend(0);
                        $newProduct->setUsers($checkUser);
                        $newProduct->setViews(0);
                        $newProduct->setUId($checkUser->getId());
                        $newProduct->setMainFile($main_file);
                        $newProduct->setTags("");
                        $newProduct->setPrice($price);
                        $newProduct->setPricePlus(0);
                        $newProduct->setTotalRate(0)->setTotalSale(0);
                        $newProduct->setTotalComment(0)->setAverageRate(0);
                        $newProduct->setViews(0);
                        $a = new \Datetime();
                        $newProduct->setCreatedAt($a);
                        $newProduct->setUpdatedAt($a);

                        $em->persist($newProduct);



                        $path = dirname(dirname(dirname(dirname(dirname(__FILE__)))));
                        $tmp = $path . "/web/uploads/tmp/" . $checkUser->getId() . "/";
                        $disImg = $path . "/web/uploads/items/";
                        $disFile = $path . "/items/";

                        if ($preview) {
                            @copy($tmp . $preview, $disImg . $preview);
                            @unlink($tmp . $preview);
                        }

                        if ($main_file) {
                            @copy($tmp . $main_file, $disFile . $main_file);
                            @unlink($tmp . $main_file);
                        }

                        $em->getRepository('MarketDigitalBundle:Categories')->updateCategories('c.total', $category);

                        $em->getRepository('MarketDigitalBundle:Users')->updateUsers('c.total_file', $checkUser->getId());

                        
                        $mDate = date("m");
                        $yDate = date("Y");
                        $dDate = date("d");
                        $report = $em->getRepository('MarketDigitalBundle:Reports')->findOneBy(array("date_report" => $dDate, "month_report" => $mDate, "year_report" => $yDate));
                        if ($report) {
                            $em->getRepository('MarketDigitalBundle:Reports')->updateReport('c.products', 1, $report->getId());
                        } else {
                            $report = new \Market\DigitalBundle\Entity\Reports();
                            $report->setDateReport($dDate)
                                    ->setMonthReport($mDate)
                                    ->setYearReport($yDate)
                                    ->setOthers("")
                                    ->setPaid(0)
                                    ->setProducts(1)
                                    ->setRevenues(0)
                                    ->setSales(0)
                                    ->setUsers(0);
                            $em->persist($report);
                        }


                        $em->flush();
                        $session->set('done', 1);
                        $session->remove("fileUpload");
                        return $this->redirect($this->generateUrl("_sales"));
                    } catch (Exception $ex) {
                        $error = 1;
                    }
                } else {
                    $error = 1;
                }
            } else {
                $error = 1;
            }
        }

        $arrReturn = array(
            'category' => $category1,
            "error" => $error,
            'uploadFail' => $uploadFail,
            'fileUpload' => $fileUpload,
            "product" => ''
        );
        return $this->render('MarketDigitalBundle:Upload:form.html.php', $arrReturn);
    }

    public function fileAction(Request $request) {

        $em = $this->getDoctrine()->getManager();
        $session = $request->getSession();

        $username = $session->get('username', "");
        $password = $session->get('password', "");

        $name = time();
        $folder = 0;

        $str = MiniLib::genString();

        $checkUser = $em->getRepository('MarketDigitalBundle:Users')->findOneBy(array("email" => $username, "password" => $password));
        if ($checkUser) {
            $name .= $str . $checkUser->getId();
            $folder = $checkUser->getId();
        }

        $tmp = dirname(dirname(dirname(dirname(dirname(__FILE__))))) . "/web";

        $targetFolder = $tmp . '/uploads/tmp/' . $folder . "/";

        if (!file_exists($targetFolder)) {
            @mkdir($targetFolder, 0777);
        }

        $fileUpload = $session->get('fileUpload', array());

        if (!empty($_FILES)) {
            if (preg_match("/png/i", $_FILES["files"]["type"][0])) {

                $arrType = array("image/png");
                $allowedExts = array("png");
                $maxWidth = array(750);
                $maxHeight = array(500);

                $size = getimagesize($_FILES["files"]['tmp_name'][0]);
                if (!in_array($_FILES["files"]["type"][0], $arrType)) {
                    echo json_encode(array('files' => array(array("error" => 1, "name" => "", 'hash' => "", 'message' => $this->get('translator')->trans('Invalid type')))));
                } else if (!in_array($size[0], $maxWidth) || !in_array($size[1], $maxHeight)) {
                    echo json_encode(array('files' => array(array("error" => 1, "name" => "", 'hash' => "", 'message' => $this->get('translator')->trans('Invalid size!')))));
                } else {

                    if ($_FILES["files"]["error"][0] == UPLOAD_ERR_OK) {
                        $extension = strtolower(pathinfo($_FILES['files']['name'][0], PATHINFO_EXTENSION));
                        if (in_array($extension, $allowedExts)) {
                            move_uploaded_file($_FILES["files"]["tmp_name"][0], $targetFolder . $name . "." . $extension);

                            $fileUpload[$name . "." . $extension] = $_FILES['files']['name'][0];
                            $session->set('fileUpload', $fileUpload);

                            echo json_encode(array('files' => array(array("error" => 0, "name" => $_FILES['files']['name'][0], 'hash' => $name . "." . $extension, 'message' => $this->get('translator')->trans('Successfully')))));
                        } else {
                            echo json_encode(array('files' => array(array("error" => 1, "name" => "", 'hash' => "", 'message' => $this->get('translator')->trans('Invalid type')))));
                        }
                    } else {
                        echo json_encode(array('files' => array(array("error" => 1, "name" => "", 'hash' => "", 'message' => $this->get('translator')->trans('Error!')))));
                    }
                }
                die;
            }

            if (preg_match("/zip/i", $_FILES["files"]["type"][0]) || preg_match("/octet-stream/i", $_FILES["files"]["type"][0])) {
                $arrType =array( "application/x-zip",  "application/zip",  "application/octet-stream", "application/x-zip-compressed", "application/zip-compressed");
                $allowedExts = array("zip");
                $sizeUpload = (int) $this->container->getParameter('maxMain');

                $size = round($_FILES["files"]['size'][0] / (1024 * 1024));
                // if (!in_array($_FILES["files"]["type"][0], $arrType)) {
                //     echo json_encode(array('files' => array(array("error" => 1, "name" => "", 'hash' => "", 'message' => $this->get('translator')->trans('Invalid type')))));
                // } else 
                if ($size > $sizeUpload) {
                    echo json_encode(array('files' => array(array("error" => 1, "name" => "", 'hash' => "", 'message' => $this->get('translator')->trans('Over size!')))));
                } else {
                    if ($_FILES["files"]["error"][0] == UPLOAD_ERR_OK) {
                        $extension = strtolower(pathinfo($_FILES['files']['name'][0], PATHINFO_EXTENSION));
                        if (in_array($extension, $allowedExts)) {
                            move_uploaded_file($_FILES["files"]["tmp_name"][0], $targetFolder . $name . "." . $extension);

                            $fileUpload[$name . "." . $extension] = $_FILES['files']['name'][0];
                            $session->set('fileUpload', $fileUpload);

                            echo json_encode(array('files' => array(array("error" => 0, "name" => $_FILES['files']['name'][0], 'hash' => $name . "." . $extension, 'message' => $this->get('translator')->trans('Successfully')))));
                        } else {
                            echo json_encode(array('files' => array(array("error" => 1, "name" => "", 'hash' => "", 'message' => $this->get('translator')->trans('Invalid type')))));
                        }
                    } else {
                        echo json_encode(array('files' => array(array("error" => 1, "name" => "", 'hash' => "", 'message' => $this->get('translator')->trans('Error!')))));
                    }
                }
                die;
            }

            echo json_encode(array('files' => array(array("error" => 1, "name" => "", 'hash' => "", 'message' => $this->get('translator')->trans('Upload error!')))));
            die;
        } else {
            echo json_encode(array('files' => array(array("error" => 1, "name" => "", 'hash' => "", 'message' => $this->get('translator')->trans('Upload error! Refresh and try again')))));
        }

        die;
    }

    public function imageAction(Request $request) {

        $em = $this->getDoctrine()->getManager();
        $session = $request->getSession();

        $username = $session->get('username', "");
        $password = $session->get('password', "");

        $name = time();

        $str = MiniLib::genString();

        $jSon = array("error" => 1, "name" => "", "hash" => "", "message" => $this->get('translator')->trans('Have an error. Please try again'));

        $checkUser = $em->getRepository('MarketDigitalBundle:Users')->findOneBy(array("email" => $username, "password" => $password));
        if ($checkUser) {
            $name .= $str . $checkUser->getId();
        } else {
            $jSon["message"] = $this->get('translator')->trans('Please, Login to your account.');
            echo json_encode($jSon);
            die;
        }

        $forID = $session->get("admin_edit_user", 0);
        if ($forID) {
            $name = time() . $str . $forID;
        }

        $tmp = dirname(dirname(dirname(dirname(dirname(__FILE__))))) . "/web";

        $targetFolder = $tmp . '/uploads/avatar/';

        if (!empty($_FILES)) {
            if (preg_match("/png/i", $_FILES["files"]["type"][0])) {

                $arrType = array("image/png");
                $allowedExts = array("png");

                $maxWidthAvatar = array(114, 1920);
                $maxHeightAvatar = array(114, 200);

                $size = getimagesize($_FILES["files"]['tmp_name'][0]);
                if (!in_array($_FILES["files"]["type"][0], $arrType)) {

                    echo json_encode(array('files' => array(array("type" => 0, "error" => 1, "name" => "", 'hash' => "", 'message' => $this->get('translator')->trans('Invalid type')))));
                } else if (!in_array($size[0], $maxWidthAvatar) || !in_array($size[1], $maxHeightAvatar)) {
                    echo json_encode(array('files' => array(array("type" => 0, "error" => 1, "name" => "", 'hash' => "", 'message' => $this->get('translator')->trans('Invalid size!')))));
                } else {

                    if ($_FILES["files"]["error"][0] == UPLOAD_ERR_OK) {
                        $extension = strtolower(pathinfo($_FILES['files']['name'][0], PATHINFO_EXTENSION));
                        if (in_array($extension, $allowedExts)) {

                            $str = MiniLib::genString();

                            if ($size[0] == $maxWidthAvatar[0]) {
                                $name = "avatar" . $str . $name;
                                $text = $this->get('translator')->trans('Successfully upload Avatar.');
                            } else {
                                $name = "cover" . $str . $name;
                                $text = $this->get('translator')->trans('Successfully upload Page cover.');
                            }

                            move_uploaded_file($_FILES["files"]["tmp_name"][0], $targetFolder . $name . "." . $extension);

                            $url = $this->generateUrl('_homepage', array(), true) . "uploads/avatar/" . $name . "." . $extension;
                            if ($size[0] == $maxWidthAvatar[0]) {
                                if ($checkUser->getAvatar()) {
                                    $tmp = explode("/", $checkUser->getAvatar());
                                    @unlink($targetFolder . $tmp[count($tmp) - 1]);
                                }

                                if ($forID) {
                                    $checkUserId = $em->getRepository('MarketDigitalBundle:Users')->findOneBy(array("id" => $forID));
                                    $checkUserId->setAvatar($url);
                                    $em->persist($checkUserId);
                                    $em->flush();
                                } else {
                                    $checkUser->setAvatar($url);
                                    $em->persist($checkUser);
                                    $em->flush();
                                }
                                $type = 1;
                            } else {
                                if ($forID) {
                                    $checkUserId = $em->getRepository('MarketDigitalBundle:Users')->findOneBy(array("id" => $forID));
                                    if ($checkUserId->getCover()) {
                                        $tmp = explode("/", $checkUserId->getCover());
                                        @unlink($targetFolder . $tmp[count($tmp) - 1]);
                                    }
                                    $checkUserId->setCover($url);
                                    $em->persist($checkUserId);
                                    $em->flush();
                                } else {
                                    if ($checkUser->getCover()) {
                                        $tmp = explode("/", $checkUser->getCover());
                                        @unlink($targetFolder . $tmp[count($tmp) - 1]);
                                    }
                                    $checkUser->setCover($url);
                                    $em->persist($checkUser);
                                    $em->flush();
                                }
                                $type = 2;
                            }

                            echo json_encode(array('files' => array(array("type" => $type, "error" => 0, "name" => $url, 'hash' => $url, 'message' => $text))));
                        } else {
                            echo json_encode(array('files' => array(array("type" => 0, "error" => 1, "name" => "", 'hash' => "", 'message' => $this->get('translator')->trans('Invalid type')))));
                        }
                    } else {
                        echo json_encode(array('files' => array(array("type" => 0, "error" => 1, "name" => "", 'hash' => "", 'message' => $this->get('translator')->trans('Error! Please try again')))));
                    }
                }
                die;
            }

            echo json_encode(array('files' => array(array("type" => 0, "error" => 1, "name" => "", 'hash' => "", 'message' => $this->get('translator')->trans('Upload error!')))));
            die;
        } else {
            echo json_encode(array('files' => array(array("type" => 0, "error" => 1, "name" => "", 'hash' => "", 'message' => $this->get('translator')->trans('Upload error! Refresh and try again')))));
        }

        die;
    }

}
