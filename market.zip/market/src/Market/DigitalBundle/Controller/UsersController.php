<?php

namespace Market\DigitalBundle\Controller;

use Symfony\Component\HttpFoundation\Request;
use Market\DigitalBundle\Entity\Users;
use Market\DigitalBundle\Entity\NewsLetters;
use Market\DigitalBundle\Entity\Affiliate;
use Market\DigitalBundle\Entity\Notifications;
use Facebook\Facebook;
use Market\DigitalBundle\MarketDigitalBundle as MiniLib;

class UsersController extends BaseController {

    public function registerAction(Request $request, $fb = 0) {
        $em = $this->em;

        $session = $request->getSession();
        $username = $session->get('username', "");
        $password = $session->get('password', "");
        $checkw = $em->getRepository('MarketDigitalBundle:Users')->findOneBy(array("email" => $username, "password" => $password));
        if ($checkw) {
            return $this->redirect($this->generateUrl("_user"));
        }

        $error = null;
        $check = '';
        $checkName = '';

        $password = "";
        $email = "";
        $user_name = "";
        $name = "";
        $token = "";
        $avatar = "";

        if ($request->getMethod() == 'POST' || $fb) {
            if ($fb) {
                $userNode = '';
                $longLivedAccessToken = '';
                $fbApp = new Facebook(array('app_id' => MiniLib::$fb_app, 'app_secret' => MiniLib::$fb_key));
                $helper = $fbApp->getRedirectLoginHelper();
                try {
                    $accessToken = $helper->getAccessToken();
                    // OAuth 2.0 client handler
                    $oAuth2Client = $fbApp->getOAuth2Client();
                    // Exchanges a short-lived access token for a long-lived one
                    $longLivedAccessToken = $oAuth2Client->getLongLivedAccessToken($accessToken);
                } catch (Facebook\Exceptions\FacebookResponseException $e) {
                    return $this->redirect($this->generateUrl("_homepage"));
                } catch (Facebook\Exceptions\FacebookSDKException $e) {
                    return $this->redirect($this->generateUrl("_homepage"));
                }
                if ($longLivedAccessToken) {
                    $fbApp->setDefaultAccessToken((string) $longLivedAccessToken);
                    try {
                        $response = $fbApp->get('/me?fields=id,name,email');
                        $userNode = $response->getGraphUser()->asJson();
                    } catch (Facebook\Exceptions\FacebookResponseException $e) {
                        return $this->redirect($this->generateUrl("_homepage"));
                    } catch (Facebook\Exceptions\FacebookSDKException $e) {
                        return $this->redirect($this->generateUrl("_homepage"));
                    }
                    if ($userNode) {
                        $userNode = json_decode($userNode, true);

                        $password = $userNode["id"];
                        $email = $userNode["email"];
                        $user_name = $userNode["id"];
                        $name = $userNode["name"];
                        $avatar = "//graph.facebook.com/" . $user_name . "/picture?type=large";
                        $token = (string) $longLivedAccessToken;

                        $checkw = $em->getRepository('MarketDigitalBundle:Users')->findOneBy(array("username" => $user_name));
                        if ($checkw) {
                            $session->set('username', $checkw->getEmail());
                            $session->set('password', $checkw->getPassword());
                            return $this->redirect($this->generateUrl("_user"));
                        }
                    }
                }
            } else {
                $password = $request->request->get("password", "");
                $email = $request->request->get("email", "");
                $user_name = $request->request->get("username", "");
            }

            $bannedWords = $this->container->getParameter('bannedWords');
            $minCharacter = (int) $this->container->getParameter('minCharacter');

            if (!empty($user_name) && !empty($password) && filter_var($email, FILTER_VALIDATE_EMAIL) && !in_array($user_name, $bannedWords) && strlen($user_name) >= $minCharacter) {
                $check = $em->getRepository('MarketDigitalBundle:Users')->findOneByEmail($email);
                $checkName = $em->getRepository('MarketDigitalBundle:Users')->findOneByUsername($user_name);
                if (!$check && !$checkName) {
                    $a = new \Datetime();
                    $new_user = new Users();
                    $new_user->setActive(1);
                    $new_user->setAdd1("")->setAvatar($avatar)
                            ->setBio("")->setCity("")
                            ->setCountry("")
                            ->setCover("")
                            ->setEarned(0)
                            ->setEmailBaokim('')
                            ->setEmailNganluong("")
                            ->setEmailPaypal("")
                            ->setFacebook("")
                            ->setFullname($name)
                            ->setHomepage("")
                            ->setSaled(0)
                            ->setTokenFacebook($token)
                            ->setSupper(0)
                            ->setTotalFile(0)
                            ->setTwitter("")
                            ->setUsername($user_name)
                            ->setEmailSubject($this->get('translator')->trans('Thanks for purchase!'))
                            ->setEmailContent($this->get('translator')->trans('You can download your product file here:'));

                    $new_user->setPassword(md5(sha1($password)));
                    $new_user->setEmail($email);
                    $new_user->setCreatedAt($a);
                    $new_user->setUpdatedAt($a);

                    $newL = $this->em->getRepository('MarketDigitalBundle:NewsLetters')->findOneByEmail($email);
                    if ($newL) {
                        $newL->setActive(1);
                    } else {
                        $newL = new NewsLetters();
                        $newL->setEmail($email);
                        $newL->setActive(1);
                    }
                    $this->em->persist($newL);
                    $this->em->persist($new_user);

                    $content = $this->get('translator')->trans('Hi') . ' ' . $user_name . ',<br>' .
                            $this->get('translator')->trans('Thank you for joining Marketplace, we hope you will contribute and get rewarded handsomely!') . '<br>' .
                            $this->get('translator')->trans('If you have any question, please do not hesitate to contact us.') . '<br><br>' .
                            $this->get('translator')->trans('Marketplace.Com') . '<br>' .
                            $this->generateUrl("_homepage", array(), true);

                    $sub = $this->get('translator')->trans('Welcome to Marketplace.Com');

                    $noti = new Notifications();
                    $noti->setEmail($email);
                    $noti->setReplyEmail('');
                    $noti->setTitle($sub);
                    $noti->setContent($content);
                    $this->em->persist($noti);

                    //Add Ref
                    if ($ref = $session->get('ref', "")) {
                        $newRef = $this->em->getRepository('MarketDigitalBundle:Users')->findOneByUsername($ref);
                        if ($newRef && $new_user) {
                            $refAdd = new Affiliate();
                            $refAdd->setUserId($new_user->getId());
                            $refAdd->setRefId($newRef->getId());
                            $refAdd->setStatus(0);
                            $this->em->persist($refAdd);
                        }
                    }

                    $mDate = date("m");
                    $yDate = date("Y");
                    $dDate = date("d");
                    $report = $em->getRepository('MarketDigitalBundle:Reports')->findOneBy(array("date_report" => $dDate, "month_report" => $mDate, "year_report" => $yDate));
                    if ($report) {
                        $em->getRepository('MarketDigitalBundle:Reports')->updateReport('c.users', 1, $report->getId());
                    } else {
                        $report = new \Market\DigitalBundle\Entity\Reports();
                        $report->setDateReport($dDate)
                                ->setMonthReport($mDate)
                                ->setYearReport($yDate)
                                ->setOthers("")
                                ->setPaid(0)
                                ->setProducts(0)
                                ->setRevenues(0)
                                ->setSales(0)
                                ->setUsers(1);
                        $this->em->persist($report);
                    }

                    $this->em->flush();
                    $session->set('username', $email);
                    $session->set('password', md5(sha1($password)));

                    return $this->redirect($this->generateUrl("_user"));
                }
            } else {
                if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
                    $session->set('notice', $this->get('translator')->trans('You enter invalid Email.'));
                } elseif (strlen($user_name) < $minCharacter) {
                    $session->set('notice', $this->get('translator')->trans('Username min 6 characters.'));
                } elseif (empty($password)) {
                    $session->set('notice', $this->get('translator')->trans('Password can not empty.'));
                } elseif (empty($user_name)) {
                    $session->set('notice', $this->get('translator')->trans('Username can not empty.'));
                } elseif (in_array($user_name, $bannedWords)) {
                    $session->set('notice', $this->get('translator')->trans('Can Not use this Username.'));
                }
            }
        }
        return $this->redirect($this->generateUrl("_homepage"));
    }

    public function loginAction(Request $request) {
        $em = $this->em;
        $session = $request->getSession();
        $username = $session->get('username', "");
        $password = $session->get('password', "");
        $checkw = $em->getRepository('MarketDigitalBundle:Users')->findOneBy(array("email" => $username, "password" => $password));
        if ($checkw) {
            return $this->redirect($this->generateUrl("_user"));
        }

        if ($request->getMethod() == 'POST') {
            $password = $request->request->get("password", "");
            $user_name = $request->request->get("username", "");
            if (!empty($user_name) && !empty($password)) {
                $check = $em->getRepository('MarketDigitalBundle:Users')->findOneBy(array("email" => $user_name, "password" => md5(sha1($password))));
                if ($check) {
                    $session->set('username', $check->getEmail());
                    $session->set('password', md5(sha1($password)));
                    return $this->redirect($this->generateUrl("_user"));
                }
            }
        }
        return $this->redirect($this->generateUrl("_homepage"));
    }

    public function logoutAction(Request $request) {
        $session = $request->getSession();
        $session->clear();
        return $this->redirect($this->generateUrl("_homepage"));
    }

    public function menuUserAction(Request $request) {
        $session = $request->getSession();
        $userMenu = $session->get('userMenu', "");

        return $this->render('MarketDigitalBundle:Users:menu.html.php', array('userMenu' => $userMenu));
    }

    public function menuAdminAction(Request $request) {
        $session = $request->getSession();
        $menuAdmin = $session->get('dashboard', "");

        return $this->render('MarketDigitalBundle:Users:menuAdmin.html.php', array('userMenu' => $menuAdmin));
    }

    public function passwordAction(Request $request) {
        $session = $request->getSession();
        $userMenu = $session->set('userMenu', "password");
        $error = 0;

        $check = $this->em->getRepository('MarketDigitalBundle:Users')->findOneBy(array("email" => $this->username, "password" => $this->password));
        if (!$check) {
            $session = $request->getSession();
            $session->clear();
            return $this->redirect($this->generateUrl("_homepage"));
        }

        if ($request->getMethod() == 'POST') {
            $oldpass = $request->request->get("oldpass", "");
            $newpass = $request->request->get("newpass", "");
            $renewpass = $request->request->get("renewpass", "");
            if (!empty($newpass) && $newpass == $renewpass && md5(sha1($oldpass)) == $check->getPassword()) {
                $error = 1;
                $check->setPassword(md5(sha1($newpass)));
                $this->em->persist($check);
                $this->em->flush();
            } else {
                $error = 2;
            }
        }

        return $this->render('MarketDigitalBundle:Users:password.html.php', array('error' => $error, 'userMenu' => $userMenu));
    }

    public function profileAction(Request $request) {
        $session = $request->getSession();
        $userMenu = $session->set('userMenu', "profile");

        $check = $this->em->getRepository('MarketDigitalBundle:Users')->findOneBy(array("email" => $this->username, "password" => $this->password));
        if (!$check) {
            $session->clear();
            return $this->redirect($this->generateUrl("_homepage"));
        }

        if ($request->getMethod() == 'POST') {
            $name = $request->request->get("name", "");
            if ($name) {
                $check->setFullName($name);
            }

            $Bio = $request->request->get("bio", "");
            $check->setBio($Bio);

            $add = $request->request->get("add", "");
            $check->setAdd1($add);

            $country = $request->request->get("country", "");
            $check->setCountry($country);

            $city = $request->request->get("city", "");
            $check->setCity($city);

            $facebook = $request->request->get("facebook", "");
            $check->setFacebook($facebook);

            $twitter = $request->request->get("twitter", "");
            $check->setTwitter($twitter);

            $homepage = $request->request->get("homepage", "");
            $check->setHomepage($homepage);


            $this->em->persist($check);
            $this->em->flush();
        }

        return $this->render('MarketDigitalBundle:Users:profile.html.php', array('userMenu' => $userMenu, 'info' => $check));
    }

    public function paymentAction(Request $request) {
        $session = $request->getSession();
        $userMenu = $session->set('userMenu', "_user_payment");

        $check = $this->em->getRepository('MarketDigitalBundle:Users')->findOneBy(array("email" => $this->username, "password" => $this->password));
        if (!$check) {
            $session = $request->getSession();
            $session->clear();
            return $this->redirect($this->generateUrl("_homepage"));
        }

        if ($request->getMethod() == 'POST') {
            $Bio = $request->request->get("paypal", "");
            $check->setEmailPaypal($Bio);

            $this->em->persist($check);
            $this->em->flush();
        }

        return $this->render('MarketDigitalBundle:Users:payment.html.php', array('userMenu' => $userMenu, 'info' => $check));
    }

    public function emailAction(Request $request) {
        $session = $request->getSession();
        $userMenu = $session->set('userMenu', "_user_email");

        $check = $this->em->getRepository('MarketDigitalBundle:Users')->findOneBy(array("email" => $this->username, "password" => $this->password));
        if (!$check) {
            $session = $request->getSession();
            $session->clear();
            return $this->redirect($this->generateUrl("_homepage"));
        }

        if ($request->getMethod() == 'POST') {
            $subject = $request->request->get("subject", "");
            $detail = $request->request->get("detail", "");

            $check->setEmailSubject($subject);
            $check->setEmailContent($detail);

            $this->em->persist($check);
            $this->em->flush();
        }

        return $this->render('MarketDigitalBundle:Users:email.html.php', array('userMenu' => $userMenu, 'info' => $check));
    }

}
