<?php

namespace Market\DigitalBundle\Controller;

use Symfony\Component\HttpFoundation\Request;

class CategoriesController extends BaseController {

    public function listProductsAction(Request $request, $id) {
        $em = $this->getDoctrine()->getManager();
        $id = (int) $id;
        $p = isset($_REQUEST['p']) ? (int) $_REQUEST['p'] : 1;
        if (!$p || $p < 1) {
            $p = 1;
        }
        $limit = (int) $this->container->getParameter('limit');
        $cat = $em->getRepository('MarketDigitalBundle:Categories')->findOneById($id);
        if (!$cat) {
            return $this->redirect($this->generateUrl("_homepage"));
        }
        $total = $em->getRepository('MarketDigitalBundle:Products')->_getCountListByCat($id);
        $list = $em->getRepository('MarketDigitalBundle:Products')->_getProListByCat($id, $p, $limit);
        $pager2 = array();
        $pager2['PreviousPage'] = ($p > 1) ? ($p - 1) : $p;
        $pager2['NextPage'] = (ceil($total / $limit) > $p) ? ($p + 1) : $p;
        $pager2['LastPage'] = ceil($total / $limit);
        $pager2['Page'] = $p;
        $arr1 = array('list' => $list, 'page' => $pager2, 'cat' => $cat);
        return $this->render('MarketDigitalBundle:Categories:listProducts.html.php', $arr1);
    }

    public function authorProductsAction(Request $request, $title) {
        $em = $this->getDoctrine()->getManager();
        $session = $request->getSession();
        $p = isset($_REQUEST['p']) ? (int) $_REQUEST['p'] : 1;
        if (!$p || $p < 1) {
            $p = 1;
        }
        $limit = (int) $this->container->getParameter('limit');
        $cat = $em->getRepository('MarketDigitalBundle:Users')->findOneBy(array("username" => $title));
        if (!$cat) {
            $session->set('notice', $this->get('translator')->trans('User Not Found.'));
            return $this->redirect($this->generateUrl("_homepage"));
        }
        $total = $em->getRepository('MarketDigitalBundle:Products')->_getCountListByUser($cat->getId(), 1);
        $list = $em->getRepository('MarketDigitalBundle:Products')->_getProListByUser($cat->getId(), $p, $limit, 1);
        $pager2 = array();
        $pager2['PreviousPage'] = ($p > 1) ? ($p - 1) : $p;
        $pager2['NextPage'] = (ceil($total / $limit) > $p) ? ($p + 1) : $p;
        $pager2['LastPage'] = ceil($total / $limit);
        $pager2['Page'] = $p;
        $arr1 = array('list' => $list, 'page' => $pager2, 'cat' => $cat);
        return $this->render('MarketDigitalBundle:Categories:authorProducts.html.php', $arr1);
    }

    public function searchAction(Request $request) {
        $em = $this->getDoctrine()->getManager();
        $p = isset($_REQUEST['p']) ? (int) $_REQUEST['p'] : 1;
        if (!$p || $p < 1) {
            $p = 1;
        }
        $limit = (int) $this->container->getParameter('limit');
        $s = isset($_REQUEST['s']) ? $_REQUEST['s'] : "";
        if ($s) {
            $total = $em->getRepository('MarketDigitalBundle:Products')->_getCountSearch($s);
            $list = $em->getRepository('MarketDigitalBundle:Products')->_getProSearch($s, $p, $limit);
        } else {
            $total = 0;
            $list = "";
        }
        $pager2 = array();
        $pager2['PreviousPage'] = ($p > 1) ? ($p - 1) : $p;
        $pager2['NextPage'] = (ceil($total / $limit) > $p) ? ($p + 1) : $p;
        $pager2['LastPage'] = ceil($total / $limit);
        $pager2['Page'] = $p;
        $arr1 = array('list' => $list, 'page' => $pager2, 's' => $s);
        return $this->render('MarketDigitalBundle:Categories:searchProducts.html.php', $arr1);
    }

}
