<?php

namespace Market\DigitalBundle\Controller;

use Symfony\Component\HttpFoundation\Request;
use Market\DigitalBundle\Entity\Categories;
use Market\DigitalBundle\MarketDigitalBundle as MiniLib;

class AdminController extends BaseController {

    //Dashboard
    public function indexAction(Request $request) {
        $em = $this->getDoctrine()->getManager();

        $session = $request->getSession();

        $session->set("dashboard", "");

        if (!$this->username || !$this->password) {
            $session->clear();
            return $this->redirect($this->generateUrl("_homepage"));
        }
        $checkw = $this->em->getRepository('MarketDigitalBundle:Users')->findOneBy(array("email" => $this->username, "password" => $this->password, "supper" => 1, "active" => 1));
        if (!$checkw) {
            $session->clear();
            return $this->redirect($this->generateUrl("_homepage"));
        }

        $mDate = date("m");
        $yDate = date("Y");
        $dateChart = $mDate . "/" . $yDate;
        if ($request->getMethod() == 'POST') {
            $dateChart = $request->request->get("dateChart", $dateChart);
            $tmp = explode("/", $dateChart);
            $mDate = $tmp[0];
            $yDate = $tmp[1];
        }

        $listToday = $em->getRepository('MarketDigitalBundle:Reports')->findOneBy(array("date_report" => date("d"), "month_report" => date("m"), "year_report" => date("Y")));

        $list = $em->getRepository('MarketDigitalBundle:Reports')->findBy(array("month_report" => $mDate, "year_report" => $yDate));

        $arr1 = array('list' => $list, "listToday" => $listToday, 'dateChart' => $dateChart);

        return $this->render('MarketDigitalBundle:Admin:index.html.php', $arr1);
    }

    //Categories
    public function categoriesIndexAction(Request $request) {
        $em = $this->getDoctrine()->getManager();

        $session = $request->getSession();

        $session->set("dashboard", "_admin_categories");

        if (!$this->username || !$this->password) {
            $session->clear();
            return $this->redirect($this->generateUrl("_homepage"));
        }
        $checkw = $this->em->getRepository('MarketDigitalBundle:Users')->findOneBy(array("email" => $this->username, "password" => $this->password, "supper" => 1, "active" => 1));
        if (!$checkw) {
            $session->clear();
            return $this->redirect($this->generateUrl("_homepage"));
        }
        $list = $em->getRepository('MarketDigitalBundle:Categories')->findAll();

        $arr1 = array('list' => $list);

        return $this->render('MarketDigitalBundle:Admin:categoriesIndex.html.php', $arr1);
    }

    public function categoriesAddAction(Request $request) {
        $em = $this->getDoctrine()->getManager();

        $session = $request->getSession();

        $session->set("dashboard", "_admin_add_categories");

        if (!$this->username || !$this->password) {
            $session->clear();
            return $this->redirect($this->generateUrl("_homepage"));
        }
        $checkw = $em->getRepository('MarketDigitalBundle:Users')->findOneBy(array("email" => $this->username, "password" => $this->password, "supper" => 1, "active" => 1));
        if (!$checkw) {
            $session->clear();
            return $this->redirect($this->generateUrl("_homepage"));
        }

        if ($request->getMethod() == 'POST') {
            if (MiniLib::$demoMode) {
                $session->set('notice', $this->get('translator')->trans('Only View on Demo Mode.'));
                return $this->redirect($this->generateUrl("_homepage"));
            }

            $title = $request->request->get("title", "");
            $active = $request->request->get("active", 0);
            if ($title != "") {
                $new_cat = new Categories();
                $new_cat->setMid(0);
                $new_cat->setTitle($title);
                $new_cat->setActive($active);
                $new_cat->setTotal(0);
                $a = new \Datetime();
                $new_cat->setCreatedAt($a);
                $new_cat->setUpdatedAt($a);
                $em->persist($new_cat);
                $em->flush();
            }
            return $this->redirect($this->generateUrl("_admin_categories"));
        }

        $list = $em->getRepository('MarketDigitalBundle:Categories')->findAll();
        $arr = array('list' => $list);

        return $this->render('MarketDigitalBundle:Admin:categoriesAdd.html.php', $arr);
    }

    public function categoriesEditAction(Request $request, $id = 0) {

        $em = $this->getDoctrine()->getManager();

        $session = $request->getSession();

        $session->set("dashboard", "_admin_categories");

        $username = $session->get('username', "");
        $password = $session->get('password', "");
        if (!$username || !$password) {
            $session->clear();
            return $this->redirect($this->generateUrl("_homepage"));
        }
        $checkw = $em->getRepository('MarketDigitalBundle:Users')->findOneBy(array("email" => $username, "password" => $password, "supper" => 1, "active" => 1));
        if (!$checkw) {
            $session->clear();
            return $this->redirect($this->generateUrl("_homepage"));
        }

        $viewT = $em->getRepository('MarketDigitalBundle:Categories')->findOneById((int) $id);
        if (!$viewT) {
            return $this->redirect($this->generateUrl("_admin_categories"));
        }

        if ($request->getMethod() == 'POST') {
            if (MiniLib::$demoMode) {
                $session->set('notice', $this->get('translator')->trans('Only View on Demo Mode.'));
                return $this->redirect($this->generateUrl("_homepage"));
            }

            $title = $request->request->get("title", "");
            $active = $request->request->get("active", 0);
            if ($title != "") {
                try {
                    $viewT->setMid(0);
                    $viewT->setTitle($title);
                    $viewT->setActive($active);
                    $em->persist($viewT);
                    $em->flush();
                } catch (Exception $ex) {
                    
                }
                return $this->redirect($this->generateUrl("_admin_categories"));
            }
        }
        $arr = array('viewT' => $viewT);
        return $this->render('MarketDigitalBundle:Admin:categoriesEdit.html.php', $arr);
    }

    public function categoriesDeleteAction(Request $request, $id) {
        $em = $this->getDoctrine()->getManager();

        $session = $request->getSession();
        $username = $session->get('username', "");
        $password = $session->get('password', "");
        if (!$username || !$password) {
            $session->clear();
            return $this->redirect($this->generateUrl("_homepage"));
        }
        $checkw = $em->getRepository('MarketDigitalBundle:Users')->findOneBy(array("email" => $username, "password" => $password, "supper" => 1, "active" => 1));
        if (!$checkw) {
            $session->clear();
            return $this->redirect($this->generateUrl("_homepage"));
        }

        if (MiniLib::$demoMode) {
            $session->set('notice', $this->get('translator')->trans('Only View on Demo Mode.'));
            return $this->redirect($this->generateUrl("_homepage"));
        }

        if (!$id) {
            return $this->redirect($this->generateUrl("_admin_categories"));
        }

        $viewT = $em->getRepository('MarketDigitalBundle:Categories')->findOneById((int) $id);

        $em->remove($viewT);
        $em->flush();

        return $this->redirect($this->generateUrl("_admin_categories"));
    }

    //Newsletter
    public function newsletterAction(Request $request) {
        $em = $this->getDoctrine()->getManager();

        $session = $request->getSession();

        $session->set("dashboard", "admin_newsletter");

        $username = $session->get('username', "");
        $password = $session->get('password', "");
        if (!$username || !$password) {
            $session->clear();
            return $this->redirect($this->generateUrl("_homepage"));
        }
        $checkw = $em->getRepository('MarketDigitalBundle:Users')->findOneBy(array("email" => $username, "password" => $password, "supper" => 1, "active" => 1));
        if (!$checkw) {
            $session->clear();
            return $this->redirect($this->generateUrl("_homepage"));
        }
        $error = 0;
        if ($request->getMethod() == 'POST') {
            if (MiniLib::$demoMode) {
                $session->set('notice', $this->get('translator')->trans('Only View on Demo Mode.'));
                return $this->redirect($this->generateUrl("_homepage"));
            }
            $title = $request->request->get("title", "");
            $details = $request->request->get("details", "");
            if ($title && $details) {
                try {
                    $query = "INSERT INTO Notifications (email, title, content, reply_email) SELECT email, :title, :details, '' FROM `NewsLetters` WHERE active = :active";
                    $connection = $em->getConnection();
                    $statement = $connection->prepare($query);
                    $statement->bindValue('active', 1);
                    $statement->bindValue('title', $title);
                    $statement->bindValue('details', $details);
                    $statement->execute();
                    $error = 2;
                } catch (\Exception $e) {
                    $error = 1;
                }
            } else {
                $error = 1;
            }
        }
        $a = array('error' => $error);
        return $this->render('MarketDigitalBundle:Admin:newsletter.html.php', $a);
    }

    //Products
    public function productsIndexAction(Request $request) {
        $em = $this->getDoctrine()->getManager();

        $session = $request->getSession();

        $session->set("dashboard", "_admin_products");

        $p = isset($_REQUEST['p']) ? (int) $_REQUEST['p'] : 1;
        if (!$p || $p < 1) {
            $p = 1;
        }
        $limit = (int) $this->container->getParameter('limit');

        $total = $em->getRepository('MarketDigitalBundle:Products')->_getCountAdmin();
        $list = $em->getRepository('MarketDigitalBundle:Products')->_getProAdmin($p, $limit);

        $pager2 = array();
        $pager2['PreviousPage'] = ($p > 1) ? ($p - 1) : $p;
        $pager2['NextPage'] = (ceil($total / $limit) > $p) ? ($p + 1) : $p;
        $pager2['LastPage'] = ceil($total / $limit);
        $pager2['Page'] = $p;
        $arr1 = array('list' => $list, 'page' => $pager2);
        return $this->render('MarketDigitalBundle:Admin:productsIndex.html.php', $arr1);
    }

    public function productsEditAction(Request $request, $id = 0) {

        $em = $this->getDoctrine()->getManager();
        $session = $request->getSession();
        $session->set("dashboard", "_admin_products");

        $username = $session->get('username', "");
        $password = $session->get('password', "");

        $tmp = dirname(dirname(dirname(dirname(dirname(__FILE__))))) . "/web";

        $checkUser = $em->getRepository('MarketDigitalBundle:Users')->findOneBy(array("email" => $username, "password" => $password, "supper" => 1, "active" => 1));
        if (!$checkUser) {
            $session->clear();
            return $this->redirect($this->generateUrl("_homepage"));
        }

        $products = $em->getRepository('MarketDigitalBundle:Products')->findOneBy(array("id" => $id));
        if (!$products) {
            return $this->redirect($this->generateUrl("_admin_products"));
        }

        $targetFolder = $tmp . '/uploads/tmp/' . $checkUser->getId() . "/";

        $category1 = $em->getRepository('MarketDigitalBundle:Categories')->findBy(array("active" => 1));

        $error = 0;

        $uploadFail = array();

        $fileUpload = $session->get('fileUpload', array());

        if ($request->getMethod() == 'POST') {
            if (MiniLib::$demoMode) {
                $session->set('notice', $this->get('translator')->trans('Only View on Demo Mode.'));
                return $this->redirect($this->generateUrl("_homepage"));
            }

            $title = $request->request->get("title", "");
            $details = $request->request->get("details", "");
            $preview = $request->request->get("heroImage", "");
            $main_file = $request->request->get("mainFile", "");
            $category = (int) $request->request->get("category", 0);
            $active = (int) $request->request->get("active", 0);
            $videoUrl = $request->request->get("video_url", "");

            $mFile = $products->getMainFile();
            $mPreview = $products->getImage();
            $mCid = $products->getCId();

            $price = round(floatval($request->request->get("price", 0)), 2, PHP_ROUND_HALF_DOWN);
            if ($price < 0) {
                $price = 0;
            }

            if ($preview != $mPreview) {
                if (preg_match("/png/i", $targetFolder . $preview)) {
                    $size = getimagesize($targetFolder . $preview);
                    if ($size[0] != 750 || $size[1] != 500) {
                        $uploadFail[0] = 1;
                    }
                } else {
                    $uploadFail[0] = 1;
                }
            }

            if ($main_file != $mFile) {
                if (preg_match("/zip/i", $targetFolder . $main_file)) {
                    $sizeUpload = (int) $this->container->getParameter('maxMain');
                    $size = @filesize($targetFolder . $main_file) / (1024 * 1024);
                    if ($size > $sizeUpload) {
                        $uploadFail[1] = 1;
                    }
                } else {
                    $uploadFail[1] = 1;
                }
            }

            $checkCid = $em->getRepository('MarketDigitalBundle:Categories')->findOneBy(array("id" => $category));

            if ($title && $details && $preview && $main_file && $category && $price && $checkCid) {
                if (count($uploadFail) == 0) {
                    try {

                        $products->setTitle($title)->setDetails($details);
                        $products->setCategories($checkCid);
                        $products->setCId($category);
                        $products->setActive($active);

                        if ($preview && $mPreview != $preview) {
                            $products->setImage($preview);
                        }

                        $products->setPreview($videoUrl);

                        if ($main_file && $mFile != $main_file) {
                            $products->setMainFile($main_file);
                        }

                        $products->setTags("");
                        $products->setPrice($price);

                        $em->persist($products);


                        $path = dirname(dirname(dirname(dirname(dirname(__FILE__)))));
                        $tmp = $path . "/web/uploads/tmp/" . $checkUser->getId() . "/";
                        $disImg = $path . "/web/uploads/items/";
                        $disFile = $path . "/items/";

                        if ($preview && $mPreview != $preview) {
                            @copy($tmp . $preview, $disImg . $preview);
                            @unlink($tmp . $preview);
                            @unlink($disImg . $mPreview);
                        }

                        if ($main_file && $mFile != $main_file) {
                            @copy($tmp . $main_file, $disFile . $main_file);
                            @unlink($tmp . $main_file);
                            @unlink($disFile . $mFile);
                        }

                        $em->flush();

                        $em->getRepository('MarketDigitalBundle:Categories')->updateCategories('c.total', $mCid, -1);

                        $em->getRepository('MarketDigitalBundle:Categories')->updateCategories('c.total', $category);

                        $session->remove("fileUpload");
                        return $this->redirect($this->generateUrl("_admin_products"));
                    } catch (Exception $ex) {
                        $error = 1;
                    }
                } else {
                    $error = 1;
                }
            } else {
                $error = 1;
            }
        }

        $arrReturn = array(
            'category' => $category1,
            "error" => $error,
            'uploadFail' => $uploadFail,
            'fileUpload' => $fileUpload,
            "product" => $products
        );
        return $this->render('MarketDigitalBundle:Admin:productsEdit.html.php', $arrReturn);
    }

    //Users
    public function usersIndexAction(Request $request) {
        $em = $this->getDoctrine()->getManager();

        $session = $request->getSession();

        $session->set("dashboard", "_admin_users");

        $p = isset($_REQUEST['p']) ? (int) $_REQUEST['p'] : 1;
        if (!$p || $p < 1) {
            $p = 1;
        }
        $limit = (int) $this->container->getParameter('limit');

        $total = $em->getRepository('MarketDigitalBundle:Users')->_getCountAdmin();
        $list = $em->getRepository('MarketDigitalBundle:Users')->_getProAdmin($p, $limit);

        $pager2 = array();
        $pager2['PreviousPage'] = ($p > 1) ? ($p - 1) : $p;
        $pager2['NextPage'] = (ceil($total / $limit) > $p) ? ($p + 1) : $p;
        $pager2['LastPage'] = ceil($total / $limit);
        $pager2['Page'] = $p;
        $arr1 = array('list' => $list, 'page' => $pager2);
        return $this->render('MarketDigitalBundle:Admin:usersIndex.html.php', $arr1);
    }

    public function usersEditAction(Request $request, $id = 0) {

        $em = $this->getDoctrine()->getManager();
        $session = $request->getSession();
        $session->set("dashboard", "_admin_users");

        $username = $session->get('username', "");
        $password = $session->get('password', "");

        $checkUser = $em->getRepository('MarketDigitalBundle:Users')->findOneBy(array("email" => $username, "password" => $password, "supper" => 1, "active" => 1));
        if (!$checkUser) {
            $session->clear();
            return $this->redirect($this->generateUrl("_homepage"));
        }

        $check = $em->getRepository('MarketDigitalBundle:Users')->findOneBy(array("id" => (int) $id));
        if (!$check) {
            return $this->redirect($this->generateUrl("_admin_users"));
        }

        $session->set("admin_edit_user", $check->getId());

        if ($request->getMethod() == 'POST') {
            if (MiniLib::$demoMode) {
                $session->set('notice', $this->get('translator')->trans('Only View on Demo Mode.'));
                return $this->redirect($this->generateUrl("_homepage"));
            }

            $name = $request->request->get("name", "");
            if ($name) {
                $check->setFullName($name);
            }

            $Bio = $request->request->get("bio", "");
            $check->setBio($Bio);

            $add = $request->request->get("add", "");
            $check->setAdd1($add);

            $country = $request->request->get("country", "");
            $check->setCountry($country);

            $city = $request->request->get("city", "");
            $check->setCity($city);

            $facebook = $request->request->get("facebook", "");
            $check->setFacebook($facebook);

            $twitter = $request->request->get("twitter", "");
            $check->setTwitter($twitter);

            $isAdmin = $request->request->get("isAdmin", 0);
            $check->setSupper($isAdmin);

            $homepage = $request->request->get("homepage", "");
            $check->setHomepage($homepage);

            $password = $request->request->get("password", "");
            if ($password) {
                $check->setHomepage(md5(sha1($password)));
            }

            $paypal = $request->request->get("paypal", "");
            $check->setEmailPaypal($paypal);

            $subject = $request->request->get("subject", "");
            $check->setEmailSubject($subject);

            $detail = $request->request->get("detail", "");
            $check->setEmailContent($detail);

            $em->persist($check);
            $em->flush();
        }

        return $this->render('MarketDigitalBundle:Admin:usersEdit.html.php', array('info' => $check));
    }

    //Help
    public function helpIndexAction(Request $request) {
        $em = $this->getDoctrine()->getManager();

        $session = $request->getSession();

        $session->set("dashboard", "_admin_help");

        if (!$this->username || !$this->password) {
            $session->clear();
            return $this->redirect($this->generateUrl("_homepage"));
        }
        $checkw = $this->em->getRepository('MarketDigitalBundle:Users')->findOneBy(array("email" => $this->username, "password" => $this->password, "supper" => 1, "active" => 1));
        if (!$checkw) {
            $session->clear();
            return $this->redirect($this->generateUrl("_homepage"));
        }
        $list = $em->getRepository('MarketDigitalBundle:Informations')->findAll();

        $arr1 = array('list' => $list);

        return $this->render('MarketDigitalBundle:Admin:helpIndex.html.php', $arr1);
    }

    public function helpAddAction(Request $request) {
        $em = $this->getDoctrine()->getManager();

        $session = $request->getSession();

        $session->set("dashboard", "_admin_add_help");

        if (!$this->username || !$this->password) {
            $session->clear();
            return $this->redirect($this->generateUrl("_homepage"));
        }
        $checkw = $em->getRepository('MarketDigitalBundle:Users')->findOneBy(array("email" => $this->username, "password" => $this->password, "supper" => 1, "active" => 1));
        if (!$checkw) {
            $session->clear();
            return $this->redirect($this->generateUrl("_homepage"));
        }

        if ($request->getMethod() == 'POST') {
            if (MiniLib::$demoMode) {
                $session->set('notice', $this->get('translator')->trans('Only View on Demo Mode.'));
                return $this->redirect($this->generateUrl("_homepage"));
            }

            $title = $request->request->get("title", "");
            $details = $request->request->get("details", "");
            $cId = $request->request->get("type", 0);
            if ($title != "" && $details) {
                $new_cat = new \Market\DigitalBundle\Entity\Informations();
                $new_cat->setCId($cId);
                $new_cat->setTitle($title);
                $new_cat->setDetails($details);
                $a = new \Datetime();
                $new_cat->setCreatedAt($a);
                $new_cat->setUpdatedAt($a);
                $em->persist($new_cat);
                $em->flush();
            }
            return $this->redirect($this->generateUrl("_admin_help"));
        }

        return $this->render('MarketDigitalBundle:Admin:helpAdd.html.php', array());
    }

    public function helpEditAction(Request $request, $id = 0) {

        $em = $this->getDoctrine()->getManager();

        $session = $request->getSession();

        $session->set("dashboard", "_admin_help");

        $username = $session->get('username', "");
        $password = $session->get('password', "");
        if (!$username || !$password) {
            $session->clear();
            return $this->redirect($this->generateUrl("_homepage"));
        }
        $checkw = $em->getRepository('MarketDigitalBundle:Users')->findOneBy(array("email" => $username, "password" => $password, "supper" => 1, "active" => 1));
        if (!$checkw) {
            $session->clear();
            return $this->redirect($this->generateUrl("_homepage"));
        }

        $viewT = $em->getRepository('MarketDigitalBundle:Informations')->findOneById((int) $id);
        if (!$viewT) {
            return $this->redirect($this->generateUrl("_admin_help"));
        }

        if ($request->getMethod() == 'POST') {
            if (MiniLib::$demoMode) {
                $session->set('notice', $this->get('translator')->trans('Only View on Demo Mode.'));
                return $this->redirect($this->generateUrl("_homepage"));
            }

            $title = $request->request->get("title", "");
            $details = $request->request->get("details", "");
            $cId = $request->request->get("type", 0);
            if ($title != "" && $details) {
                $viewT->setCId($cId);
                $viewT->setTitle($title);
                $viewT->setDetails($details);
                $em->persist($viewT);
                $em->flush();
                
                return $this->redirect($this->generateUrl("_admin_help"));
            }
        }
        $arr = array('viewT' => $viewT);
        return $this->render('MarketDigitalBundle:Admin:helpEdit.html.php', $arr);
    }

    public function helpDeleteAction(Request $request, $id) {
        $em = $this->getDoctrine()->getManager();

        $session = $request->getSession();
        $username = $session->get('username', "");
        $password = $session->get('password', "");
        if (!$username || !$password) {
            $session->clear();
            return $this->redirect($this->generateUrl("_homepage"));
        }
        $checkw = $em->getRepository('MarketDigitalBundle:Users')->findOneBy(array("email" => $username, "password" => $password, "supper" => 1, "active" => 1));
        if (!$checkw) {
            $session->clear();
            return $this->redirect($this->generateUrl("_homepage"));
        }

        if (MiniLib::$demoMode) {
            $session->set('notice', $this->get('translator')->trans('Only View on Demo Mode.'));
            return $this->redirect($this->generateUrl("_homepage"));
        }

        if (!$id) {
            return $this->redirect($this->generateUrl("_admin_help"));
        }

        $viewT = $em->getRepository('MarketDigitalBundle:Informations')->findOneById((int) $id);

        $em->remove($viewT);
        $em->flush();

        return $this->redirect($this->generateUrl("_admin_help"));
    }

}
