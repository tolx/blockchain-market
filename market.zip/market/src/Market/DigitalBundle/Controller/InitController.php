<?php

namespace Market\DigitalBundle\Controller;

use Symfony\Component\HttpFoundation\Request;

class InitController extends BaseController {

    public function footerAction(Request $request) {

        $arr1 = array('categories' => $this->categories);

        return $this->render('MarketDigitalBundle:Init:footer.html.php', $arr1);
    }

    public function systemAction(Request $request, $title = "") {

        switch ($title) {
            case "terms":
                $title = 0;
                break;
            case "privacy":
                $title = 1;
                break;
            case "about":
                $title = 2;
                break;
            default:
                $title = 0;
                break;
        }

        $info = $this->em->getRepository('MarketDigitalBundle:Informations')->findOneBy(array("c_id" => $title));;

        $arr1 = array('product' => $info);

        return $this->render('MarketDigitalBundle:Init:system.html.php', $arr1);
    }

}
