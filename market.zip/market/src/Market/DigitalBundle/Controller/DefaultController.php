<?php

namespace Market\DigitalBundle\Controller;

use Symfony\Component\HttpFoundation\Request;
use Market\DigitalBundle\MarketDigitalBundle as MiniLib;

class DefaultController extends BaseController {

    public function indexAction(Request $request) {
        return $this->render('MarketDigitalBundle:Default:index.html.php', array());
    }

    public function indexFixedAction(Request $request) {

        $session = $request->getSession();
        
        $notice = $session->get('notice', "");
        $session->set('notice', "");
        
        $check = $this->em->getRepository('MarketDigitalBundle:Users')->findOneBy(array("email" => $this->username, "password" => $this->password));

        $arr_0 = $this->em->getRepository('MarketDigitalBundle:Products')->_getFeature(20);

        $arr1 = array('fbRegister' => $this->fbRegister, 'categories' => $this->categories, "check" => $check, 'list' => $arr_0, 'notice' => $notice);

        return $this->render('MarketDigitalBundle:Default:indexFixed.html.php', $arr1);
    }

    public function menuAction(Request $request) {

        $check = $this->em->getRepository('MarketDigitalBundle:Users')->findOneBy(array("email" => $this->username, "password" => $this->password));

        return $this->render('MarketDigitalBundle:Default:menu.html.php', array('fbRegister' => $this->fbRegister, 'categories' => $this->categories, "check" => $check));
    }

}
