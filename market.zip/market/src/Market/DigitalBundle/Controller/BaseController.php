<?php

namespace Market\DigitalBundle\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Session\Session;
use Symfony\Component\HttpFoundation\Request;
use Market\DigitalBundle\MarketDigitalBundle as MiniLib;
use Facebook\Facebook;

class BaseController extends Controller {

    protected $em;
    protected $username;
    protected $password;
    protected $fbRegister;
    protected $categories;

    public function __construct() {
        $this->em = MiniLib::getManager();

        $session = new Session();
        $request = new Request();

       /* $this->fbRegister = $session->get("fbRegister", "");
        if (!$this->fbRegister) {
            $fb = new Facebook(array('app_id' => MiniLib::$fb_app, 'app_secret' => MiniLib::$fb_key));

            $helper = $fb->getRedirectLoginHelper();

            $url = MiniLib::getContainer()->get('router')->generate('register', array("fb" => "facebook"), true);

            $permissions = array('email'); //, 'user_likes', 'publish_actions', 'publish_pages', 'manage_pages');

            $fbRegister = $helper->getLoginUrl($url, $permissions);

            $this->fbRegister = $fbRegister;

            $session->set("fbRegister", $fbRegister);
        } */
        

        $this->categories = $this->em->getRepository('MarketDigitalBundle:Categories')->findBy(array("active" => 1));

        $locale = isset($_REQUEST['lang']) ? $_REQUEST['lang'] : "";
        if (!$locale) {
            $locale = $session->get("_locale", "en");
        }
        $session->set("_locale", $locale);
        $request->setLocale($locale);

        $this->username = $session->get('username', "");
        $this->password = $session->get('password', "");
    }

}
