<?php

namespace Market\DigitalBundle\Controller;

use Symfony\Component\HttpFoundation\Request;
use Market\DigitalBundle\Entity\Bought;
use Market\DigitalBundle\Entity\Sell;
use Market\DigitalBundle\Entity\Notifications;
use Market\DigitalBundle\MarketDigitalBundle as MiniLib;
use Market\DigitalBundle\System;

class IpnController extends BaseController {

    public function ipnAction(Request $request) {
        $em = $this->getDoctrine()->getManager();

        $ipnMessage = new \PPIPNMessage(null, MiniLib::sdkConfig());

        if ($ipnMessage->validate()) {

            $em->getConnection()->beginTransaction();
            try {
                $response = $ipnMessage->getRawData();

                $pay_key = $response["pay_key"];
                $status = strtoupper($response["status"]);
                $sender_email = $response["sender_email"];
                $a = new \Datetime();

                $prePay = $em->getRepository('MarketDigitalBundle:PaypalPayment')->findOneBy(array("token" => $pay_key));
                if ($prePay) {
                    $product = $em->getRepository('MarketDigitalBundle:Products')->findOneBy(array("id" => $prePay->getPId()));
                    if ($product) {
                        if ($status != "COMPLETED") {
                            if ($prePay->getStatus() != 0) {
                                $prePay->setStatus(0);
                                $em->getRepository('MarketDigitalBundle:Bought')->updateStatus("c.status", $prePay->getId(), 0);
                                $em->getRepository('MarketDigitalBundle:Sell')->updateStatus("c.status", $prePay->getId(), 0);

                                $em->getRepository('MarketDigitalBundle:Products')->updateProducts("c.total_sale", $product->getId() - 1);
                                $em->getRepository('MarketDigitalBundle:Users')->updateUsers("c.saled", $product->getUsers()->getId(), -1);
                                $em->getRepository('MarketDigitalBundle:Users')->updateUsers("c.earned", $product->getUsers()->getId(), -1);

                                $em->persist($prePay);
                                $em->flush();
                            }
                        } else {
                            //Can Download When complete
                            $buyer = $em->getRepository('MarketDigitalBundle:Users')->findOneBy(array("id" => $prePay->getUserId()));

                            $prePay->setStatus(1);
                            $prePay->setPayerId($sender_email);
                            $em->persist($prePay);
                            $em->flush();

                            $systemMoney = $prePay->getPrice2();
                            $sellerMoney = $prePay->getPrice1();

                            $statusMail = 0;
                            $bought = $em->getRepository('MarketDigitalBundle:Bought')->findOneBy(array("pp_id" => $prePay->getId()));
                            if (!$bought) {
                                $statusMail = 1;
                                $bought = new Bought();
                                $bought->setCreatedAt($a)
                                        ->setUpdatedAt($a)
                                        ->setDatas("")
                                        ->setPId($product->getId())
                                        ->setStatus(1)
                                        ->setPpId($prePay->getId())
                                        ->setTitle($product->getTitle())
                                        ->setUserId($prePay->getUserId());
                            } else {
                                if ($bought->getStatus() == 0) {
                                    $statusMail = 1;
                                }
                                $bought->setStatus(1);
                            }
                            $em->persist($bought);
                            $em->flush();

                            
                            $em->getRepository('MarketDigitalBundle:Products')->updateProducts("c.total_sale", $product->getId());
                            $em->getRepository('MarketDigitalBundle:Users')->updateUsers("c.saled", $product->getUsers()->getId());
                            $em->getRepository('MarketDigitalBundle:Users')->updateUsers("c.earned", $product->getUsers()->getId(), $sellerMoney);


                            $mDate = date("m");
                            $yDate = date("Y");
                            $dDate = date("d");
                            $report = $em->getRepository('MarketDigitalBundle:Reports')->findOneBy(array("date_report" => $dDate, "month_report" => $mDate, "year_report" => $yDate));
                            if ($report) {
                                $em->getRepository('MarketDigitalBundle:Reports')->updateReport('c.sales', 1, $report->getId());
                                $em->getRepository('MarketDigitalBundle:Reports')->updateReport('c.paid', $sellerMoney, $report->getId());
                                $em->getRepository('MarketDigitalBundle:Reports')->updateReport('c.revenues', $systemMoney, $report->getId());
                            } else {
                                $report = new \Market\DigitalBundle\Entity\Reports();
                                $report->setDateReport($dDate)
                                        ->setMonthReport($mDate)
                                        ->setYearReport($yDate)
                                        ->setOthers("")
                                        ->setPaid($sellerMoney)
                                        ->setProducts(0)
                                        ->setRevenues($systemMoney)
                                        ->setSales(1)
                                        ->setUsers(0);
                                $em->persist($report);
                            }

                            if ($statusMail) {

                                $url = $this->generateUrl('_download', array("id" => $product->getId(), "title" => md5(sha1(System::_reString($product->getTitle())))), true);

                                $url2 = $this->generateUrl('_sales', array(), true);

                                $homePage = $this->generateUrl('_homepage', array(), true);


                                //Mail to seller
                                $sub1 = $this->get('translator')->trans("Your product has been purchased!");
                                $content1 = $this->get('translator')->trans('Congratulations') . ' ' . $product->getUsers()->getUsername() . '!<br><br>' .
                                        $this->get('translator')->trans('A user has just purchased your item') . ' "' . $product->getTitle() . '".<br>' .
                                        $this->get('translator')->trans('For this purchase you earned') . ' $' . $sellerMoney . '.<br><br>' .
                                        $this->get('translator')->trans('Please notice that you can track your sales by visiting') . ' ' . $url2 . '<br><br>' .
                                        $this->get('translator')->trans('Sincerely') . ',<br>' .
                                        $this->get('translator')->trans('Digital Products Marketplace') . '<br>' . $homePage;

                                $noti = new Notifications();
                                $noti->setEmail($product->getUsers()->getEmail());
                                $noti->setReplyEmail('');
                                $noti->setTitle($sub1);
                                $noti->setContent($content1);
                                $em->persist($noti);
                                $em->flush();


                                //Mail to Buyer
                                $sub = $product->getUsers()->getEmailSubject();
                                $mTitle = $product->getUsers()->getEmailContent();

                                $t = $this->get('translator')->trans("Hey! I just purchased") . " " . $product->getTitle() . ". " . $this->get('translator')->trans("It's so simple with") . " @" . MiniLib::$tw_acc . " " . $this->generateUrl("_view_products", array("id" => $product->getId(), "title" => System::_reString($product->getTitle())), true);

                                $content = '<div align="center" style="background: #eaeced; padding-top: 20px; font-family: "Proxima-nova","Helvetica Neue",Helvetica,Arial,sans-serif;">
                            <div style="background: #006c9a; width: 534px; height: 80px; padding: 40px 35px 15px 35px; margin-top: 40px;">
                                <table width="540"border="0" cellpadding="0" cellspacing="0">
                                    <tr>
                                        <td align="left">
                                            <a href="' . $homePage . '">
                                                <img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAMgAAAAoCAYAAAC7HLUcAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAA3NpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuNS1jMDE0IDc5LjE1MTQ4MSwgMjAxMy8wMy8xMy0xMjowOToxNSAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wTU09Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9tbS8iIHhtbG5zOnN0UmVmPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvc1R5cGUvUmVzb3VyY2VSZWYjIiB4bWxuczp4bXA9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC8iIHhtcE1NOk9yaWdpbmFsRG9jdW1lbnRJRD0ieG1wLmRpZDpiM2E1MGVkNS1kYTBmLTQ0ZjUtOTVmNy1mN2IzMTkyNmIzMmUiIHhtcE1NOkRvY3VtZW50SUQ9InhtcC5kaWQ6RjlEQzVFMDg0NEUwMTFFNUEwODVEMDU3REZFODlCMjYiIHhtcE1NOkluc3RhbmNlSUQ9InhtcC5paWQ6RjlEQzVFMDc0NEUwMTFFNUEwODVEMDU3REZFODlCMjYiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENDIChNYWNpbnRvc2gpIj4gPHhtcE1NOkRlcml2ZWRGcm9tIHN0UmVmOmluc3RhbmNlSUQ9InhtcC5paWQ6ZWRkZjgyZjQtZTlkZi00ZTg2LTkzZGMtNmZlN2U3NjE4MWEzIiBzdFJlZjpkb2N1bWVudElEPSJ4bXAuZGlkOmIzYTUwZWQ1LWRhMGYtNDRmNS05NWY3LWY3YjMxOTI2YjMyZSIvPiA8L3JkZjpEZXNjcmlwdGlvbj4gPC9yZGY6UkRGPiA8L3g6eG1wbWV0YT4gPD94cGFja2V0IGVuZD0iciI/PvZrxAUAAAeUSURBVHja7F2NkeU0DH7HUEA6IHSQEkIHoQPTQa4CQwWBCnxUEKjAUIGXCrIdZDsweTPO4PNJlmTnLbO31oznhvfiPEfSp/8NH7z3t0aNGsH0TWNBo0YNII0aNYA0atQA0qjRGwRIdyx1rPVY96zfhc8kNByrbyJ5OA0FsmkAqWC2OdYW/p2izzXzHmPY76L7SIBpAjCb0POkIj7bxg4m3cu8xOqOZY41Rp9Nx7Kepp6494Ls04xzDcdy0R4XznprK8unk8bGG3pRF9yZuAcG3/9bHWvzfDIZ0LnMPss8V0pLE+pna0b4uzfe8FYuxFqCK34+1l/H2kM40wvdOhSWufAvRs+Z7+Zwro75e++RusCjBfn+18YiHn2LfG4iZRsIZY6V+iW59gkAh2XkC38zzgXRUxPpFzz+I8oNb0FGvzU2lSfpg9AS34Hx07G+P9bH5LvfC8DxEoSaWkRHnOsF+P33mIifFcQ7P34EPP4v4btGhQAZmXvvYdcPARifIhDE9CkDjp+j71P3/wIAi/JiH9+5BzFRBfA5yKZP+Pbcwqv6KpYhEm+bqYA4IEEfgIRahe8skDx2SQVmZxQD9DtOJNOChw2fdQDvvvbKVR/07s6D9VFVLFcAjLOylAoDUnCDXO9D1eUWVcz2ikoZVq4+gTi+cqn1NAbbheXoIakqmoyhs++gnB3ry/YogKTkmMpkk8PlwAF5D5eAg0Pc3gdUVtb/k+CusuRTcl+VMVacntRb96LbI7wl9OEeKbli3igVyEqAY8o0rgwAAofU8rmWGALc8ErCMw/oQczJ/UYiCvia+0Nj0LdU/8YrQIKhUao8VmDpIbQvGXBoBByDL2+YmVcU4IrkX1cAzgF8mCsMyRnDrwU6ULNX6i1MRfjdBZ2ywVBXddJLvAcVBi2AAHvA6pnAaIhUAVPXAMwrQqvey0c9HEcggjBxBRQfSsxnwW9sFUZku8AAjeG8Osi4ZzyfdNTJSPKUqysoFDiwxBzKDzBmSBV8uNCi9ZG3nJkC74X8nIPy28gap3nMwgw1Tn6dqxcYOlthJG2B59mRSKEXRCqcsDKlhwJkzRwwDYOg0GrPlIChe69CoW3MOLxLLBcUkuhMUQEK6eLnmpjn3YEYOr3XHhRFMhNHhVqYoasxktzQl/IImpgrkxRvjHRoswYcWgAOCkznHpVhhmRaV1UOTmrGNKxnJuWckFD5x9NUEAWMvjyCoPYapI0wAefuIsNAAcoIwEFGJI/IOyBwKAY4hsjl7hVVJyUQGCTg2K3nejEbUwhUkvwa4FgZJWhD9KWu3Gsy1zqGl3aCqCKWsZFGJaVxeA7FitEHyAHKCpl9I8rHOSuxZs5vhEZgKbCk3EmBGtqR3CP+bYXE55pxbuneBZFtl/Acq1QuAuOTggPSL3slQKikXAuvT5kwIaEV16vtgtBqRsDREckgJLixsNq2PAgUNtxbI6HVCCj4jVkBq90LWe80jN0QcChm2HhLKqMmYxQv9SCGEIp0rktlSoWSjqgRggOqkC0AoHfgGSbPG8/hlKL7qDigkzOdZeExs3qmHCAl24FnsURYW7MXu0YzcwgleM7Yw2kid56vAsgsrJDMQnCoQu9hBE0ijEkGAIcDLJ7y+HxXbTPQFBQkpFUZRYQvLqOANXtvQE9rByz54OsnIQbEw5WEaLermoEjwQxOjdoKFS0XCmlBUrwi4OiIZBBL8CdCoalQiwsOqffQhIJ3GQWs2Xs2aRfEsC5Ef8YInnMiwJECeQZ4NEkBQiXlUN6xCSsqnaATmsasLokrnaeneXONylNBdUboWHK9MOLhPgNYSSmb8h5zdGaTKalD91M+P0vG3RtPG+8CD5/yzDHCIsWQh0J+v8MawLVJuRUmnpgCTII+Q2wlHOBJILc5Es+Rng/KUW4AcAyDHyoph8ZnsoXgyHmPLjIYmvDmKrk+VfD5or0K8Paa2UA0gE6NAiNugLDaIEUHIw2xpoLO7C4sN+aajj3gqmOF6JDwbIsS31QJF8b5sHxoB6wYpKjnb2+AUDrgDNJXFi3I+eLfjMuncybEiae3RwC8O1IO5+7NTWl3gL5ZgGcbEnp3SXEj17M6v5/95yMu2WSdI4xdWN/3wutzADm7q0tyDuP5Xf1UIFg+NXh+11952XyQYTYmSwYDueVlKlR2/ssRlnNauGZvzhud3XEL3F9nvCXUVXeMiGcL+xw3byy1VloovLnCU3GS4J7YF0++QuGTYhQMsPib6oRrAhwlg5Rb5nycKhaHlsTC1+yVTOJuyTOMAgMkbb5ayjhxm4O7ILkywmSMo+Cch8FCiJkodypmSdtllNkxBH0VOLAE3TDDtIGRV44P2MsBGQSsvsBgdkQUsHFL8ZKR8dXzRs37TJOmpKu8ef7fUZzJ4Orxqdz4nLnp1jXJZygjcuY7BjivvhAccUXOMsqkudK9jkKcRXCmmr0T0DOZCVkZpDzcMXRR+//+fMB44d/kfPCP+V+wdWE9C/fp8ObELrwb60/k1UBvjfbolUdP4ZU87d1U8nd+fXesf8Irp16Ff48CSKMvgT9GgG/geCPUANKokfDNio0aNWoAadSIpn8FGADED64lSREoYgAAAABJRU5ErkJggg==" data-filename="Marketplace.png" style="width: 200px; margin-top: -20px;" title="Marketplace.Com" alt="Marketplace.Com"></img>
                                            </a>
                                        </td>
                                        <td align="right" width="200"></td>
                                    </tr>
                                </table>
                            </div>

                            <div style="background: #fcfcfc; border-bottom: 1px solid #eee; width: 534px; padding: 25px 35px 10px 35px; margin-top: 0px;">
                                <div align="left" style="text-align: center;">
                                    <h1 style="font-size: 36px; font-weight: 200; color: #000; margin: 0 0 20px 0; text-align: center; font-family: "Proxima-nova","Helvetica Neue",Helvetica,Arial,sans-serif;">' . $sub . '</h1>
                                    <p style="font-size: 15px; color: #666; margin:20px 0 20px 0; line-height: 1.5; text-align: center; font-family: "Proxima-nova","Helvetica Neue",Helvetica,Arial,sans-serif;">' . $mTitle . '</p>
                                    <a href="' . $url . '" style="background: #006c9a; font-weight: bold; height: 48px; padding: 0 40px; display: inline-block; line-height: 48px; text-decoration: none; color: #fff; border-radius: 2px; font-family: "Proxima-nova","Helvetica Neue",Helvetica,Arial,sans-serif;">' . $this->get('translator')->trans('Download this product') . '</a>
                                    <p style="margin-top: 10px; font-family: "Proxima-nova","Helvetica Neue",Helvetica,Arial,sans-serif;">
                                        ' . $this->get('translator')->trans('Or download using this link:') . ' 
                                        <a href="' . $url . '" style="font-family: "Proxima-nova","Helvetica Neue",Helvetica,Arial,sans-serif;">
                                            ' . $url . '
                                        </a>
                                    </p>
                                </div>
                            </div>
                            <div style="background: #fff; width: 534px; padding: 25px 35px; margin-top: 0px;">
                                <div align="left" style="text-align: center;">
                                    <p style="text-align: center; font-family: "Proxima-nova","Helvetica Neue",Helvetica,Arial,sans-serif;">' . $this->get('translator')->trans('Let your friends know about your awesome purchase!') . '</p>
                                    <a href="https://www.facebook.com/sharer/sharer.php?app_id=' . MiniLib::$fb_app . '&u=' . $homePage . '" style="background: #3f5da8; height: 48px; padding: 0 40px; display: inline-block; line-height: 48px; text-decoration: none; color: #fff; border-radius: 2px; font-family: "Proxima-nova","Helvetica Neue",Helvetica,Arial,sans-serif;">
                                        <img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAPCAYAAADZCo4zAAAABHNCSVQICAgIfAhkiAAAAGJ6VFh0UmF3IHByb2ZpbGUgdHlwZSBBUFAxAAB4nFXIsQ2AMAwAwd5TeIR3HBwyDkIBRUKAsn9BAQ1XnuztbKOveo9r60cTVVVVz5JrrmkBZl4GbhgJKF8t/ExEDQ8rHgYgD0i2FMl6UPBzAAAArElEQVQYla2QMVJCQRBE32z9AgsQI0MzzkLAKbwA97HKC3gPbkBMACYe4MNPEB/JLo5VmtnRbs/brt6BKnWpXvypPhLwDjzxrSOwacNO/Uwv1+pcnZASjgnomt+pz8ACGKX4V/UA7EPtgRm/a1tqkR4wDYbqvaFO1Ef1lDqs1Hu1dBExAIP6lRI+IqIHKPUHd0Ak4KEdyh/l+H+gANPk3/bSVnoGXoBxve8acAWiyn/5nm77PQAAAABJRU5ErkJggg==" data-filename="fb.png" style="width: 8px; margin-right: 10px; margin-top: -5px;">
                                        FACEBOOK
                                    </a>
                                    <a href="https://twitter.com/intent/tweet?text=' . urlencode($t) . '" style="background: #00aced; height: 48px; padding: 0 40px; display: inline-block; line-height: 48px; text-decoration: none; color: #fff; border-radius: 2px; margin-left: 30px; font-family: "Proxima-nova","Helvetica Neue",Helvetica,Arial,sans-serif;">
                                        <img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAA8AAAANCAYAAAB2HjRBAAAABHNCSVQICAgIfAhkiAAAAGJ6VFh0UmF3IHByb2ZpbGUgdHlwZSBBUFAxAAB4nFXIsQ2AMAwAwd5TeIR3HBwyDkIBRUKAsn9BAQ1XnuztbKOveo9r60cTVVVVz5JrrmkBZl4GbhgJKF8t/ExEDQ8rHgYgD0i2FMl6UPBzAAAArUlEQVQokZWSXRHDIBCElzrAAhawkEqIFizEQi3EQishFlIJRMLXhx4zDIFOs4/H7c8sJ0kCvAYAIrACG7AA3mahPG5A6BADkDnjCUQBkw0yMDfkpUMsu0EWo1bfgQcwm0MPqY62DpZGmArZXyRC3Y/F/Be5bdVfEEi9/xyVU2MfHYMHEt+2u3EpRRlujYaXdDoWSW9Jd+fcq3WMPyJn66J7vq4WqZwPScfJqcEHweTn4GsmB0EAAAAASUVORK5CYII=" data-filename="tw.png" style="width: 15px; margin-right: 10px; margin-top: -5px;">
                                        TWITTER
                                    </a>
                                </div>
                                <div style="height:1px; border-bottom: 1px solid #e3e5e6; margin-top: 20px;"></div>
                                <div align="center" style="padding: 30px 0 10px 0;">
                                    <a href="' . $homePage . '">
                                        <img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAMgAAAAoCAYAAAC7HLUcAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAA3NpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuNS1jMDE0IDc5LjE1MTQ4MSwgMjAxMy8wMy8xMy0xMjowOToxNSAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wTU09Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9tbS8iIHhtbG5zOnN0UmVmPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvc1R5cGUvUmVzb3VyY2VSZWYjIiB4bWxuczp4bXA9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC8iIHhtcE1NOk9yaWdpbmFsRG9jdW1lbnRJRD0ieG1wLmRpZDpiM2E1MGVkNS1kYTBmLTQ0ZjUtOTVmNy1mN2IzMTkyNmIzMmUiIHhtcE1NOkRvY3VtZW50SUQ9InhtcC5kaWQ6RjlEQzVFMDQ0NEUwMTFFNUEwODVEMDU3REZFODlCMjYiIHhtcE1NOkluc3RhbmNlSUQ9InhtcC5paWQ6RjlEQzVFMDM0NEUwMTFFNUEwODVEMDU3REZFODlCMjYiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENDIChNYWNpbnRvc2gpIj4gPHhtcE1NOkRlcml2ZWRGcm9tIHN0UmVmOmluc3RhbmNlSUQ9InhtcC5paWQ6ZWRkZjgyZjQtZTlkZi00ZTg2LTkzZGMtNmZlN2U3NjE4MWEzIiBzdFJlZjpkb2N1bWVudElEPSJ4bXAuZGlkOmIzYTUwZWQ1LWRhMGYtNDRmNS05NWY3LWY3YjMxOTI2YjMyZSIvPiA8L3JkZjpEZXNjcmlwdGlvbj4gPC9yZGY6UkRGPiA8L3g6eG1wbWV0YT4gPD94cGFja2V0IGVuZD0iciI/Pi+hYIoAAAnlSURBVHja7F1NdttGDB73ZdVNmBOEPkHoE4Q6QegTmFp1aekElE5AeZmV6BNYOYGYE4g5gdkTmN1060p9mAiGgPkhKb82HrzH11TmUDMAPuADZmhfPD8/qyBBgvDyW1BBkCABIEGCBIAECRIAEiTIK8o7+sHvf9z1eU60v7L99QX+2+yvyf7qPJ6RwP1tMMtZJQEdd0EVvPz99Xa0DHJQ9np/PcJ/M/R54fiMFMbv0HN8gHm4/wH+HUSWHOl5G9QxHsXSTpiizzJQ8g4UzznnbH/FlmeX8JyYGLJwBOcW7tfzCSDh9bQDG8boszSoZjhAdHQ/KLRGUejBUcGFAXQ7AJH0vbZ5bWFeqkfWeisyAz0n5PMO7BlkAEB0dG9BmU8kCrmmdSmiJYZxrcXoUrbIg0l/BqAt2JCTVVBRzyIdZI2cLbE4M3bqjtzbCLTIRoW+O8yLkyaY9ETHG1Qb6uxxF9TUP4MknpH4AIzp/rrcX3Pys/se4OjAqBwlyy3j5qEQ/1dPEejjmsn4SxU6WIMA4lq8HWjXBIBRIRBgqQzgWKCf0/TfMcCyZbH5G88ga3XsALZgm5jorQ30ajjF+uQAjKVQ5N0QcHQCOKbw8y2TBe56ZB0JbG+p3kiQfa6FJsn0F9dFDGuOUQY9C8UyZYyJAI6UjL0XHLyCK2WyFU7/uSM4Khjn4kiHCPsMDYf0FQ2n9XD47kc1XjuaNjwqddygLcn31OrX7lwliIanjnXzKABpLMBQTLTSBTsHjqkQ3RqU/nNwZpsjNY51h46yOfr/z68MjhRFuTGMp/d+YpQdpihY5W8oexzs+cCwlLMApCPF95VD5KHZoLGAI2Mi+Jzh0vpZjTBP1+MsGeOU317JeLdED2PsQcyQQ2g9YIpZMnVd+4uCI1Wn2w8bz3raCyCXAIpLD15fMA4ZCZE+EgxYq9M2bgOLTQaAQzGZqHrFgj4SAsGQYrwk2b0m4EmIrpaOz47V8eiOb5YbMtZXn2ugyc8QiDMhu94I4wthnFOR3nk6T2pBKj24WBC068Kcbh5W6POhHasKKFXiUbPYnME1Ii/RepfqtIXdtxjfQEbuGONLdZ1NMGXrPGnKkLG0jn2/v/4E4LdkfT41HGfnEgXh2GaPdyOgufQAR6pOj5csmaizAHA8jtCx0s+9HiF66SiZAkhXDgZvISO76jMHMEck+mPKumIyUcrQOQXOVqDGSWuYa0zW6uPYfcfqzlPGzL0D3ek5+xxKlWhl7jPPoad514Z02pEIF6nTk7odKCchxdVSKNI3HtE/VcfTqzsLkCMAbqHkw5cFPE9nyxtLjfAETv3oksrRfEsUOO7U8dxZhHSWwL3P6JIowwKumSGTcIEuHRAkXcfOlPnAa4T0PPN4biP4yVrQ+1kySGEwvK4RGjK52MDP9U54BcrImEW7pu2cUUbkSF0O8hEpOBECQWIIGrnjd0vzzQy6jXoWn1MBINz6sfPUHrTPZyzVUw061x0pLT8QdazhuyILnZ4za5WOKX02zbNvBkkhKrmCI7dEUdyJiRV/KnfqyKVzIVLcOxq4Q/fmBgdoHcHRWXiuNN8xZSPMQWeiRKCtiYW69h1L9TRHzYaCadIcdPgB7vlAfOvw8wt0cXWZzlK+8+wFkJgg3FZAJxZ6QwG1Fjo/LkV5JjjbQogSXGaYg/OvlbwXw+3SlkKEujYA26abMUQ6o4Y3cadCdn5vmHffsSUDjhWi4Iml0C8d7uECYAX31j7Z3ZdiRZZCiRbQkTJv+FFwcPsjjXI7P5QK4JC6VhyNm0JE2hpoDJchueaDEgyC5Uad5yWvGubXAUVpGV09IAev0NrwfP4S9Dxk7IxE/xVDY1sILA2TbWeOrCJGzZ8KAalj7DkaQEplPoqy9LifywylcI9Ls4DrglRChOHaoSsEjoTQo5wYpWHWyYHD1m27g3bmewTaiBSaJgO2TKevBgDbKJ3OghsSjFLyrLHGKsW3oAtC16UaglLR2kBdcYZbEL9sSGD8PhZAZko+bs5RDtP9nAPlTBHfKPuus1R8VYb0S9uhOstgcOjNzS2TYWgHJ+kBDu3gK4Zauv7SCy5jLh3BMWGAHjFZaIyx2mlT4jM7pkPZONZpc0f6V1kaQ9UYNUhq4cqUZ9u49YqZ2I0QYW38Mheo3tTgJAtimDkDjglZw4ahj/T7daCoPBya8nJXcMTM2mtDQCkcHDwRHHDIWE3Lb5gxHfjCpUCplDo9eiQBUFN0EzgUASnN0CedWReA2IpyWgBHlvs3DPql1mVtiRIp6nQoQk04QHHK/i6A45YYfSl0cGjW2gg63AlZEvNqn1+XVFiyBz5yskZBQQospUAjh4zVJ2wzZkwFHam50BHEOqNg+CYEPlwfr5kgnauXJ59XZF0Lah8bQGxFOVd3FEreoZT2MlIDBZGiRIIcKiKKjZjnS9mmZMChmKK7QbWLfmuvcmgZ5up4jKZCa9JzWvcAhyl7aJsd1vVF8W+IRoia6vtzhh7OBo7dwVy5uq210Hmss5qxBdVHKTxnTbIgpd+pOm4AV7QhZKtBUmXeKb8WHMJ0P+cAnwyO0BLDZMghuOfpvneF1pCSmmZmmV/OgGxHwKfbkzkDxJqpq7RRNMhmxOA+hy9vDY0H/Z24fXr490dm3aU6vjfSoq5bCs9K1fH0cdZz7DV8/pkJdHdkzRmsLSU6e2T8Qq/5FjU3OsZuuToehdFHd1bquN+WE3u+kAv65w+Y36z4JGQQ6f0Q6e8pTCz8eGHIUF+I09ICXBqvGCdMFP+L065QZHpQ5o1NHClNLWHFgIPbmLxSfsfRH5X5HBHHv2OU+ST9dHBfTDJ+N2Bsg6J5yQQlTMfoK9n6oOejMC5hGhum17NbuCJ1upfykxr7/mbFyqHusKXOuaUb9cOQwbYkQlwzNO3esoYNitANE6kpBTDt21Dns333wgKOiRrvXQ3u3RBsF1PLPFEvDx2uUEE+ZCz2o06oPVOk8xbGLkm24MbhgHmlTs//cYwEs6Iaxm2GdLFopV9ZWok1AzDbRp/LLrlpMa3wHXoXGVMxvLPcCdH2myEDVcz6GmFO2NASOPq8l1ILgezSEogqkimlZ0/U6V7EkLFU76buJn1Br7UEBBowG9CD6XiPpoTW4ORCsXSEKAwdIimVL5T76dtSqA109HJ5jyKHdmIHTr6xRJNOyQf4dL3TOgSFCHHnFn23RAGHgEN/XwlraIDL+2ahFOoCXJ/dO85pyNhMvTzBXYO+KoOt6F5Xh2zSWXzxBlExzjYngimWK0D6GDDqYbQC0akNUtz/XZ6U/yZgkNPg9xHoeH1O/WGAvDvTd3Q9F7BUw9/2+y/KCqKtLVIG8auFzy4X4Y94BgkiS/gLU0GCBIAECdJP/hFgAPv6eKXxiXBZAAAAAElFTkSuQmCC" data-filename="logo.png" style="width: 200px;">
                                    </a>
                                    <p style="margin-top: 20px; font-family: "Proxima-nova","Helvetica Neue",Helvetica,Arial,sans-serif;">
                                        ' . $this->get('translator')->trans('CAREFULLY RESOURCE ASSETS') . '
                                    </p>
                                </div>
                            </div>
                            <p style="font-size: 12px; color: #666; margin:25px 0 0 0; line-height: 19px; font-family: "Proxima-nova","Helvetica Neue",Helvetica,Arial,sans-serif;">
                                ' . $this->get('translator')->trans('Copyright © 2015 Marketplace, All rights reserved.') . '
                            </p>
                            <br/>
                        </div>';

                                $notibuyer = new Notifications();
                                $notibuyer->setEmail($buyer->getEmail());
                                $notibuyer->setReplyEmail('');
                                $notibuyer->setTitle($sub);
                                $notibuyer->setContent($content);
                                $em->persist($notibuyer);
                                $em->flush();
                            }
                            

                            $sell = $em->getRepository('MarketDigitalBundle:Sell')->findOneBy(array("pp_id" => $prePay->getId()));
                            if (!$sell) {
                                $sell = new Sell();
                                $sell->setPrice($product->getPrice())
                                        ->setNetMoney($sellerMoney)
                                        ->setCreatedAt($a)
                                        ->setUpdatedAt($a)
                                        ->setDatas($prePay->getUserId())
                                        ->setPId($product->getId())
                                        ->setStatus(1)
                                        ->setPpId($prePay->getId())
                                        ->setTitle($product->getTitle())
                                        ->setUserId($product->getUsers()->getId());
                            } else {
                                $sell->setStatus(1);
                            }
                            $em->persist($sell);
                            $em->flush();
                        }
                    }
                }

                $em->getConnection()->commit();
            } catch (\Exception $e) {
                $em->getConnection()->rollback();
            }
            var_dump("Success: Got valid IPN data");
        } else {
            var_dump("Error: Got invalid IPN data");
        }
        die;
    }

}
