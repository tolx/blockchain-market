<?php

namespace Market\DigitalBundle\Entity;

/**
 * Reports
 */
class Reports
{
    /**
     * @var integer
     */
    private $id;

    /**
     * @var integer
     */
    private $users;

    /**
     * @var integer
     */
    private $products;

    /**
     * @var integer
     */
    private $sales;

    /**
     * @var float
     */
    private $paid;

    /**
     * @var float
     */
    private $revenues;

    /**
     * @var string
     */
    private $others;

    /**
     * @var integer
     */
    private $month_report;

    /**
     * @var integer
     */
    private $year_report;

    /**
     * @var integer
     */
    private $date_report;


    /**
     * Get id
     *
     * @return integer
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set users
     *
     * @param integer $users
     *
     * @return Reports
     */
    public function setUsers($users)
    {
        $this->users = $users;

        return $this;
    }

    /**
     * Get users
     *
     * @return integer
     */
    public function getUsers()
    {
        return $this->users;
    }

    /**
     * Set products
     *
     * @param integer $products
     *
     * @return Reports
     */
    public function setProducts($products)
    {
        $this->products = $products;

        return $this;
    }

    /**
     * Get products
     *
     * @return integer
     */
    public function getProducts()
    {
        return $this->products;
    }

    /**
     * Set sales
     *
     * @param integer $sales
     *
     * @return Reports
     */
    public function setSales($sales)
    {
        $this->sales = $sales;

        return $this;
    }

    /**
     * Get sales
     *
     * @return integer
     */
    public function getSales()
    {
        return $this->sales;
    }

    /**
     * Set paid
     *
     * @param float $paid
     *
     * @return Reports
     */
    public function setPaid($paid)
    {
        $this->paid = $paid;

        return $this;
    }

    /**
     * Get paid
     *
     * @return float
     */
    public function getPaid()
    {
        return $this->paid;
    }

    /**
     * Set revenues
     *
     * @param float $revenues
     *
     * @return Reports
     */
    public function setRevenues($revenues)
    {
        $this->revenues = $revenues;

        return $this;
    }

    /**
     * Get revenues
     *
     * @return float
     */
    public function getRevenues()
    {
        return $this->revenues;
    }

    /**
     * Set others
     *
     * @param string $others
     *
     * @return Reports
     */
    public function setOthers($others)
    {
        $this->others = $others;

        return $this;
    }

    /**
     * Get others
     *
     * @return string
     */
    public function getOthers()
    {
        return $this->others;
    }

    /**
     * Set monthReport
     *
     * @param integer $monthReport
     *
     * @return Reports
     */
    public function setMonthReport($monthReport)
    {
        $this->month_report = $monthReport;

        return $this;
    }

    /**
     * Get monthReport
     *
     * @return integer
     */
    public function getMonthReport()
    {
        return $this->month_report;
    }

    /**
     * Set yearReport
     *
     * @param integer $yearReport
     *
     * @return Reports
     */
    public function setYearReport($yearReport)
    {
        $this->year_report = $yearReport;

        return $this;
    }

    /**
     * Get yearReport
     *
     * @return integer
     */
    public function getYearReport()
    {
        return $this->year_report;
    }

    /**
     * Set dateReport
     *
     * @param integer $dateReport
     *
     * @return Reports
     */
    public function setDateReport($dateReport)
    {
        $this->date_report = $dateReport;

        return $this;
    }

    /**
     * Get dateReport
     *
     * @return integer
     */
    public function getDateReport()
    {
        return $this->date_report;
    }
}
