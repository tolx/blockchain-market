<?php

namespace Market\DigitalBundle\Entity;

/**
 * PaypalPayment
 */
class PaypalPayment
{
    /**
     * @var integer
     */
    private $id;

    /**
     * @var integer
     */
    private $p_id;

    /**
     * @var integer
     */
    private $user_id;

    /**
     * @var float
     */
    private $amount;

    /**
     * @var float
     */
    private $price1;

    /**
     * @var float
     */
    private $price2;

    /**
     * @var string
     */
    private $token;

    /**
     * @var string
     */
    private $datas;

    /**
     * @var string
     */
    private $payer_id;

    /**
     * @var integer
     */
    private $status;

    /**
     * @var \DateTime
     */
    private $createdAt;

    /**
     * @var \DateTime
     */
    private $updatedAt;


    /**
     * Get id
     *
     * @return integer
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set pId
     *
     * @param integer $pId
     *
     * @return PaypalPayment
     */
    public function setPId($pId)
    {
        $this->p_id = $pId;

        return $this;
    }

    /**
     * Get pId
     *
     * @return integer
     */
    public function getPId()
    {
        return $this->p_id;
    }

    /**
     * Set userId
     *
     * @param integer $userId
     *
     * @return PaypalPayment
     */
    public function setUserId($userId)
    {
        $this->user_id = $userId;

        return $this;
    }

    /**
     * Get userId
     *
     * @return integer
     */
    public function getUserId()
    {
        return $this->user_id;
    }

    /**
     * Set amount
     *
     * @param float $amount
     *
     * @return PaypalPayment
     */
    public function setAmount($amount)
    {
        $this->amount = $amount;

        return $this;
    }

    /**
     * Get amount
     *
     * @return float
     */
    public function getAmount()
    {
        return $this->amount;
    }

    /**
     * Set price1
     *
     * @param float $price1
     *
     * @return PaypalPayment
     */
    public function setPrice1($price1)
    {
        $this->price1 = $price1;

        return $this;
    }

    /**
     * Get price1
     *
     * @return float
     */
    public function getPrice1()
    {
        return $this->price1;
    }

    /**
     * Set price2
     *
     * @param float $price2
     *
     * @return PaypalPayment
     */
    public function setPrice2($price2)
    {
        $this->price2 = $price2;

        return $this;
    }

    /**
     * Get price2
     *
     * @return float
     */
    public function getPrice2()
    {
        return $this->price2;
    }

    /**
     * Set token
     *
     * @param string $token
     *
     * @return PaypalPayment
     */
    public function setToken($token)
    {
        $this->token = $token;

        return $this;
    }

    /**
     * Get token
     *
     * @return string
     */
    public function getToken()
    {
        return $this->token;
    }

    /**
     * Set datas
     *
     * @param string $datas
     *
     * @return PaypalPayment
     */
    public function setDatas($datas)
    {
        $this->datas = $datas;

        return $this;
    }

    /**
     * Get datas
     *
     * @return string
     */
    public function getDatas()
    {
        return $this->datas;
    }

    /**
     * Set payerId
     *
     * @param string $payerId
     *
     * @return PaypalPayment
     */
    public function setPayerId($payerId)
    {
        $this->payer_id = $payerId;

        return $this;
    }

    /**
     * Get payerId
     *
     * @return string
     */
    public function getPayerId()
    {
        return $this->payer_id;
    }

    /**
     * Set status
     *
     * @param integer $status
     *
     * @return PaypalPayment
     */
    public function setStatus($status)
    {
        $this->status = $status;

        return $this;
    }

    /**
     * Get status
     *
     * @return integer
     */
    public function getStatus()
    {
        return $this->status;
    }

    /**
     * Set createdAt
     *
     * @param \DateTime $createdAt
     *
     * @return PaypalPayment
     */
    public function setCreatedAt($createdAt)
    {
        $this->createdAt = $createdAt;

        return $this;
    }

    /**
     * Get createdAt
     *
     * @return \DateTime
     */
    public function getCreatedAt()
    {
        return $this->createdAt;
    }

    /**
     * Set updatedAt
     *
     * @param \DateTime $updatedAt
     *
     * @return PaypalPayment
     */
    public function setUpdatedAt($updatedAt)
    {
        $this->updatedAt = $updatedAt;

        return $this;
    }

    /**
     * Get updatedAt
     *
     * @return \DateTime
     */
    public function getUpdatedAt()
    {
        return $this->updatedAt;
    }
}

