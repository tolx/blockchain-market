<?php

namespace Market\DigitalBundle\Entity;

/**
 * Traffics
 */
class Traffics
{
    /**
     * @var integer
     */
    private $id;

    /**
     * @var integer
     */
    private $p_id;

    /**
     * @var string
     */
    private $sources;

    /**
     * @var string
     */
    private $location_code;

    /**
     * @var string
     */
    private $location_title;

    /**
     * @var integer
     */
    private $sale;

    /**
     * @var string
     */
    private $date_log;

    /**
     * @var \DateTime
     */
    private $createdAt;

    /**
     * @var \DateTime
     */
    private $updatedAt;


    /**
     * Get id
     *
     * @return integer
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set pId
     *
     * @param integer $pId
     *
     * @return Traffics
     */
    public function setPId($pId)
    {
        $this->p_id = $pId;

        return $this;
    }

    /**
     * Get pId
     *
     * @return integer
     */
    public function getPId()
    {
        return $this->p_id;
    }

    /**
     * Set sources
     *
     * @param string $sources
     *
     * @return Traffics
     */
    public function setSources($sources)
    {
        $this->sources = $sources;

        return $this;
    }

    /**
     * Get sources
     *
     * @return string
     */
    public function getSources()
    {
        return $this->sources;
    }

    /**
     * Set locationCode
     *
     * @param string $locationCode
     *
     * @return Traffics
     */
    public function setLocationCode($locationCode)
    {
        $this->location_code = $locationCode;

        return $this;
    }

    /**
     * Get locationCode
     *
     * @return string
     */
    public function getLocationCode()
    {
        return $this->location_code;
    }

    /**
     * Set locationTitle
     *
     * @param string $locationTitle
     *
     * @return Traffics
     */
    public function setLocationTitle($locationTitle)
    {
        $this->location_title = $locationTitle;

        return $this;
    }

    /**
     * Get locationTitle
     *
     * @return string
     */
    public function getLocationTitle()
    {
        return $this->location_title;
    }

    /**
     * Set sale
     *
     * @param integer $sale
     *
     * @return Traffics
     */
    public function setSale($sale)
    {
        $this->sale = $sale;

        return $this;
    }

    /**
     * Get sale
     *
     * @return integer
     */
    public function getSale()
    {
        return $this->sale;
    }

    /**
     * Set dateLog
     *
     * @param string $dateLog
     *
     * @return Traffics
     */
    public function setDateLog($dateLog)
    {
        $this->date_log = $dateLog;

        return $this;
    }

    /**
     * Get dateLog
     *
     * @return string
     */
    public function getDateLog()
    {
        return $this->date_log;
    }

    /**
     * Set createdAt
     *
     * @param \DateTime $createdAt
     *
     * @return Traffics
     */
    public function setCreatedAt($createdAt)
    {
        $this->createdAt = $createdAt;

        return $this;
    }

    /**
     * Get createdAt
     *
     * @return \DateTime
     */
    public function getCreatedAt()
    {
        return $this->createdAt;
    }

    /**
     * Set updatedAt
     *
     * @param \DateTime $updatedAt
     *
     * @return Traffics
     */
    public function setUpdatedAt($updatedAt)
    {
        $this->updatedAt = $updatedAt;

        return $this;
    }

    /**
     * Get updatedAt
     *
     * @return \DateTime
     */
    public function getUpdatedAt()
    {
        return $this->updatedAt;
    }
}
