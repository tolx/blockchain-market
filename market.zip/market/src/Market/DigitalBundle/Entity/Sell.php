<?php

namespace Market\DigitalBundle\Entity;

/**
 * Sell
 */
class Sell
{
    /**
     * @var integer
     */
    private $id;

    /**
     * @var integer
     */
    private $p_id;

    /**
     * @var integer
     */
    private $pp_id;

    /**
     * @var integer
     */
    private $user_id;

    /**
     * @var string
     */
    private $title;

    /**
     * @var string
     */
    private $datas;

    /**
     * @var float
     */
    private $price;

    /**
     * @var float
     */
    private $netMoney;

    /**
     * @var integer
     */
    private $status;

    /**
     * @var \DateTime
     */
    private $createdAt;

    /**
     * @var \DateTime
     */
    private $updatedAt;


    /**
     * Get id
     *
     * @return integer
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set pId
     *
     * @param integer $pId
     *
     * @return Sell
     */
    public function setPId($pId)
    {
        $this->p_id = $pId;

        return $this;
    }

    /**
     * Get pId
     *
     * @return integer
     */
    public function getPId()
    {
        return $this->p_id;
    }

    /**
     * Set ppId
     *
     * @param integer $ppId
     *
     * @return Sell
     */
    public function setPpId($ppId)
    {
        $this->pp_id = $ppId;

        return $this;
    }

    /**
     * Get ppId
     *
     * @return integer
     */
    public function getPpId()
    {
        return $this->pp_id;
    }

    /**
     * Set userId
     *
     * @param integer $userId
     *
     * @return Sell
     */
    public function setUserId($userId)
    {
        $this->user_id = $userId;

        return $this;
    }

    /**
     * Get userId
     *
     * @return integer
     */
    public function getUserId()
    {
        return $this->user_id;
    }

    /**
     * Set title
     *
     * @param string $title
     *
     * @return Sell
     */
    public function setTitle($title)
    {
        $this->title = $title;

        return $this;
    }

    /**
     * Get title
     *
     * @return string
     */
    public function getTitle()
    {
        return $this->title;
    }

    /**
     * Set datas
     *
     * @param string $datas
     *
     * @return Sell
     */
    public function setDatas($datas)
    {
        $this->datas = $datas;

        return $this;
    }

    /**
     * Get datas
     *
     * @return string
     */
    public function getDatas()
    {
        return $this->datas;
    }

    /**
     * Set price
     *
     * @param float $price
     *
     * @return Sell
     */
    public function setPrice($price)
    {
        $this->price = $price;

        return $this;
    }

    /**
     * Get price
     *
     * @return float
     */
    public function getPrice()
    {
        return $this->price;
    }

    /**
     * Set netMoney
     *
     * @param float $netMoney
     *
     * @return Sell
     */
    public function setNetMoney($netMoney)
    {
        $this->netMoney = $netMoney;

        return $this;
    }

    /**
     * Get netMoney
     *
     * @return float
     */
    public function getNetMoney()
    {
        return $this->netMoney;
    }

    /**
     * Set status
     *
     * @param integer $status
     *
     * @return Sell
     */
    public function setStatus($status)
    {
        $this->status = $status;

        return $this;
    }

    /**
     * Get status
     *
     * @return integer
     */
    public function getStatus()
    {
        return $this->status;
    }

    /**
     * Set createdAt
     *
     * @param \DateTime $createdAt
     *
     * @return Sell
     */
    public function setCreatedAt($createdAt)
    {
        $this->createdAt = $createdAt;

        return $this;
    }

    /**
     * Get createdAt
     *
     * @return \DateTime
     */
    public function getCreatedAt()
    {
        return $this->createdAt;
    }

    /**
     * Set updatedAt
     *
     * @param \DateTime $updatedAt
     *
     * @return Sell
     */
    public function setUpdatedAt($updatedAt)
    {
        $this->updatedAt = $updatedAt;

        return $this;
    }

    /**
     * Get updatedAt
     *
     * @return \DateTime
     */
    public function getUpdatedAt()
    {
        return $this->updatedAt;
    }
}
