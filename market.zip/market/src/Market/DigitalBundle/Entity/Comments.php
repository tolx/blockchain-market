<?php

namespace Market\DigitalBundle\Entity;

/**
 * Comments
 */
class Comments
{
    /**
     * @var integer
     */
    private $id;

    /**
     * @var integer
     */
    private $u_id;

    /**
     * @var integer
     */
    private $p_id;

    /**
     * @var integer
     */
    private $c_id;

    /**
     * @var integer
     */
    private $spam;

    /**
     * @var string
     */
    private $details;

    /**
     * @var \DateTime
     */
    private $createdAt;

    /**
     * @var \DateTime
     */
    private $updatedAt;

    /**
     * @var \Market\DigitalBundle\Entity\Users
     */
    private $Users;


    /**
     * Get id
     *
     * @return integer
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set uId
     *
     * @param integer $uId
     *
     * @return Comments
     */
    public function setUId($uId)
    {
        $this->u_id = $uId;

        return $this;
    }

    /**
     * Get uId
     *
     * @return integer
     */
    public function getUId()
    {
        return $this->u_id;
    }

    /**
     * Set pId
     *
     * @param integer $pId
     *
     * @return Comments
     */
    public function setPId($pId)
    {
        $this->p_id = $pId;

        return $this;
    }

    /**
     * Get pId
     *
     * @return integer
     */
    public function getPId()
    {
        return $this->p_id;
    }

    /**
     * Set cId
     *
     * @param integer $cId
     *
     * @return Comments
     */
    public function setCId($cId)
    {
        $this->c_id = $cId;

        return $this;
    }

    /**
     * Get cId
     *
     * @return integer
     */
    public function getCId()
    {
        return $this->c_id;
    }

    /**
     * Set spam
     *
     * @param integer $spam
     *
     * @return Comments
     */
    public function setSpam($spam)
    {
        $this->spam = $spam;

        return $this;
    }

    /**
     * Get spam
     *
     * @return integer
     */
    public function getSpam()
    {
        return $this->spam;
    }

    /**
     * Set details
     *
     * @param string $details
     *
     * @return Comments
     */
    public function setDetails($details)
    {
        $this->details = $details;

        return $this;
    }

    /**
     * Get details
     *
     * @return string
     */
    public function getDetails()
    {
        return $this->details;
    }

    /**
     * Set createdAt
     *
     * @param \DateTime $createdAt
     *
     * @return Comments
     */
    public function setCreatedAt($createdAt)
    {
        $this->createdAt = $createdAt;

        return $this;
    }

    /**
     * Get createdAt
     *
     * @return \DateTime
     */
    public function getCreatedAt()
    {
        return $this->createdAt;
    }

    /**
     * Set updatedAt
     *
     * @param \DateTime $updatedAt
     *
     * @return Comments
     */
    public function setUpdatedAt($updatedAt)
    {
        $this->updatedAt = $updatedAt;

        return $this;
    }

    /**
     * Get updatedAt
     *
     * @return \DateTime
     */
    public function getUpdatedAt()
    {
        return $this->updatedAt;
    }

    /**
     * Set users
     *
     * @param \Market\DigitalBundle\Entity\Users $users
     *
     * @return Comments
     */
    public function setUsers(\Market\DigitalBundle\Entity\Users $users = null)
    {
        $this->Users = $users;

        return $this;
    }

    /**
     * Get users
     *
     * @return \Market\DigitalBundle\Entity\Users
     */
    public function getUsers()
    {
        return $this->Users;
    }
}
