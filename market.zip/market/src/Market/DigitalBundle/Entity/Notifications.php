<?php

namespace Market\DigitalBundle\Entity;

/**
 * Notifications
 */
class Notifications
{
    /**
     * @var integer
     */
    private $id;

    /**
     * @var string
     */
    private $email;

    /**
     * @var string
     */
    private $reply_email;

    /**
     * @var string
     */
    private $title;

    /**
     * @var string
     */
    private $content;


    /**
     * Get id
     *
     * @return integer
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set email
     *
     * @param string $email
     *
     * @return Notifications
     */
    public function setEmail($email)
    {
        $this->email = $email;

        return $this;
    }

    /**
     * Get email
     *
     * @return string
     */
    public function getEmail()
    {
        return $this->email;
    }

    /**
     * Set replyEmail
     *
     * @param string $replyEmail
     *
     * @return Notifications
     */
    public function setReplyEmail($replyEmail)
    {
        $this->reply_email = $replyEmail;

        return $this;
    }

    /**
     * Get replyEmail
     *
     * @return string
     */
    public function getReplyEmail()
    {
        return $this->reply_email;
    }

    /**
     * Set title
     *
     * @param string $title
     *
     * @return Notifications
     */
    public function setTitle($title)
    {
        $this->title = $title;

        return $this;
    }

    /**
     * Get title
     *
     * @return string
     */
    public function getTitle()
    {
        return $this->title;
    }

    /**
     * Set content
     *
     * @param string $content
     *
     * @return Notifications
     */
    public function setContent($content)
    {
        $this->content = $content;

        return $this;
    }

    /**
     * Get content
     *
     * @return string
     */
    public function getContent()
    {
        return $this->content;
    }
}
