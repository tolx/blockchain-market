<?php

namespace Market\DigitalBundle\Entity;

/**
 * Blogs
 */
class Blogs
{
    /**
     * @var integer
     */
    private $id;

    /**
     * @var integer
     */
    private $u_id;

    /**
     * @var string
     */
    private $title;

    /**
     * @var string
     */
    private $short_details;

    /**
     * @var string
     */
    private $details;

    /**
     * @var integer
     */
    private $views;

    /**
     * @var integer
     */
    private $active;

    /**
     * @var \DateTime
     */
    private $createdAt;

    /**
     * @var \DateTime
     */
    private $updatedAt;

    /**
     * @var \Market\DigitalBundle\Entity\Users
     */
    private $Users;


    /**
     * Get id
     *
     * @return integer
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set uId
     *
     * @param integer $uId
     *
     * @return Blogs
     */
    public function setUId($uId)
    {
        $this->u_id = $uId;

        return $this;
    }

    /**
     * Get uId
     *
     * @return integer
     */
    public function getUId()
    {
        return $this->u_id;
    }

    /**
     * Set title
     *
     * @param string $title
     *
     * @return Blogs
     */
    public function setTitle($title)
    {
        $this->title = $title;

        return $this;
    }

    /**
     * Get title
     *
     * @return string
     */
    public function getTitle()
    {
        return $this->title;
    }

    /**
     * Set shortDetails
     *
     * @param string $shortDetails
     *
     * @return Blogs
     */
    public function setShortDetails($shortDetails)
    {
        $this->short_details = $shortDetails;

        return $this;
    }

    /**
     * Get shortDetails
     *
     * @return string
     */
    public function getShortDetails()
    {
        return $this->short_details;
    }

    /**
     * Set details
     *
     * @param string $details
     *
     * @return Blogs
     */
    public function setDetails($details)
    {
        $this->details = $details;

        return $this;
    }

    /**
     * Get details
     *
     * @return string
     */
    public function getDetails()
    {
        return $this->details;
    }

    /**
     * Set views
     *
     * @param integer $views
     *
     * @return Blogs
     */
    public function setViews($views)
    {
        $this->views = $views;

        return $this;
    }

    /**
     * Get views
     *
     * @return integer
     */
    public function getViews()
    {
        return $this->views;
    }

    /**
     * Set active
     *
     * @param integer $active
     *
     * @return Blogs
     */
    public function setActive($active)
    {
        $this->active = $active;

        return $this;
    }

    /**
     * Get active
     *
     * @return integer
     */
    public function getActive()
    {
        return $this->active;
    }

    /**
     * Set createdAt
     *
     * @param \DateTime $createdAt
     *
     * @return Blogs
     */
    public function setCreatedAt($createdAt)
    {
        $this->createdAt = $createdAt;

        return $this;
    }

    /**
     * Get createdAt
     *
     * @return \DateTime
     */
    public function getCreatedAt()
    {
        return $this->createdAt;
    }

    /**
     * Set updatedAt
     *
     * @param \DateTime $updatedAt
     *
     * @return Blogs
     */
    public function setUpdatedAt($updatedAt)
    {
        $this->updatedAt = $updatedAt;

        return $this;
    }

    /**
     * Get updatedAt
     *
     * @return \DateTime
     */
    public function getUpdatedAt()
    {
        return $this->updatedAt;
    }

    /**
     * Set users
     *
     * @param \Market\DigitalBundle\Entity\Users $users
     *
     * @return Blogs
     */
    public function setUsers(\Market\DigitalBundle\Entity\Users $users = null)
    {
        $this->Users = $users;

        return $this;
    }

    /**
     * Get users
     *
     * @return \Market\DigitalBundle\Entity\Users
     */
    public function getUsers()
    {
        return $this->Users;
    }
}
