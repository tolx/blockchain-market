<?php

namespace Market\DigitalBundle\Entity;

/**
 * Products
 */
class Products
{
    /**
     * @var integer
     */
    private $id;

    /**
     * @var integer
     */
    private $u_id;

    /**
     * @var integer
     */
    private $c_id;

    /**
     * @var string
     */
    private $title;

    /**
     * @var string
     */
    private $details;

    /**
     * @var string
     */
    private $image;

    /**
     * @var string
     */
    private $preview;

    /**
     * @var string
     */
    private $main_file;

    /**
     * @var string
     */
    private $tags;

    /**
     * @var integer
     */
    private $price;

    /**
     * @var integer
     */
    private $price_plus;

    /**
     * @var integer
     */
    private $total_sale;

    /**
     * @var integer
     */
    private $total_comment;

    /**
     * @var integer
     */
    private $total_rate;

    /**
     * @var string
     */
    private $average_rate;

    /**
     * @var integer
     */
    private $views;

    /**
     * @var integer
     */
    private $feature;

    /**
     * @var integer
     */
    private $trend;

    /**
     * @var integer
     */
    private $active;

    /**
     * @var \DateTime
     */
    private $createdAt;

    /**
     * @var \DateTime
     */
    private $updatedAt;

    /**
     * @var \Market\DigitalBundle\Entity\Users
     */
    private $Users;

    /**
     * @var \Market\DigitalBundle\Entity\Categories
     */
    private $Categories;


    /**
     * Get id
     *
     * @return integer
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set uId
     *
     * @param integer $uId
     *
     * @return Products
     */
    public function setUId($uId)
    {
        $this->u_id = $uId;

        return $this;
    }

    /**
     * Get uId
     *
     * @return integer
     */
    public function getUId()
    {
        return $this->u_id;
    }

    /**
     * Set cId
     *
     * @param integer $cId
     *
     * @return Products
     */
    public function setCId($cId)
    {
        $this->c_id = $cId;

        return $this;
    }

    /**
     * Get cId
     *
     * @return integer
     */
    public function getCId()
    {
        return $this->c_id;
    }

    /**
     * Set title
     *
     * @param string $title
     *
     * @return Products
     */
    public function setTitle($title)
    {
        $this->title = $title;

        return $this;
    }

    /**
     * Get title
     *
     * @return string
     */
    public function getTitle()
    {
        return $this->title;
    }

    /**
     * Set details
     *
     * @param string $details
     *
     * @return Products
     */
    public function setDetails($details)
    {
        $this->details = $details;

        return $this;
    }

    /**
     * Get details
     *
     * @return string
     */
    public function getDetails()
    {
        return $this->details;
    }

    /**
     * Set image
     *
     * @param string $image
     *
     * @return Products
     */
    public function setImage($image)
    {
        $this->image = $image;

        return $this;
    }

    /**
     * Get image
     *
     * @return string
     */
    public function getImage()
    {
        return $this->image;
    }

    /**
     * Set preview
     *
     * @param string $preview
     *
     * @return Products
     */
    public function setPreview($preview)
    {
        $this->preview = $preview;

        return $this;
    }

    /**
     * Get preview
     *
     * @return string
     */
    public function getPreview()
    {
        return $this->preview;
    }

    /**
     * Set mainFile
     *
     * @param string $mainFile
     *
     * @return Products
     */
    public function setMainFile($mainFile)
    {
        $this->main_file = $mainFile;

        return $this;
    }

    /**
     * Get mainFile
     *
     * @return string
     */
    public function getMainFile()
    {
        return $this->main_file;
    }

    /**
     * Set tags
     *
     * @param string $tags
     *
     * @return Products
     */
    public function setTags($tags)
    {
        $this->tags = $tags;

        return $this;
    }

    /**
     * Get tags
     *
     * @return string
     */
    public function getTags()
    {
        return $this->tags;
    }

    /**
     * Set price
     *
     * @param integer $price
     *
     * @return Products
     */
    public function setPrice($price)
    {
        $this->price = $price;

        return $this;
    }

    /**
     * Get price
     *
     * @return integer
     */
    public function getPrice()
    {
        return $this->price;
    }

    /**
     * Set pricePlus
     *
     * @param integer $pricePlus
     *
     * @return Products
     */
    public function setPricePlus($pricePlus)
    {
        $this->price_plus = $pricePlus;

        return $this;
    }

    /**
     * Get pricePlus
     *
     * @return integer
     */
    public function getPricePlus()
    {
        return $this->price_plus;
    }

    /**
     * Set totalSale
     *
     * @param integer $totalSale
     *
     * @return Products
     */
    public function setTotalSale($totalSale)
    {
        $this->total_sale = $totalSale;

        return $this;
    }

    /**
     * Get totalSale
     *
     * @return integer
     */
    public function getTotalSale()
    {
        return $this->total_sale;
    }

    /**
     * Set totalComment
     *
     * @param integer $totalComment
     *
     * @return Products
     */
    public function setTotalComment($totalComment)
    {
        $this->total_comment = $totalComment;

        return $this;
    }

    /**
     * Get totalComment
     *
     * @return integer
     */
    public function getTotalComment()
    {
        return $this->total_comment;
    }

    /**
     * Set totalRate
     *
     * @param integer $totalRate
     *
     * @return Products
     */
    public function setTotalRate($totalRate)
    {
        $this->total_rate = $totalRate;

        return $this;
    }

    /**
     * Get totalRate
     *
     * @return integer
     */
    public function getTotalRate()
    {
        return $this->total_rate;
    }

    /**
     * Set averageRate
     *
     * @param string $averageRate
     *
     * @return Products
     */
    public function setAverageRate($averageRate)
    {
        $this->average_rate = $averageRate;

        return $this;
    }

    /**
     * Get averageRate
     *
     * @return string
     */
    public function getAverageRate()
    {
        return $this->average_rate;
    }

    /**
     * Set views
     *
     * @param integer $views
     *
     * @return Products
     */
    public function setViews($views)
    {
        $this->views = $views;

        return $this;
    }

    /**
     * Get views
     *
     * @return integer
     */
    public function getViews()
    {
        return $this->views;
    }

    /**
     * Set feature
     *
     * @param integer $feature
     *
     * @return Products
     */
    public function setFeature($feature)
    {
        $this->feature = $feature;

        return $this;
    }

    /**
     * Get feature
     *
     * @return integer
     */
    public function getFeature()
    {
        return $this->feature;
    }

    /**
     * Set trend
     *
     * @param integer $trend
     *
     * @return Products
     */
    public function setTrend($trend)
    {
        $this->trend = $trend;

        return $this;
    }

    /**
     * Get trend
     *
     * @return integer
     */
    public function getTrend()
    {
        return $this->trend;
    }

    /**
     * Set active
     *
     * @param integer $active
     *
     * @return Products
     */
    public function setActive($active)
    {
        $this->active = $active;

        return $this;
    }

    /**
     * Get active
     *
     * @return integer
     */
    public function getActive()
    {
        return $this->active;
    }

    /**
     * Set createdAt
     *
     * @param \DateTime $createdAt
     *
     * @return Products
     */
    public function setCreatedAt($createdAt)
    {
        $this->createdAt = $createdAt;

        return $this;
    }

    /**
     * Get createdAt
     *
     * @return \DateTime
     */
    public function getCreatedAt()
    {
        return $this->createdAt;
    }

    /**
     * Set updatedAt
     *
     * @param \DateTime $updatedAt
     *
     * @return Products
     */
    public function setUpdatedAt($updatedAt)
    {
        $this->updatedAt = $updatedAt;

        return $this;
    }

    /**
     * Get updatedAt
     *
     * @return \DateTime
     */
    public function getUpdatedAt()
    {
        return $this->updatedAt;
    }

    /**
     * Set users
     *
     * @param \Market\DigitalBundle\Entity\Users $users
     *
     * @return Products
     */
    public function setUsers(\Market\DigitalBundle\Entity\Users $users = null)
    {
        $this->Users = $users;

        return $this;
    }

    /**
     * Get users
     *
     * @return \Market\DigitalBundle\Entity\Users
     */
    public function getUsers()
    {
        return $this->Users;
    }

    /**
     * Set categories
     *
     * @param \Market\DigitalBundle\Entity\Categories $categories
     *
     * @return Products
     */
    public function setCategories(\Market\DigitalBundle\Entity\Categories $categories = null)
    {
        $this->Categories = $categories;

        return $this;
    }

    /**
     * Get categories
     *
     * @return \Market\DigitalBundle\Entity\Categories
     */
    public function getCategories()
    {
        return $this->Categories;
    }
}
