<?php

namespace Market\DigitalBundle\Entity;

/**
 * Users
 */
class Users
{
    /**
     * @var integer
     */
    private $id;

    /**
     * @var string
     */
    private $username;

    /**
     * @var string
     */
    private $password;

    /**
     * @var string
     */
    private $fullname;

    /**
     * @var string
     */
    private $email;

    /**
     * @var string
     */
    private $email_nganluong;

    /**
     * @var string
     */
    private $email_baokim;

    /**
     * @var string
     */
    private $email_paypal;

    /**
     * @var string
     */
    private $add1;

    /**
     * @var string
     */
    private $city;

    /**
     * @var string
     */
    private $country;

    /**
     * @var string
     */
    private $avatar;

    /**
     * @var string
     */
    private $token_facebook;

    /**
     * @var string
     */
    private $cover;

    /**
     * @var string
     */
    private $facebook;

    /**
     * @var string
     */
    private $twitter;

    /**
     * @var string
     */
    private $homepage;

    /**
     * @var string
     */
    private $bio;

    /**
     * @var float
     */
    private $earned;

    /**
     * @var float
     */
    private $saled;

    /**
     * @var integer
     */
    private $total_file;

    /**
     * @var string
     */
    private $email_subject;

    /**
     * @var string
     */
    private $email_content;

    /**
     * @var integer
     */
    private $supper;

    /**
     * @var integer
     */
    private $active;

    /**
     * @var \DateTime
     */
    private $createdAt;

    /**
     * @var \DateTime
     */
    private $updatedAt;


    /**
     * Get id
     *
     * @return integer
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set username
     *
     * @param string $username
     *
     * @return Users
     */
    public function setUsername($username)
    {
        $this->username = $username;

        return $this;
    }

    /**
     * Get username
     *
     * @return string
     */
    public function getUsername()
    {
        return $this->username;
    }

    /**
     * Set password
     *
     * @param string $password
     *
     * @return Users
     */
    public function setPassword($password)
    {
        $this->password = $password;

        return $this;
    }

    /**
     * Get password
     *
     * @return string
     */
    public function getPassword()
    {
        return $this->password;
    }

    /**
     * Set fullname
     *
     * @param string $fullname
     *
     * @return Users
     */
    public function setFullname($fullname)
    {
        $this->fullname = $fullname;

        return $this;
    }

    /**
     * Get fullname
     *
     * @return string
     */
    public function getFullname()
    {
        return $this->fullname;
    }

    /**
     * Set email
     *
     * @param string $email
     *
     * @return Users
     */
    public function setEmail($email)
    {
        $this->email = $email;

        return $this;
    }

    /**
     * Get email
     *
     * @return string
     */
    public function getEmail()
    {
        return $this->email;
    }

    /**
     * Set emailNganluong
     *
     * @param string $emailNganluong
     *
     * @return Users
     */
    public function setEmailNganluong($emailNganluong)
    {
        $this->email_nganluong = $emailNganluong;

        return $this;
    }

    /**
     * Get emailNganluong
     *
     * @return string
     */
    public function getEmailNganluong()
    {
        return $this->email_nganluong;
    }

    /**
     * Set emailBaokim
     *
     * @param string $emailBaokim
     *
     * @return Users
     */
    public function setEmailBaokim($emailBaokim)
    {
        $this->email_baokim = $emailBaokim;

        return $this;
    }

    /**
     * Get emailBaokim
     *
     * @return string
     */
    public function getEmailBaokim()
    {
        return $this->email_baokim;
    }

    /**
     * Set emailPaypal
     *
     * @param string $emailPaypal
     *
     * @return Users
     */
    public function setEmailPaypal($emailPaypal)
    {
        $this->email_paypal = $emailPaypal;

        return $this;
    }

    /**
     * Get emailPaypal
     *
     * @return string
     */
    public function getEmailPaypal()
    {
        return $this->email_paypal;
    }

    /**
     * Set add1
     *
     * @param string $add1
     *
     * @return Users
     */
    public function setAdd1($add1)
    {
        $this->add1 = $add1;

        return $this;
    }

    /**
     * Get add1
     *
     * @return string
     */
    public function getAdd1()
    {
        return $this->add1;
    }

    /**
     * Set city
     *
     * @param string $city
     *
     * @return Users
     */
    public function setCity($city)
    {
        $this->city = $city;

        return $this;
    }

    /**
     * Get city
     *
     * @return string
     */
    public function getCity()
    {
        return $this->city;
    }

    /**
     * Set country
     *
     * @param string $country
     *
     * @return Users
     */
    public function setCountry($country)
    {
        $this->country = $country;

        return $this;
    }

    /**
     * Get country
     *
     * @return string
     */
    public function getCountry()
    {
        return $this->country;
    }

    /**
     * Set avatar
     *
     * @param string $avatar
     *
     * @return Users
     */
    public function setAvatar($avatar)
    {
        $this->avatar = $avatar;

        return $this;
    }

    /**
     * Get avatar
     *
     * @return string
     */
    public function getAvatar()
    {
        return $this->avatar;
    }

    /**
     * Set tokenFacebook
     *
     * @param string $tokenFacebook
     *
     * @return Users
     */
    public function setTokenFacebook($tokenFacebook)
    {
        $this->token_facebook = $tokenFacebook;

        return $this;
    }

    /**
     * Get tokenFacebook
     *
     * @return string
     */
    public function getTokenFacebook()
    {
        return $this->token_facebook;
    }

    /**
     * Set cover
     *
     * @param string $cover
     *
     * @return Users
     */
    public function setCover($cover)
    {
        $this->cover = $cover;

        return $this;
    }

    /**
     * Get cover
     *
     * @return string
     */
    public function getCover()
    {
        return $this->cover;
    }

    /**
     * Set facebook
     *
     * @param string $facebook
     *
     * @return Users
     */
    public function setFacebook($facebook)
    {
        $this->facebook = $facebook;

        return $this;
    }

    /**
     * Get facebook
     *
     * @return string
     */
    public function getFacebook()
    {
        return $this->facebook;
    }

    /**
     * Set twitter
     *
     * @param string $twitter
     *
     * @return Users
     */
    public function setTwitter($twitter)
    {
        $this->twitter = $twitter;

        return $this;
    }

    /**
     * Get twitter
     *
     * @return string
     */
    public function getTwitter()
    {
        return $this->twitter;
    }

    /**
     * Set homepage
     *
     * @param string $homepage
     *
     * @return Users
     */
    public function setHomepage($homepage)
    {
        $this->homepage = $homepage;

        return $this;
    }

    /**
     * Get homepage
     *
     * @return string
     */
    public function getHomepage()
    {
        return $this->homepage;
    }

    /**
     * Set bio
     *
     * @param string $bio
     *
     * @return Users
     */
    public function setBio($bio)
    {
        $this->bio = $bio;

        return $this;
    }

    /**
     * Get bio
     *
     * @return string
     */
    public function getBio()
    {
        return $this->bio;
    }

    /**
     * Set earned
     *
     * @param float $earned
     *
     * @return Users
     */
    public function setEarned($earned)
    {
        $this->earned = $earned;

        return $this;
    }

    /**
     * Get earned
     *
     * @return float
     */
    public function getEarned()
    {
        return $this->earned;
    }

    /**
     * Set saled
     *
     * @param float $saled
     *
     * @return Users
     */
    public function setSaled($saled)
    {
        $this->saled = $saled;

        return $this;
    }

    /**
     * Get saled
     *
     * @return float
     */
    public function getSaled()
    {
        return $this->saled;
    }

    /**
     * Set totalFile
     *
     * @param integer $totalFile
     *
     * @return Users
     */
    public function setTotalFile($totalFile)
    {
        $this->total_file = $totalFile;

        return $this;
    }

    /**
     * Get totalFile
     *
     * @return integer
     */
    public function getTotalFile()
    {
        return $this->total_file;
    }

    /**
     * Set emailSubject
     *
     * @param string $emailSubject
     *
     * @return Users
     */
    public function setEmailSubject($emailSubject)
    {
        $this->email_subject = $emailSubject;

        return $this;
    }

    /**
     * Get emailSubject
     *
     * @return string
     */
    public function getEmailSubject()
    {
        return $this->email_subject;
    }

    /**
     * Set emailContent
     *
     * @param string $emailContent
     *
     * @return Users
     */
    public function setEmailContent($emailContent)
    {
        $this->email_content = $emailContent;

        return $this;
    }

    /**
     * Get emailContent
     *
     * @return string
     */
    public function getEmailContent()
    {
        return $this->email_content;
    }

    /**
     * Set supper
     *
     * @param integer $supper
     *
     * @return Users
     */
    public function setSupper($supper)
    {
        $this->supper = $supper;

        return $this;
    }

    /**
     * Get supper
     *
     * @return integer
     */
    public function getSupper()
    {
        return $this->supper;
    }

    /**
     * Set active
     *
     * @param integer $active
     *
     * @return Users
     */
    public function setActive($active)
    {
        $this->active = $active;

        return $this;
    }

    /**
     * Get active
     *
     * @return integer
     */
    public function getActive()
    {
        return $this->active;
    }

    /**
     * Set createdAt
     *
     * @param \DateTime $createdAt
     *
     * @return Users
     */
    public function setCreatedAt($createdAt)
    {
        $this->createdAt = $createdAt;

        return $this;
    }

    /**
     * Get createdAt
     *
     * @return \DateTime
     */
    public function getCreatedAt()
    {
        return $this->createdAt;
    }

    /**
     * Set updatedAt
     *
     * @param \DateTime $updatedAt
     *
     * @return Users
     */
    public function setUpdatedAt($updatedAt)
    {
        $this->updatedAt = $updatedAt;

        return $this;
    }

    /**
     * Get updatedAt
     *
     * @return \DateTime
     */
    public function getUpdatedAt()
    {
        return $this->updatedAt;
    }
}
