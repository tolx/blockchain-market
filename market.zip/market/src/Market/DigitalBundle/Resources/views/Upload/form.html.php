<?php
$view->extend('MarketDigitalBundle::layout_user.html.php');
?>
<div class="col-md-9">
    <form class="form-horizontal" method="POST" autocomplete="off" action="">
        <div class="panel panel-blue">
            <div class="panel-heading">
                <h2 class="panel-title"><?php echo $view['translator']->trans('Product'); ?> <?php
                    if ($product) {
                        echo ": " . $product->getTitle();
                    }
                    ?></h2>
            </div>
            <div class="panel-body">
                <div class="form-group">
                    <div class="col-sm-12">
                        <div id="uploadMsg" class="alert alert-info">
                            <?php echo $view['translator']->trans("Upload main file (.zip) max 300MB, Hero image file (.png) size 750x500px"); ?>
                        </div>

                        <?php if ($uploadFail) { ?>
                            <?php if (isset($uploadFail[0])) { ?>
                                <div class="alert alert-dismissable alert-danger">
                                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                                    <strong><?php echo $view['translator']->trans("Error!"); ?></strong>
                                    <?php echo $view['translator']->trans("Preview Image type .png and size 750x500px"); ?>
                                </div>
                            <?php } ?>
                            <?php if (isset($uploadFail[1])) { ?>
                                <div class="alert alert-dismissable alert-danger">
                                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                                    <strong><?php echo $view['translator']->trans("Error!"); ?></strong>
                                    <?php echo $view['translator']->trans("Main File type .zip and max size 300MB"); ?>
                                </div>
                            <?php } ?>
                        <?php } ?>
                        <?php if ($error) { ?>
                            <div class="alert alert-dismissable alert-danger">
                                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                                <strong><?php echo $view['translator']->trans("Error!"); ?></strong>
                                <?php echo $view['translator']->trans("Please try again."); ?>
                            </div>
                        <?php } ?>

                        <span class="btn btn-success fileinput-button">
                            <i class="glyphicon glyphicon-plus"></i>
                            <span><?php echo $view['translator']->trans("Upload files..."); ?></span>
                            <input id="fileupload" type="file" name="files[]" multiple>
                        </span>

                        <br>
                        <br>

                        <div id="progress" class="progress">
                            <div class="progress-bar progress-bar-warning progress-bar-striped"></div>
                        </div>
                        <div id="files" class="files"></div>
                        <hr>
                    </div>
                </div>

                <div class="form-group">
                    <div class="col-sm-12">
                        <label><?php echo $view['translator']->trans("Product Name"); ?></label>
                        <input maxlength="100" type="text" autocomplete="off" class="form-control font14" id="title" name="title" required placeholder="<?php echo $view['translator']->trans("Product Name"); ?>" value="<?php
                        if ($product) {
                            echo $product->getTitle();
                        }
                        ?>">
                    </div>
                </div>

                <div class="form-group">
                    <div class="col-sm-12">

                        <label><?php echo $view['translator']->trans("Hero Image"); ?></label>
                        <?php
                        if ($product) {
                            ?>
                            <img src="<?php echo $view->escape('/uploads/items/'); ?><?php echo $product->getImage(); ?>" class="img-rounded" style="display: table; padding: 10px 0px; width: 200px; height: auto;">
                        <?php } ?>
                        <select name="heroImage" id="heroImage" class="form-control dataFile">
                            <option value="<?php
                            if ($product) {
                                echo $product->getImage();
                            }
                            ?>" selected="selected">---</option>
                                    <?php
                                    if ($fileUpload) {
                                        foreach ($fileUpload as $key => $value) {
                                            ?>
                                    <option value="<?php echo $key; ?>"><?php echo $value; ?></option>
                                    <?php
                                }
                            }
                            ?>
                        </select>
                    </div>
                </div>


                <div class="form-group">
                    <div class="col-sm-12">
                        <label><?php echo $view['translator']->trans("Product File"); ?></label>
                        <?php
                        if ($product) {
                            $urlDownload = $view['router']->generate('_download', array('id' => $product->getId(), 'title' => md5(sha1(Market\DigitalBundle\System::_reString($product->getTitle())))), true);
                            ?>
                            <a target="_blank" href="<?php echo $urlDownload; ?>" style="width: 100%; color: red; display: table; padding: 10px 0px; height: auto;"><?php echo Market\DigitalBundle\System::_reString($product->getTitle()) . ".zip"; ?></a>
                        <?php } ?>
                        <select name="mainFile" id="mainFile" class="form-control dataFile">
                            <option value="<?php
                            if ($product) {
                                echo $product->getMainFile();
                            }
                            ?>" selected="selected">---</option>
                                    <?php
                                    if ($fileUpload) {
                                        foreach ($fileUpload as $key => $value) {
                                            ?>
                                    <option value="<?php echo $key; ?>"><?php echo $value; ?></option>
                                    <?php
                                }
                            }
                            ?>
                        </select>
                    </div>
                </div>


                <div class="form-group">
                    <div class="col-sm-12">
                        <label><?php echo $view['translator']->trans("Category"); ?></label>
                        <select name="category" id="category" class="form-control">
                            <option value="" selected="selected">---</option>
                            <?php
                            if ($category) {
                                foreach ($category as $key => $value) {
                                    ?>
                                    <option <?php
                                    if ($product && $product->getCId() == $value->getId()) {
                                        echo 'selected="selected"';
                                    }
                                    ?> value="<?php echo $value->getId(); ?>"><?php echo $value->getTitle(); ?></option>
                                        <?php
                                    }
                                }
                                ?>
                        </select>
                    </div>
                </div>


                <div class="form-group">
                    <div class="col-sm-12">
                        <label><?php echo $view['translator']->trans("Product Detail"); ?></label>
                        <textarea class="form-control summernote" name="details" rows="12"><?php
                            if ($product) {
                                echo $product->getDetails();
                            }
                            ?></textarea>
                    </div>
                </div>


                <div class="form-group">
                    <div class="col-sm-12">
                        <label><?php echo $view['translator']->trans("Price"); ?></label>
                        <div class="input-group">
                            <span class="input-group-addon" id="basic-addon1"><i class="fa fa-dollar"></i></span>
                            <input type="text" maxlength="5" aria-describedby="basic-addon1" autocomplete="off" class="form-control font14" id="price" name="price" required placeholder="<?php echo $view['translator']->trans("0.00"); ?>" value="<?php
                            if ($product) {
                                echo $product->getPrice();
                            }
                            ?>">
                        </div>
                    </div>
                </div>


                <div class="form-group">
                    <div class="col-sm-12">
                        <label><?php echo $view['translator']->trans("Active"); ?></label>
                        <div class="radio">
                            <label>
                                <input type="radio" name="active" value="0" <?php
                                if ($product && $product->getActive() == 0) {
                                    echo 'checked';
                                }
                                ?>><?php echo $view['translator']->trans("No"); ?>
                            </label>
                        </div>
                        <div class="radio">
                            <label>
                                <input type="radio" name="active" value="1" <?php
                                if ($product && $product->getActive() == 1) {
                                    echo 'checked';
                                }
                                if (!$product) {
                                    echo "checked";
                                }
                                ?>><?php echo $view['translator']->trans("Yes"); ?>
                            </label>
                        </div>
                    </div>
                </div>
            </div>
            <div class="panel-footer bg-white">
                <button type="submit" class="btn btn-danger btn-lg font14"><?php echo $view['translator']->trans("Submit"); ?></button>
            </div>
        </div>
    </form>
</div>