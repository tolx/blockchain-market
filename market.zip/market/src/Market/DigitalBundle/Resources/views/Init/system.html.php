<?php
$view->extend('MarketDigitalBundle::layout.html.php');
?>
<div id="main" class="mt90">
    <div class="container">
        <div class="row">
            <div class="panel panel-default">
                <div class="panel-body">
                    <h4>
                        <?php echo $product->getTitle(); ?>
                    </h4>
                    <hr>
                    <div class="detail">
                        <?php echo $product->getDetails(); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>