<?php if ($categories) { ?>
    <div id="reports">
        <div class="container">
            <div class="row">
                <div class="col-lg-1"></div>
                <?php foreach ($categories as $key => $value) { ?>
                    <div class="col-lg-2 statistic">
                        <div class="value"><?php echo number_format($value->getTotal()); ?></div>
                        <div class="label"><?php echo $value->getTitle(); ?></div>
                    </div>
                <?php } ?>
            </div>
        </div>
    </div>
<?php } ?>