<div class="navbar navbar-default navbar-fixed-top" role="navigation">
    <div class="container">
        <div class="navbar-header">
            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                <i class="fa fa-align-justify fa-2x"></i>
            </button>

            <a class="navbar-brand" href="<?php echo $view['router']->generate('_homepage', array(), true); ?>">
                <img alt="<?php echo $view['translator']->trans("Veri Print"); ?>" src="<?php echo $view->escape('/assetic/images/'); ?>logo.png">
            </a>
        </div>
        <div class="navbar-collapse collapse">
            <ul class="nav navbar-nav">
                <li class="dropdown">
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown"><?php echo $view['translator']->trans("Categories"); ?> <i class="fa fa-angle-down"></i></a>
                    <ul class="dropdown-menu fadeIn">
                        <?php
                        if ($categories) {
                            foreach ($categories as $vCategories) {
                                $url = $view['router']->generate('_view_categories', array('id' => $vCategories->getId(), 'title' => Market\DigitalBundle\System::_reString($vCategories->getTitle())), true);
                                ?>
                                <li><a href="<?php echo $url; ?>"><?php echo $vCategories->getTitle(); ?></a></li>
                                <?php
                            }
                        }
                        ?>
                    </ul>
                </li>
            </ul>
            <form id="fSearch" class="navbar-form navbar-left form-inline" role="search" method="GET" action="<?php echo $view['router']->generate('_view_search', array(), true); ?>">
                <div class="form-group has-feedback">
                    <input type="text" class="form-control" name="s" id="s" placeholder="<?php echo $view['translator']->trans("Input keyword + Enter"); ?>">
                    <span class="form-control-feedback"><i class="fa fa-search"></i></span>
                </div>
            </form>
            <ul class="nav navbar-nav navbar-right<?php
            if (!$check) {
                echo " mtop8";
            }
            ?>">
                    <?php if (!$check) { ?>
                    <a class="btn white" data-toggle="modal" data-target=".popup-signup"><?php echo $view['translator']->trans("Sign up"); ?></a>
                    <a data-toggle="modal" data-target=".popup-signin" class="btn blue bold mleft10"><?php echo $view['translator']->trans("Log in"); ?></a>
                <?php } else { ?>
                    <li class="dropdown">
                        <a href="#" class="dropdown-toggle pb10 pt10" data-toggle="dropdown">
                            <img alt="<?php echo $check->getUsername(); ?>" src="<?php echo ($check->getAvatar())?$check->getAvatar():($view->escape('/uploads/avatar/')."defaultAvatar.png"); ?>" class="img-circle"> 
                            <i class="fa fa-angle-down"></i>
                        </a>
                        <ul class="dropdown-menu fadeIn">
                            <li><a href="<?php echo $view['router']->generate('_user', array(), true); ?>"><?php echo $view['translator']->trans("Profile"); ?></a></li>
                            <li><a href="<?php echo $view['router']->generate('_upload', array(), true); ?>"><?php echo $view['translator']->trans("Upload"); ?></a></li>
                            <li><a href="<?php echo $view['router']->generate('_purchases', array(), true); ?>"><?php echo $view['translator']->trans("My purchases"); ?></a></li>
                            <li><a href="<?php echo $view['router']->generate('_logout', array(), true); ?>"><?php echo $view['translator']->trans("Log out"); ?></a></li>
                        </ul>
                    </li>
                <?php } ?>
            </ul>
        </div>
    </div>
</div>

<?php if ($check && $check->getSupper()) { ?>
    <a class="scrollAdmin" data-toggle="tooltip" data-placement="left" title="<?php echo $view['translator']->trans("Admin Dashboard"); ?>" href="<?php echo $view['router']->generate('_admin_homepage', array(), true); ?>"><i class="fa fa-dashboard fa-2x"></i></a>
<?php } ?>

<?php if (!$check) { ?>
    <div class="modal fade popup-signup" tabindex="-1" role="dialog">
        <div class="modal-dialog modal-sm">
            <div class="modal-content rd3">
                <div class="modal-body">
                    <center><h3><?php echo $view['translator']->trans("Veri Print "); ?></h3></center>
                    <br>
                    <form class="form-horizontal" method="POST" autocomplete="off" action="<?php echo $view['router']->generate('register', array(), true); ?>">
                        <div class="form-group">
                            <div class="col-sm-12">
                                <a class="btn btn-default facebook btn-lg" href="<?php echo $fbRegister; ?>">
                                    <i class="fa fa-facebook"></i> <?php echo $view['translator']->trans("Sign up with Facebook"); ?>
                                </a>
                            </div>
                        </div>
                        <hr>
                        <div class="form-group">
                            <div class="col-sm-12">
                                <input type="text" autocomplete="off" required class="form-control input-lg font14" id="username" name="username" placeholder="<?php echo $view['translator']->trans("Username"); ?>">
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="col-sm-12">
                                <input type="email" autocomplete="off" required class="form-control input-lg font14" id="email" name="email" placeholder="<?php echo $view['translator']->trans("Email address"); ?>">
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="col-sm-12">
                                <input type="password" autocomplete="off" required class="form-control input-lg font14" id="password" name="password" placeholder="<?php echo $view['translator']->trans("Password"); ?>">
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="col-sm-12">
                                <button type="submit" class="btn blue btn-lg font14 width100"><?php echo $view['translator']->trans("Sign up for free"); ?></button>
                            </div>
                        </div>
                        <div class="terms">
                            <?php echo $view['translator']->trans('By clicking "Sign up" you agree to our'); ?>
                            <a href="<?php echo $view['router']->generate('_view_system', array('title' => "terms"), true); ?>" target="_blank"><?php echo $view['translator']->trans('Terms of Service'); ?></a>
                            <?php echo $view['translator']->trans('and'); ?>
                            <a href="<?php echo $view['router']->generate('_view_system', array('title' => "privacy"), true); ?>" target="_blank"><?php echo $view['translator']->trans('Privacy Policy'); ?></a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <div class="modal fade popup-signin" tabindex="-1" role="dialog">
        <div class="modal-dialog modal-sm">
            <div class="modal-content rd3">
                <div class="modal-body">
                    <center><h3><?php echo $view['translator']->trans("Log in to Marketplace"); ?></h3></center>
                    <br>
                    <form class="form-horizontal" method="POST" autocomplete="off" action="<?php echo $view['router']->generate('_login', array(), true); ?>">
                        <div class="form-group">
                            <div class="col-sm-12">
                                <a class="btn btn-default facebook btn-lg" href="<?php echo $fbRegister; ?>">
                                    <i class="fa fa-facebook"></i> <?php echo $view['translator']->trans("Log in with Facebook"); ?>
                                </a>
                            </div>
                        </div>
                        <hr>
                        <div class="form-group">
                            <div class="col-sm-12">
                                <input type="email" autocomplete="off" class="form-control input-lg font14" id="username" name="username" required placeholder="<?php echo $view['translator']->trans("Email address"); ?>">
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="col-sm-12">
                                <input type="password" autocomplete="off" class="form-control input-lg font14" id="password" name="password" required placeholder="<?php echo $view['translator']->trans("Password"); ?>">
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="col-sm-12">
                                <button type="submit" class="btn blue btn-lg font14 width100"><?php echo $view['translator']->trans("Log in"); ?></button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php } ?>