<?php if (!$check) { ?>
    <div id="header">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="text-center top100 color-white">
                        <h1>
                            <?php echo $view['translator']->trans("Secure 3D Printer Model Transactions."); ?>
                        </h1>
                    </div>
                </div>

                <div class="col-lg-1"></div>
                <div class="col-lg-6">

                    <div class="benefits">
                        <ul class="list-unstyled">
                            <li class="top90">
                                <i class="fa fa-users fa-2x" style="padding-right: 15px;"></i> 
                                <span class="spanIn">
                                    <?php echo $view['translator']->trans(" developers, and 3D creators..."); ?>
                                </span>
                            </li>
                            <li style="margin-top: 30px;">
                                <i class="fa fa-cart-plus fa-2x" style="padding-right: 15px;"></i> 
                                <span class="spanIn">
                                    <?php echo $view['translator']->trans("Securely Verify 3D Printer Models"); ?>
                                </span>
                            </li>
                            <li style="margin-top: 30px;">
                                <i class="fa fa-credit-card fa-2x" style="padding-right: 15px;"></i> 
                                <span class="spanIn">
                                    <?php echo $view['translator']->trans("Verified Models are here."); ?>
                                </span>
                            </li>
                            <li style="margin-top: 30px;">
                                <i class="fa fa-money fa-2x" style="padding-right: 15px;"></i> 
                                <span class="spanIn">
                                    <?php echo $view['translator']->trans("Safely check all your digital 3D Models"); ?>
                                </span>
                            </li>
                            <?php /*
                              <li style="margin-top: 30px;">
                              <a style="padding-right: 15px;" class="learn-more-link" href="/sell/">
                              <?php echo $view['translator']->trans("Learn more..."); ?>
                              </a>
                              </li>
                             */ ?>
                        </ul>
                    </div>

                </div>

                <div class="col-lg-4">
                    <form class="form-horizontal signup" autocomplete="off" method="POST" action="<?php echo $view['router']->generate('register', array(), true); ?>">
                        <div class="form-group">
                            <div class="col-sm-12">
                                <!-- <a class="btn btn-default facebook btn-lg" href="<?php echo $fbRegister; ?>">
                                    <i class="fa fa-facebook"></i> <?php echo $view['translator']->trans("Sign up with Facebook"); ?>
                                </a> -->
                            </div>
                        </div>
                        <hr class="hr9">
                        <div class="form-group">
                            <div class="col-sm-12">
                                <input type="text" autocomplete="off" required class="form-control input-lg font14" id="username" name="username" placeholder="<?php echo $view['translator']->trans("Username"); ?>">
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="col-sm-12">
                                <input type="email" autocomplete="off" required class="form-control input-lg font14" id="email" name="email" placeholder="<?php echo $view['translator']->trans("Email address"); ?>">
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="col-sm-12">
                                <input type="password" autocomplete="off" required class="form-control input-lg font14" id="password" name="password" placeholder="<?php echo $view['translator']->trans("Password"); ?>">
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="col-sm-12">
                                <button type="submit" class="btn blue btn-lg font14 width100"><?php echo $view['translator']->trans("Sign up for free"); ?></button>
                            </div>
                        </div>
                        <div class="terms">
                            <?php echo $view['translator']->trans('By clicking "Sign up" you agree to our'); ?>
                            <a href="<?php echo $view['router']->generate('_view_system', array('title' => "terms"), true); ?>" target="_blank"><?php echo $view['translator']->trans('Terms of Service'); ?></a>
                            <?php echo $view['translator']->trans('and'); ?>
                            <a href="<?php echo $view['router']->generate('_view_system', array('title' => "privacy"), true); ?>" target="_blank"><?php echo $view['translator']->trans('Privacy Policy'); ?></a>
                        </div>
                    </form>
                </div>

            </div>
        </div>
    </div>
<?php } ?>

<div id="join" class="<?php
if ($check) {
    echo "mt50 bg-blue";
}
?>">
    <div class="container">
        <div class="row">
            <h2>
                <?php echo $view['translator']->trans("Ready to use assets for building your contents"); ?>
            </h2>
            <h4>
                <?php echo $view['translator']->trans("Purchase 3D Printer Models Securely. "); ?>
            </h4>
        </div>
        <?php if (!$check) { ?>
            <br>
            <a class="btn blue btn-lg" data-toggle="modal" data-target=".popup-signup">
                <?php echo $view['translator']->trans("Get started!"); ?>
            </a>
        <?php } ?>
    </div>
</div>

<?php if ($list) { ?>
    <div id="main">
        <div class="container">
            <div class="row">
                <?php
                foreach ($list as $key => $value) {
                    $title = $value->getTitle();
                    $userName = $value->getUsers()->getFullName();
                    $url = $view['router']->generate('_view_products', array('id' => $value->getId(), 'title' => Market\DigitalBundle\System::_reString($title)), true);
                    ?>
                    <div class="col-md-3">
                        <div class="thumbnail">
                            <a href="<?php echo $url; ?>" alt="<?php echo $title; ?>" title="<?php echo $title; ?>">
                                <img alt="<?php echo $title; ?>" title="<?php echo $title; ?>" src="<?php echo $view->escape('/uploads/items/'); ?><?php echo $value->getImage(); ?>">
                            </a>
                            <div class="caption">
                                <div class="title-product">
                                    <a href="<?php echo $url; ?>" alt="<?php echo $title; ?>" title="<?php echo $title; ?>">
                                        <h5 class="text-detail">
                                            <?php echo Market\DigitalBundle\System::getSomeWords($title, 12); ?>
                                        </h5>
                                    </a>
                                </div>

                                <div class="media">
                                    <a href="<?php echo $view['router']->generate('_view_author', array('title' => $value->getUsers()->getUsername()), true); ?>" class="pull-left" alt="<?php echo $title; ?>" title="<?php echo $title; ?>">
                                        <img alt="<?php echo $userName; ?>" title="<?php echo $userName; ?>" src="<?php echo $value->getUsers()->getAvatar(); ?>" class="media-object img-circle avatar">
                                    </a>
                                    <div class="media-body">
                                        <a href="<?php echo $view['router']->generate('_view_author', array('title' => $value->getUsers()->getUsername()), true); ?>" alt="<?php echo $userName; ?>" title="<?php echo $userName; ?>"><?php echo $userName; ?></a>
                                    </div>
                                </div>
                                <hr>
                                <div class="price-product">
                                    <div class="left column">
                                        <div class="price">
                                            <span class="discount-price">
                                                <?php echo ($value->getPrice() > 0) ? "$" . number_format($value->getPrice()) : $view['translator']->trans("FREE"); ?>
                                            </span>
                                        </div>
                                    </div>
                                    <div class="right column">
                                        <a class="btn btn-buy-gray" href="<?php echo $url; ?>"><i class="fa fa-cart-plus"></i> <?php echo $view['translator']->trans("Buy now"); ?></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php
                }
                ?>
            </div>
        </div>
    </div>
    <?php
}
?>
<?php if ($notice) { ?>
    <div class="modal fade" id="noticeModal" tabindex="-1" role="dialog" aria-labelledby="noticeModalLabel">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-body">
                    <div style="text-align: center; padding: 20px 0px;">
                        <img src="<?php echo $view->escape('/assetic/images/'); ?>error.jpg">
                    </div>
                    <h4 style="text-align: center;">
                        <?php echo $notice; ?>
                    </h4>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal"><?php echo $view['translator']->trans("Close"); ?></button>
                </div>
            </div>
        </div>
    </div>
    <script>
        $('#noticeModal').modal('show');
    </script>
<?php } ?>
