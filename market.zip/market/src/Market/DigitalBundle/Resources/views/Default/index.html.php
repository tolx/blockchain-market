<?php
$view->extend('MarketDigitalBundle::layout.html.php');
echo $view['actions']->render(
        $view['router']->generate('indexFixed', array(), true)
);
?>