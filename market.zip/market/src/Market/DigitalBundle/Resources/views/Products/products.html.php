<?php
$view->extend('MarketDigitalBundle::layout.html.php');
$url = $view['router']->generate('_view_products', array('id' => $product->getId(), 'title' => Market\DigitalBundle\System::_reString($product->getTitle())), true);
?>
<div id="main" class="mt90">
    <div class="container">
        <div class="row">
            <div class="col-md-8">
                <div class="panel panel-default">
                    <div class="panel-body">
                        <h4>
                            <?php echo $product->getTitle(); ?>
                        </h4>
                        <hr>
                        <img alt="<?php echo $product->getTitle(); ?>" title="<?php echo $product->getTitle(); ?>" src="<?php echo $view->escape('/uploads/items/'); ?><?php echo $product->getImage(); ?>">
                        <hr>
                        <div class="detail">
                            <?php echo $product->getDetails(); ?>
                        </div>
                    </div>
                    <div class="panel-footer">
                        <div style="display: table; width: 100%;">
                            <div class="form-group text-center">
                                <div class="col-sm-12">
                                    <a class="btn blue btn-lg buyNow" data-bind="<?php echo $url; ?>"><i class="faAni fa fa-cart-plus"></i> <?php echo $view['translator']->trans("Buy Now"); ?></a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="panel panel-default">
                    <div class="panel-body">
                        <div class="price">
                            <?php echo ($product->getPrice() > 0) ? "$" . number_format($product->getPrice()) : $view['translator']->trans("FREE"); ?>
                        </div>
                        <div class="form-group" style="margin-top: 15px;">
                            <div class="col-sm-12">
                                <a class="btn blue btn-lg width100 buyNow" data-bind="<?php echo $url; ?>"><i class="faAni fa fa-cart-plus"></i> <?php echo $view['translator']->trans("Buy Now"); ?></a>
                            </div>
                        </div>
                    </div>
                    <div class="panel-footer">
                        <div class="infoAuthor">
                            <div class="left">
                                <?php echo $view['translator']->trans("Created By:"); ?>
                            </div>
                            <div class="right">
                                <a href="<?php echo $view['router']->generate('_view_author', array('title' => $product->getUsers()->getUsername()), true); ?>">
                                    <?php echo $product->getUsers()->getFullName(); ?>
                                </a>
                            </div>
                        </div>
                        <hr class="hr5">
                        <div class="infoAuthor">
                            <div class="left">
                                <?php echo $view['translator']->trans("Created On:"); ?>
                            </div>
                            <div class="right">
                                <a href="<?php echo $view['router']->generate('_view_categories', array('id' => $product->getCategories()->getId(), 'title' => Market\DigitalBundle\System::_reString($product->getCategories()->getTitle())), true); ?>">
                                    <?php echo $product->getCategories()->getTitle(); ?>
                                </a>
                            </div>
                        </div>
                        <hr class="hr5">
                        <div class="infoAuthor">
                            <div class="left">
                                <?php echo $view['translator']->trans("Created At:"); ?>
                            </div>
                            <div class="right">
                                <?php echo $product->getCreatedAt()->format("d/m/Y"); ?>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="panel panel-default" style="padding: 5px; height: 32px; text-align: center; border: none;">
                    <div class="fb-like" data-href="<?php echo $url; ?>" data-layout="button_count" data-action="like" data-show-faces="false" data-share="false"></div>
                    <a href="https://twitter.com/share" class="twitter-share-button" data-url="<?php echo $url; ?>" data-dnt="true">Tweet</a>
                    <a href="//www.pinterest.com/pin/create/button/" data-pin-do="buttonBookmark"  data-pin-color="red"><img src="//assets.pinterest.com/images/pidgets/pinit_fg_en_rect_red_20.png" /></a>
                </div>
            </div>
        </div>
    </div>
</div>