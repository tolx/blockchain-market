<?php
$view->extend('MarketDigitalBundle::layout_user.html.php');

$view['slots']->set('title', $view['translator']->trans("My Purchases") . " | " . $view['translator']->trans("Marketplace.Com"));
?>
<div class="col-md-9">
    <?php if ($done) { ?>
        <div class="alert alert-success">
            <i class="fa fa-flag"></i> <?php echo $view['translator']->trans("Congratulation! You've upload successfully your product."); ?>
        </div>
    <?php } ?>
    <div class="panel panel-blue">
        <div class="panel-heading">
            <h2 class="panel-title"><i class="fa fa-file-archive-o"></i> <?php echo $view['translator']->trans("My Products"); ?></h2>
        </div>
        <div class="table-responsive panel-collapse pull out">
            <table class="table">
                <thead>
                    <tr>
                        <th><?php echo $view['translator']->trans("Title"); ?></th> 
                        <th><?php echo $view['translator']->trans("Status"); ?></th>
                        <th><?php echo $view['translator']->trans("Price"); ?></th>
                        <th><?php echo $view['translator']->trans("Saled"); ?></th>
                        <th><?php echo $view['translator']->trans("Edit"); ?></th>
                    </tr>
                </thead>
                <tbody>
                    <?php if ($list) { ?>
                        <?php
                        foreach ($list as $value) {
                            $url = $view['router']->generate('_view_products', array('id' => $value->getId(), 'title' => Market\DigitalBundle\System::_reString($value->getTitle())), true);
                            $urlDownload = $view['router']->generate('_edit_product', array('id' => $value->getId()), true);
                            ?>
                            <tr>
                                <td style="width: 70%"><a target="_blank" href="<?php echo $url; ?>" class="semibold text-accent"><?php echo $value->getTitle(); ?></a></td> 
                                <td style="width: 10%"><?php
                                    if ($value->getActive()) {
                                        echo "<font style='color: green; font-weight: bold;'>" . $view['translator']->trans("Showing") . "</font>";
                                    } else {
                                        echo "<font style='color: red; font-weight: bold;'>" . $view['translator']->trans("Hidden") . "</font>";
                                    }
                                    ?></td> 
                                <td style="width: 10%"><?php echo number_format($value->getPrice()); ?></td> 
                                <td style="width: 10%"><?php echo number_format($value->getTotalSale()); ?></td> 
                                <td style="width: 5%"><a class="btn btn-default" href="<?php echo $urlDownload; ?>"><?php echo $view['translator']->trans("Edit"); ?></a></td>
                            </tr>
                            <?php
                        }
                        ?>
                        <?php
                    } else {
                        ?>
                        <tr>
                            <td colspan="3">
                    <center>
                        <?php echo $view['translator']->trans("No Data"); ?>
                    </center>
                    </td>
                    </tr>
                <?php }
                ?> 
                </tbody>
            </table>
        </div>
    </div>
    <div class="col-lg-12">
        <div class="row">
            <?php
            if ($page["NextPage"] > 1):
                $urlNext = $view['router']->generate('_sales', array(), true);
                ?>
                <ul class="pagination">
                    <?php if ($page["PreviousPage"] != $page["Page"]): ?>
                        <li class="prev">
                            <a href="<?php echo $urlNext . '?p=' . $page["PreviousPage"]; ?>"><span class="glyphicon glyphicon-chevron-left"></span>&nbsp;<?php echo $view['translator']->trans("Prew"); ?></a>
                        </li>
                    <?php endif; ?>
                    <li class="active"><a><?php echo $page["Page"]; ?></a></li>
                    <?php if ($page["LastPage"] > $page["Page"]): ?>
                        <li class="next"><a href="<?php echo $urlNext . '?p=' . $page["NextPage"]; ?>"><?php echo $view['translator']->trans("Next"); ?>&nbsp;<span class="glyphicon glyphicon-chevron-right"></span></a></li>
                            <?php endif; ?>
                </ul>
            <?php endif; ?>
        </div>
    </div>
</div>