<?php
$view->extend('MarketDigitalBundle::layout_admin.html.php');
?>
<div class="col-md-9">
    <form class="form-horizontal" method="POST" autocomplete="off" action="">
        <div class="panel panel-blue">
            <div class="panel-heading">
                <h2 class="panel-title"><?php echo $view['translator']->trans('New Category'); ?></h2>
            </div>
            <div class="panel-body">
                <div class="form-group">
                    <div class="col-sm-12">
                        <input type="text" autocomplete="off" class="form-control font14" id="title" name="title" required placeholder="<?php echo $view['translator']->trans("Category Title"); ?>" value="<?php echo $viewT->getTitle(); ?>">
                    </div>
                </div>

                <div class="form-group">
                    <div class="col-sm-12">
                        <label><?php echo $view['translator']->trans("Active"); ?></label>
                        <div class="radio">
                            <label>
                                <input type="radio" name="active" value="0" <?php
                                if ($viewT->getActive() == 0) {
                                    echo 'checked';
                                }
                                ?>><?php echo $view['translator']->trans("No"); ?>
                            </label>
                        </div>
                        <div class="radio">
                            <label>
                                <input type="radio" name="active" value="1"  <?php
                                if ($viewT->getActive() == 1) {
                                    echo 'checked';
                                }
                                ?>><?php echo $view['translator']->trans("Yes"); ?>
                            </label>
                        </div>
                    </div>
                </div>
            </div>
            <div class="panel-footer bg-white">
                <button type="submit" class="btn blue btn-lg font14"><?php echo $view['translator']->trans("Update"); ?></button>
            </div>
        </div>
    </form>
</div>