<?php
$view->extend('MarketDigitalBundle::layout_admin.html.php');
?>
<div class="col-md-9">
    <form class="form-horizontal" method="POST" autocomplete="off" action="">
        <div class="panel panel-blue">
            <div class="panel-heading">
                <h2 class="panel-title"><?php echo $view['translator']->trans('New Help'); ?></h2>
            </div>
            <div class="panel-body">
                <div class="form-group">
                    <div class="col-sm-12">
                        <label><?php echo $view['translator']->trans("Title"); ?></label>
                        <input type="text" autocomplete="off" class="form-control font14" id="title" name="title" required placeholder="<?php echo $view['translator']->trans("Title"); ?>">
                    </div>
                </div>

                <div class="form-group">
                    <div class="col-sm-12">

                        <label><?php echo $view['translator']->trans("Type"); ?></label>
                        <select name="type" id="type" class="form-control dataFile" required>
                            <option value="0" selected="selected"><?php echo $view['translator']->trans("Terms"); ?></option>
                            <option value="1"><?php echo $view['translator']->trans("Privacy"); ?></option>
                            <option value="2"><?php echo $view['translator']->trans("About"); ?></option>
                        </select>
                    </div>
                </div>
                
                <div class="form-group">
                    <div class="col-sm-12">
                        <label><?php echo $view['translator']->trans("Detail"); ?></label>
                        <textarea class="form-control summernote" name="details" rows="12"></textarea>
                    </div>
                </div>
                
            </div>
            <div class="panel-footer bg-white">
                <button type="submit" class="btn blue btn-lg font14"><?php echo $view['translator']->trans("Submit"); ?></button>
            </div>
        </div>
    </form>
</div>