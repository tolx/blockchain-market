<?php
$view->extend('MarketDigitalBundle::layout_admin.html.php');
?>
<div class="col-md-9">
    <div class="panel panel-blue">
        <div class="panel-heading">
            <h2 class="panel-title"><?php echo $view['translator']->trans('List Users'); ?></h2>
        </div>
        <div class="panel-body">
            <?php
            if (count($list) > 0) {
                ?>
                <table class="table mb0">
                    <thead>
                        <tr>
                            <th data-field="id" data-sortable="true"><?php echo $view['translator']->trans("ID"); ?></th>
                            <th data-field="author"  data-sortable="true"><?php echo $view['translator']->trans("Author"); ?></th>
                            <th data-field="files"  data-sortable="true"><?php echo $view['translator']->trans("Total File"); ?></th>
                            <th data-field="price"  data-sortable="true"><?php echo $view['translator']->trans("Earned"); ?></th>
                            <th data-field="total"  data-sortable="true"><?php echo $view['translator']->trans("Saled"); ?></th>
                            <th data-field="status" data-sortable="true"><?php echo $view['translator']->trans("Status"); ?></th>
                            <th><?php echo $view['translator']->trans("Edit"); ?></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($list as $key => $value) { ?>
                            <tr data-index="<?php echo $value->getId(); ?>">
                                <td style="">
                                    <?php echo $value->getId(); ?>
                                </td>
                                <td style="">
                                    <a href="<?php echo $view['router']->generate('edit_users', array('id' => $value->getId()), true); ?>"><?php echo $value->getFullName(); ?></a>
                                </td>
                                <td style="">
                                    <?php echo number_format($value->getTotalFile()); ?>
                                </td>
                                <td style="">
                                    <?php echo number_format($value->getEarned()); ?>
                                </td>
                                <td style="">
                                    <?php echo number_format($value->getSaled()); ?>
                                </td>
                                <td style=""><?php
                                    if ($value->getActive() == 1) {
                                        echo "<font color='green'>" . $view['translator']->trans("Active") . "</font>";
                                    } else {
                                        echo "<font color='red'>" . $view['translator']->trans("Disable") . "</font>";
                                    }
                                    ?>
                                </td>
                                <td style="">
                                    <a href="<?php echo $view['router']->generate('edit_users', array('id' => $value->getId()), true); ?>"><?php echo $view['translator']->trans("Edit"); ?></a>
                                </td>
                            </tr>
                        <?php } ?>
                    </tbody> 
                </table>
                <?php
            } else {
                echo $view['translator']->trans("No Data");
            }
            ?>
        </div>
    </div>
    <div class="col-lg-12">
        <div class="row">
            <?php
            if ($page["NextPage"] > 1):
                $urlNext = $view['router']->generate('_admin_users', array(), true);
                ?>
                <ul class="pagination">
                    <?php if ($page["PreviousPage"] != $page["Page"]): ?>
                        <li class="prev">
                            <a href="<?php echo $urlNext . '?p=' . $page["PreviousPage"]; ?>"><span class="glyphicon glyphicon-chevron-left"></span>&nbsp;<?php echo $view['translator']->trans("Prew"); ?></a>
                        </li>
                    <?php endif; ?>
                    <li class="active"><a><?php echo $page["Page"]; ?></a></li>
                    <?php if ($page["LastPage"] > $page["Page"]): ?>
                        <li class="next"><a href="<?php echo $urlNext . '?p=' . $page["NextPage"]; ?>"><?php echo $view['translator']->trans("Next"); ?>&nbsp;<span class="glyphicon glyphicon-chevron-right"></span></a></li>
                            <?php endif; ?>
                </ul>
            <?php endif; ?>
        </div>
    </div>
</div>