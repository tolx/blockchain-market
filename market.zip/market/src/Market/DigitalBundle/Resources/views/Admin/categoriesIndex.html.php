<?php
$view->extend('MarketDigitalBundle::layout_admin.html.php');
?>
<div class="col-md-9">
    <div class="panel panel-blue">
        <div class="panel-heading">
            <h2 class="panel-title"><?php echo $view['translator']->trans('List Categories'); ?></h2>
        </div>
        <div class="panel-body">
            <?php
            if (count($list) > 0) {
                ?>
                <table class="table mb0">
                    <thead>
                        <tr>
                            <th data-field="id" data-sortable="true"><?php echo $view['translator']->trans("ID"); ?></th>
                            <th data-field="name"  data-sortable="true"><?php echo $view['translator']->trans("Name"); ?></th>
                            <th data-field="total"  data-sortable="true"><?php echo $view['translator']->trans("Total Files"); ?></th>
                            <th data-field="status" data-sortable="true"><?php echo $view['translator']->trans("Status"); ?></th>
                            <th><?php echo $view['translator']->trans("Delete"); ?></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($list as $key => $value) { ?>
                            <tr data-index="<?php echo $value->getId(); ?>">
                                <td style="">
                                    <?php echo $value->getId(); ?>
                                </td>
                                <td style="">
                                    <a href="<?php echo $view['router']->generate('edit_categories', array('id' => $value->getId()), true); ?>"><?php echo $value->getTitle(); ?></a>
                                </td>
                                <td style="">
                                    <?php echo number_format($value->getTotal()); ?>
                                </td>
                                <td style=""><?php
                                    if ($value->getActive() == 1) {
                                        echo "<font color='green'>" . $view['translator']->trans("Active") . "</font>";
                                    } else {
                                        echo "<font color='red'>" . $view['translator']->trans("Disable") . "</font>";
                                    }
                                    ?>
                                </td>
                                <td style=""><a style="color: red;" onclick="return  confirm('Delete?');" href="<?php echo $view['router']->generate('del_categories', array('id' => $value->getId()), true); ?>"><?php echo $view['translator']->trans("Delete"); ?></a>
                                </td>
                            </tr>
                        <?php } ?>
                    </tbody> 
                </table>
                <?php
            } else {
                echo $view['translator']->trans("No Data");
            }
            ?>
        </div>
    </div>
</div>