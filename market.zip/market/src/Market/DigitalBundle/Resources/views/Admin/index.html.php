<?php
$view->extend('MarketDigitalBundle::layout_admin.html.php');
?>
<script type="text/javascript" src="<?php echo $view['assets']->getUrl('/assetic/'); ?>js/moment.min.js"></script>
<script type="text/javascript" src="<?php echo $view['assets']->getUrl('/assetic/'); ?>js/bootstrap-datetimepicker.min.js"></script>
<link rel="stylesheet" href="<?php echo $view['assets']->getUrl('/assetic/'); ?>css/bootstrap-datetimepicker.css">
<div class="col-md-9">
    <section class="panel panel-default">
        <header class="panel-heading">
            <?php echo $view['translator']->trans("Today"); ?>
        </header>
        <div class="panel-body text-center">
            <div class="row">
                <div class="col-lg-1 col-md-1 col-sm-12 col-xs-12"></div>
                <div class="col-lg-2 col-md-2 col-sm-12 col-xs-12" style="color: #d43f3a;">
                    <div class="info-box blue-bg">
                        <i class="fa fa-users"></i>
                        <div class="count">
                            <?php echo ($listToday) ? number_format($listToday->getUsers()) : 0; ?>
                        </div>
                        <div class="title"><?php echo $view['translator']->trans("New Users"); ?></div>						
                    </div>			
                </div>
                <div class="col-lg-2 col-md-2 col-sm-12 col-xs-12" style="color: #eea236;">
                    <div class="info-box brown-bg">
                        <i class="fa fa-file-archive-o"></i>
                        <div class="count">
                            <?php echo ($listToday) ? number_format($listToday->getProducts()) : 0; ?>
                        </div>
                        <div class="title"><?php echo $view['translator']->trans("New Products"); ?></div>							
                    </div>			
                </div>	
                <div class="col-lg-2 col-md-2 col-sm-12 col-xs-12" style="color: #337ab7;">
                    <div class="info-box dark-bg">
                        <i class="fa fa-cart-plus"></i>
                        <div class="count">
                            <?php echo ($listToday) ? number_format($listToday->getSales()) : 0; ?>
                        </div>
                        <div class="title"><?php echo $view['translator']->trans("Orders"); ?></div>					
                    </div>			
                </div>
                <div class="col-lg-2 col-md-2 col-sm-12 col-xs-12" style="color: #46b8da;">
                    <div class="info-box green-bg">
                        <i class="fa fa-money"></i>
                        <div class="count">
                            <?php echo ($listToday) ? number_format($listToday->getPaid()) : 0; ?>
                        </div>
                        <div class="title"><?php echo $view['translator']->trans("Paid"); ?></div>						
                    </div>			
                </div>
                <div class="col-lg-2 col-md-2 col-sm-12 col-xs-12" style="color: #4cae4c;">
                    <div class="info-box green-bg">
                        <i class="fa fa-money"></i>
                        <div class="count">
                            <?php echo ($listToday) ? number_format($listToday->getRevenues()) : 0; ?>
                        </div>
                        <div class="title"><?php echo $view['translator']->trans("Revenues"); ?></div>						
                    </div>			
                </div>
            </div>
        </div>
    </section>
    <section class="panel panel-default">
        <header class="panel-heading">
            <form class="navbar-form" method="POST" autocomplete="off" action="">
                <div class="form-group">
                    <div class='input-group date' id='datetimepicker10'>
                        <input type='text' class="form-control" id="dateChart" name="dateChart" value="<?php echo $dateChart; ?>"/>
                        <span class="input-group-addon">
                            <span class="glyphicon glyphicon-calendar">
                            </span>
                        </span>
                    </div>
                </div>
                <button type="submit" class="btn btn-default"><?php echo $view['translator']->trans("Submit"); ?></button>
            </form>

        </header>
        <div class="panel-body text-center">
            <canvas id="line" height="450" width="750"></canvas>
        </div>
    </section>
</div>
<script src="<?php echo $view['assets']->getUrl('/assetic/'); ?>js/Chart.js"></script>
<script>
<?php
$title = "";
$totalUser = "";
$totalPaid = "";
$totalRevenue = "";
$totalProduct = "";
$totalOrder = "";
if ($list) {
    foreach ($list as $key => $value) {
        if ($title) {
            $title .= ', "' . $value->getDateReport() . '/' . $value->getMonthReport() . '"';
        } else {
            $title = '"' . $value->getDateReport() . '/' . $value->getMonthReport() . '"';
        }
        if ($totalUser) {
            $totalUser .= "," . $value->getUsers();
        } else {
            $totalUser = $value->getUsers();
        }
        if ($totalPaid) {
            $totalPaid .= "," . $value->getPaid();
        } else {
            $totalPaid = $value->getPaid();
        }
        if ($totalRevenue) {
            $totalRevenue .= "," . $value->getRevenues();
        } else {
            $totalRevenue = $value->getRevenues();
        }
        if ($totalProduct) {
            $totalProduct .= "," . $value->getProducts();
        } else {
            $totalProduct = $value->getProducts();
        }
        if ($totalOrder) {
            $totalOrder .= "," . $value->getSales();
        } else {
            $totalOrder = $value->getSales();
        }
    }
}
?>
    $(document).ready(function () {
        var data = {
            labels: [<?php echo $title; ?>],
            datasets: [
                {
                    label: "Orders",
                    fillColor: "rgba(220,220,220,0)",
                    strokeColor: "#337ab7",
                    pointColor: "#337ab7",
                    pointStrokeColor: "#fff",
                    pointHighlightFill: "#fff",
                    pointHighlightStroke: "#337ab7",
                    data: [<?php echo $totalOrder; ?>]
                },
                {
                    label: "Revenues",
                    fillColor: "rgba(151,187,205,0)",
                    strokeColor: "#4cae4c",
                    pointColor: "#4cae4c",
                    pointStrokeColor: "#fff",
                    pointHighlightFill: "#fff",
                    pointHighlightStroke: "#4cae4c",
                    data: [<?php echo $totalRevenue; ?>]
                },
                {
                    label: "Paid",
                    fillColor: "rgba(151,187,205,0)",
                    strokeColor: "#46b8da",
                    pointColor: "#46b8da",
                    pointStrokeColor: "#fff",
                    pointHighlightFill: "#fff",
                    pointHighlightStroke: "#46b8da",
                    data: [<?php echo $totalPaid; ?>]
                },
                {
                    label: "Products",
                    fillColor: "rgba(151,187,205,0)",
                    strokeColor: "#eea236",
                    pointColor: "#eea236",
                    pointStrokeColor: "#fff",
                    pointHighlightFill: "#fff",
                    pointHighlightStroke: "#eea236",
                    data: [<?php echo $totalProduct; ?>]
                },
                {
                    label: "Users",
                    fillColor: "rgba(151,187,205,0)",
                    strokeColor: "#d43f3a",
                    pointColor: "#d43f3a",
                    pointStrokeColor: "#fff",
                    pointHighlightFill: "#fff",
                    pointHighlightStroke: "#d43f3a",
                    data: [<?php echo $totalUser; ?>]
                }
            ]
        };
        new Chart(document.getElementById("line").getContext("2d")).Line(data);
    });
</script>
<script type="text/javascript">
    $(function () {
        $('#datetimepicker10').datetimepicker({
            viewMode: 'years',
            format: 'MM/YYYY'
        });
    });
</script>