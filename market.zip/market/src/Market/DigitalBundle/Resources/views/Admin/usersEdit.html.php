<?php
$view->extend('MarketDigitalBundle::layout_admin.html.php');
?>
<div class="col-md-9">
    <form class="form-horizontal" method="POST" autocomplete="off" action="">
        <div class="panel panel-blue">
            <div class="panel-body">

                <div class="form-group">
                    <div class="col-sm-12">
                        <label><?php echo $view['translator']->trans("Author"); ?> : </label>
                        <span style="color: red; font-weight: bold;"><?php
                            if ($info) {
                                echo $info->getFullName();
                            }
                            ?></span>
                    </div>
                </div>

                <div class="form-group">
                    <div class="col-sm-12">
                        <label><?php echo $view['translator']->trans("Total Files"); ?> : </label>
                        <span style="color: red; font-weight: bold;"><?php echo number_format($info->getTotalFile()); ?></span>
                    </div>
                </div>

                <div class="form-group">
                    <div class="col-sm-12">
                        <label><?php echo $view['translator']->trans("Earned"); ?> : </label>
                        <span style="color: red; font-weight: bold;"><?php echo number_format($info->getEarned()); ?></span>
                    </div>
                </div>

                <div class="form-group">
                    <div class="col-sm-12">
                        <label><?php echo $view['translator']->trans("Saled"); ?> : </label>
                        <span style="color: red; font-weight: bold;"><?php echo number_format($info->getSaled()); ?></span>
                    </div>
                </div>

                <div class="form-group">
                    <div class="col-sm-12">
                        <label><?php echo $view['translator']->trans("Join On"); ?> : </label>
                        <span style="color: red; font-weight: bold;"><?php echo $info->getCreatedAt()->format("d/m/Y H:i:s"); ?></span>
                        <hr>
                    </div>
                </div>

                <div class="form-group">

                    <span class="fileinput-button coverSpan" <?php echo ($info->getAvatar()) ? "style='background-image: url(" . $info->getCover() . ");'" : "" ?>>
                        <span class="dblock mt35">
                            <i class="faAniProfile fa fa-cloud-upload"></i>
                            <span><?php echo $view['translator']->trans("Upload profile page cover"); ?></span>
                        </span>
                        <span class="dblock fnt13"><?php echo $view['translator']->trans("(Size 1920x200px PNG)"); ?></span>
                        <input class="fileuploadCover" type="file" name="files[]" multiple>
                    </span>

                </div>
                <div class="form-group">
                    <div class="col-sm-12">
                        <div class="col-sm-3 text-center">
                            <span class="fileinput-button avatarSpan mt22" <?php echo ($info->getAvatar()) ? "style='background-image: url(" . $info->getAvatar() . ");'" : "" ?>>
                                <span class="dblock mt30">
                                    <i class="faAniProfile fa fa-cloud-upload fa-3x"></i>
                                </span>
                                <span class="dblock fnt13"><?php echo $view['translator']->trans("114x114px PNG"); ?></span>
                                <input class="fileuploadCover" type="file" name="files[]" multiple>
                            </span>
                        </div>
                        <div class="col-sm-9">
                            <div class="form-group">
                                <div class="col-sm-12">
                                    <label><?php echo $view['translator']->trans("Bio"); ?></label>
                                    <input type="text" autocomplete="off" class="form-control font14" id="bio" name="bio" placeholder="<?php echo $view['translator']->trans("Bio"); ?>" maxlength="150" value="<?php
                                    echo $info->getBio();
                                    ?>">
                                </div>
                            </div>
                            <div class="form-group">
                                <div class="col-sm-12">
                                    <label><?php echo $view['translator']->trans("Website"); ?></label>
                                    <div class="input-group">
                                        <span class="input-group-addon" id="basic-addon2"><i class="fa fa-globe"></i></span>
                                        <input type="text" autocomplete="off" class="form-control font14" id="homepage" aria-describedby="basic-addon2" maxlength="50" name="homepage" placeholder="<?php echo $view['translator']->trans("Website"); ?>" value="<?php
                                        echo $info->getHomepage();
                                        ?>">
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <hr>
                <div class="form-group">
                    <div class="col-sm-12">
                        <label><?php echo $view['translator']->trans("UserName"); ?></label>
                        <div class="input-group">
                            <span class="input-group-addon" id="basic-addon10"><?php echo $view['router']->generate('_homepage', array(), true); ?></span>
                            <input aria-describedby="basic-addon10" type="text" disabled class="form-control font14 disabled" placeholder="<?php echo $view['translator']->trans("UserName"); ?>" value="<?php
                            echo $info->getUsername();
                            ?>">
                        </div>
                    </div>
                </div>
                <div class="form-group">
                    <div class="col-sm-12">
                        <label><?php echo $view['translator']->trans("Name"); ?></label>
                        <input type="text" autocomplete="off" class="form-control font14" id="name" name="name" maxlength="50" required placeholder="<?php echo $view['translator']->trans("Name"); ?>" value="<?php
                        echo $info->getFullName();
                        ?>">
                    </div>
                </div>
                <hr>
                <div class="form-group">
                    <div class="col-sm-12">
                        <label><?php echo $view['translator']->trans("Address"); ?></label>
                        <input type="text" autocomplete="off" class="form-control font14" id="add" maxlength="200" name="add" placeholder="<?php echo $view['translator']->trans("Address"); ?>" value="<?php
                        echo $info->getAdd1();
                        ?>">
                    </div>
                </div>
                <div class="form-group">
                    <div class="col-sm-12">
                        <label><?php echo $view['translator']->trans("City"); ?></label>
                        <input type="text" autocomplete="off" class="form-control font14" id="city" maxlength="30" name="city" placeholder="<?php echo $view['translator']->trans("City"); ?>" value="<?php
                        echo $info->getCity();
                        ?>">
                    </div>
                </div>
                <div class="form-group">
                    <div class="col-sm-12">
                        <label><?php echo $view['translator']->trans("Country"); ?></label>
                        <input type="text" autocomplete="off" class="form-control font14" id="country" maxlength="30" name="country" placeholder="<?php echo $view['translator']->trans("Country"); ?>" value="<?php
                        echo $info->getCountry();
                        ?>">
                    </div>
                </div>
                <hr>
                <div class="form-group">
                    <div class="col-sm-12">
                        <label><?php echo $view['translator']->trans("Facebook"); ?></label>
                        <div class="input-group">
                            <span class="input-group-addon" id="basic-addon0"><i class="fa fa-facebook"></i></span>
                            <input type="text" autocomplete="off" class="form-control font14" id="facebook" aria-describedby="basic-addon0" maxlength="50" name="facebook" placeholder="<?php echo $view['translator']->trans("Facebook"); ?>" value="<?php
                            echo $info->getFacebook();
                            ?>">
                        </div>
                    </div>
                </div>
                <div class="form-group">
                    <div class="col-sm-12">
                        <label><?php echo $view['translator']->trans("Twitter"); ?></label>
                        <div class="input-group">
                            <span class="input-group-addon" id="basic-addon1"><i class="fa fa-twitter"></i></span>
                            <input type="text" autocomplete="off" class="form-control font14" id="twitter" aria-describedby="basic-addon1" maxlength="50" name="twitter" placeholder="<?php echo $view['translator']->trans("Twitter"); ?>" value="<?php
                            echo $info->getTwitter();
                            ?>">
                        </div>
                    </div>
                </div>
                <div class="form-group">
                    <div class="col-sm-12">
                        <label><?php echo $view['translator']->trans("Email Paypal"); ?></label>
                        <div class="alert alert-warning"><?php echo $view['translator']->trans("After each purchase payment will be sent instantly to this PayPal account."); ?></div>
                        <div class="input-group">
                            <span class="input-group-addon" id="basic-addon0"><i class="fa fa-paypal"></i></span>
                            <input type="text" autocomplete="off" class="form-control font14" id="paypal" aria-describedby="basic-addon0" maxlength="80" name="paypal" placeholder="<?php echo $view['translator']->trans("Paypal"); ?>" value="<?php
                            echo $info->getEmailPaypal();
                            ?>">
                        </div>
                    </div>
                </div>
                <div class="col-sm-12">
                    <div class="form-group">
                        <label><?php echo $view['translator']->trans("Email Template Subject"); ?></label>
                        <input maxlength="50" required="" autocomplete="off" type="text" class="form-control text-center text-bold" id="subject" name="subject" placeholder="" value="<?php
                        echo $info->getEmailSubject();
                        ?>">
                    </div>
                </div>
                <div class="col-sm-12">
                    <div class="form-group">
                        <label><?php echo $view['translator']->trans("Email Template Content"); ?></label>
                        <textarea class="form-control text-center" id="detail" name="detail" rows="10"><?php
                            echo $info->getEmailContent();
                            ?></textarea>
                    </div>
                </div>


                <div class="form-group">
                    <div class="col-sm-12">
                        <label><?php echo $view['translator']->trans("Admin"); ?></label>
                        <div class="radio">
                            <label>
                                <input type="radio" name="isAdmin" value="0" <?php
                                if ($info && $info->getSupper() == 0) {
                                    echo 'checked';
                                }
                                ?>><?php echo $view['translator']->trans("No"); ?>
                            </label>
                        </div>
                        <div class="radio">
                            <label>
                                <input type="radio" name="isAdmin" value="1" <?php
                                if ($info && $info->getSupper() == 1) {
                                    echo 'checked';
                                }
                                if (!$info) {
                                    echo "checked";
                                }
                                ?>><?php echo $view['translator']->trans("Yes"); ?>
                            </label>
                        </div>
                    </div>
                </div>

                <div class="form-group">
                    <div class="col-sm-12">
                        <label><?php echo $view['translator']->trans('Change password'); ?></label>
                        <input autocomplete="off" type="password" class="form-control" id="password" name="password" placeholder="<?php echo $view['translator']->trans('Blank if not change'); ?>">
                    </div>
                </div>
            </div>
            <div class="panel-footer bg-white">
                <button type="submit" class="btn btn-danger btn-lg font14"><?php echo $view['translator']->trans("Update"); ?></button>
            </div>
        </div>
    </form>
</div>