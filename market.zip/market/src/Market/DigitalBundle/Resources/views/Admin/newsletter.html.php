<?php
$view->extend('MarketDigitalBundle::layout_admin.html.php');
?>
<div class="col-md-9">
    <?php if ($error == 2) { ?>
        <div class="alert alert-success alert-dismissable">
            <button type="button" class="close" data-dismiss="alert">×</button>
            <?php echo $view['translator']->trans('Successfully!'); ?>
        </div>
    <?php } ?>
    <?php if ($error == 1) { ?>
        <div class="alert alert-danger alert-dismissable">
            <button type="button" class="close" data-dismiss="alert">×</button>
            <?php echo $view['translator']->trans("Error! Please try again."); ?>
        </div>
    <?php } ?>

    <form class="form-horizontal" method="POST" autocomplete="off" action="">
        <div class="panel panel-blue">
            <div class="panel-heading">
                <h2 class="panel-title"><?php echo $view['translator']->trans('Create Newsletter'); ?></h2>
            </div>
            <div class="panel-body">
                <div class="form-group">
                    <div class="col-sm-12">
                        <label><?php echo $view['translator']->trans("Title"); ?></label>
                        <input class="form-control" placeholder="<?php echo $view['translator']->trans("Title"); ?>" id="title" name="title" type="text" autofocus="" required>
                    </div>
                </div>

                <div class="form-group">
                    <div class="col-sm-12">
                        <label><?php echo $view['translator']->trans("Description"); ?></label>
                        <textarea class="summernote" type="text" id="details" name="details"></textarea>
                    </div>
                </div>
            </div>
            <div class="panel-footer bg-white">
                <button type="submit" class="btn blue btn-lg font14"><?php echo $view['translator']->trans("Submit"); ?></button>
            </div>
        </div>
    </form>
</div>