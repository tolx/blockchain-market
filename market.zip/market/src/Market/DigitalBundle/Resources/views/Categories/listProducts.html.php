<?php
$view->extend('MarketDigitalBundle::layout.html.php');
?>
<div id="join" class="mt50 bg-blue">
    <div class="container">
        <div class="row">
            <h2>
                <?php echo $cat->getTitle(); ?>
            </h2>
        </div>
    </div>
</div>
<div id="main">
    <div class="container">
        <?php if ($list) { ?>
            <div class="row">
                <?php
                foreach ($list as $key => $value) {
                    $title = $value->getTitle();
                    $userName = $value->getUsers()->getFullName();
                    $url = $view['router']->generate('_view_products', array('id' => $value->getId(), 'title' => Market\DigitalBundle\System::_reString($title)), true);
                    ?>
                    <div class="col-md-3">
                        <div class="thumbnail">
                            <a href="<?php echo $url; ?>" alt="<?php echo $title; ?>" title="<?php echo $title; ?>">
                                <img alt="<?php echo $title; ?>" title="<?php echo $title; ?>" src="<?php echo $view->escape('/uploads/items/'); ?><?php echo $value->getImage(); ?>">
                            </a>
                            <div class="caption">
                                <div class="title-product">
                                    <a href="<?php echo $url; ?>" alt="<?php echo $title; ?>" title="<?php echo $title; ?>">
                                        <h5 class="text-detail">
                                            <?php echo Market\DigitalBundle\System::getSomeWords($title, 12); ?>
                                        </h5>
                                    </a>
                                </div>

                                <div class="media">
                                    <a href="<?php echo $view['router']->generate('_view_author', array('title' => $value->getUsers()->getUsername()), true); ?>" class="pull-left" alt="<?php echo $title; ?>" title="<?php echo $title; ?>">
                                        <img alt="<?php echo $userName; ?>" title="<?php echo $userName; ?>" src="<?php echo $value->getUsers()->getAvatar(); ?>" class="media-object img-circle avatar">
                                    </a>
                                    <div class="media-body">
                                        <a href="<?php echo $view['router']->generate('_view_author', array('title' => $value->getUsers()->getUsername()), true); ?>" alt="<?php echo $userName; ?>" title="<?php echo $userName; ?>"><?php echo $userName; ?></a>
                                    </div>
                                </div>
                                <hr>
                                <div class="price-product">
                                    <div class="left column">
                                        <div class="price">
                                            <span class="discount-price">
                                                <?php echo ($value->getPrice() > 0) ? "$" . number_format($value->getPrice()) : $view['translator']->trans("FREE"); ?>
                                            </span>
                                        </div>
                                    </div>
                                    <div class="right column">
                                        <a class="btn btn-buy-gray" href="<?php echo $url; ?>"><i class="fa fa-cart-plus"></i> <?php echo $view['translator']->trans("Buy now"); ?></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php
                }
                ?>
            </div>
            <div class="col-lg-12">
                <div class="row">
                    <?php
                    if ($page["NextPage"] > 1):
                        $urlNext = $view['router']->generate('_view_categories', array('id' => $cat->getId(), 'title' => Market\DigitalBundle\System::_reString($cat->getTitle())), true);
                        ?>
                        <ul class="pagination">
                            <?php if ($page["PreviousPage"] != $page["Page"]): ?>
                                <li class="prev">
                                    <a href="<?php echo $urlNext . '?p=' . $page["PreviousPage"]; ?>"><span class="glyphicon glyphicon-chevron-left"></span>&nbsp;<?php echo $view['translator']->trans("Prew"); ?></a>
                                </li>
                            <?php endif; ?>
                            <li class="active"><a><?php echo $page["Page"]; ?></a></li>
                            <?php if ($page["LastPage"] > $page["Page"]): ?>
                                <li class="next"><a href="<?php echo $urlNext . '?p=' . $page["NextPage"]; ?>"><?php echo $view['translator']->trans("Next"); ?>&nbsp;<span class="glyphicon glyphicon-chevron-right"></span></a></li>
                                    <?php endif; ?>
                        </ul>
                    <?php endif; ?>
                </div>
            </div>
            <?php
        }
        else {
            echo "<center>" . $view['translator']->trans("No Data.") . "</center>";
        }
        ?>
    </div>
</div>