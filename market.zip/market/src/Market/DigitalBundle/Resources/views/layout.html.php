<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <title><?php $view['slots']->output('title', $view['translator']->trans("Veri Print") . " - " . $view['translator']->trans("Veri Print")) ?></title>
        <meta name="title" content="<?php $view['slots']->output('title', $view['translator']->trans("Print Vert") . " - " . $view['translator']->trans("Print Vert")) ?>" />
        <meta name="description" content="<?php $view['slots']->output('description', $view['translator']->trans("Buy and sell 3D models for 3D printers securely utilizing the block chain.") . " | " . $view['translator']->trans("Print Vert")) ?>" />
        <meta name="keywords" content="<?php $view['slots']->output('keywords', $view['translator']->trans("Printvert.Com") . ", 3D printer " . $view['translator']->trans("3D printers")) ?>" />
        <meta name="author" content="<?php echo $view['translator']->trans("Veri Print"); ?>" />
        <meta name="robots" content="index,follow" />
        <meta name="email" content="" />
        <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
        <link rel="shortcut icon" href="<?php echo $view['assets']->getUrl('/assetic/'); ?>images/favicon.ico" type="image/x-icon" />
        <link rel="apple-touch-icon-precomposed" sizes="144x144" href="<?php echo $view['assets']->getUrl('/assetic/'); ?>images/favico-144.png">
        <link rel="apple-touch-icon-precomposed" sizes="114x114" href="<?php echo $view['assets']->getUrl('/assetic/'); ?>images/favico-114.png">
        <link rel="apple-touch-icon-precomposed" sizes="72x72" href="<?php echo $view['assets']->getUrl('/assetic/'); ?>images/favico-72.png">
        <link rel="apple-touch-icon-precomposed" href="<?php echo $view['assets']->getUrl('/assetic/'); ?>images/favico-57.png">
        <!--[if lt IE 9]>
          <script src="<?php echo $view['assets']->getUrl('/assetic/'); ?>js/html5shiv.js"></script>
          <script src="<?php echo $view['assets']->getUrl('/assetic/'); ?>js/respond.min.js"></script>
        <![endif]-->
        <script type="text/javascript" src="<?php echo $view['assets']->getUrl('/assetic/'); ?>js/jquery.min.js"></script>
        <script type="text/javascript" src="<?php echo $view['assets']->getUrl('/assetic/'); ?>js/bootstrap.js"></script>
        <link rel="stylesheet" href="<?php echo $view['assets']->getUrl('/assetic/'); ?>css/bootstrap.css">
        <link rel="stylesheet" href="<?php echo $view['assets']->getUrl('/assetic/'); ?>css/color.css">
        <link rel="stylesheet" href="<?php echo $view['assets']->getUrl('/assetic/'); ?>css/font-awesome.css">
        <link rel="stylesheet" href="<?php echo $view['assets']->getUrl('/assetic/'); ?>css/animate.css">
        <link rel="stylesheet" href="<?php echo $view['assets']->getUrl('/assetic/'); ?>css/summernote.css">
    </head>
    <body>
        <?php /*
          <div id="preloader">
          <div class="loader">
          <span></span>
          <span></span>
          <span></span>
          <span></span>
          </div>
          </div>
         * 
         */
        ?>
        <?php
        echo $view['actions']->render(
                $view['router']->generate('menu', array(), true)
        );
        ?>
        <div class="modal fade" id="systemModal" tabindex="-1" role="dialog" aria-labelledby="systemModalLabel">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-body">
                        <div style="text-align: center; padding: 20px 0px;">
                            <img src="<?php echo $view->escape('/assetic/images/'); ?>error.jpg">
                        </div>
                        <h4 style="text-align: center;" id="systemModalText"></h4>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-default" data-dismiss="modal"><?php echo $view['translator']->trans("Close"); ?></button>
                    </div>
                </div>
            </div>
        </div>
        <?php $view['slots']->output('_content'); ?>
        <?php
        echo $view['actions']->render(
                $view['router']->generate('_footer', array(), true)
        );
        ?>
        <div id="footer">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <p>
                            <?php
                            /*
                              <a class="item" href="<?php echo $view['router']->generate('_view_system', array('title' => "sell"), true); ?>">
                              <?php echo $view['translator']->trans("Become a seller"); ?>
                              </a>
                             */
                            ?>
                            <a class="item" href="<?php echo $view['router']->generate('_view_system', array('title' => "about"), true); ?>">
                                <?php echo $view['translator']->trans("About"); ?>
                            </a>
                            <a class="item" href="<?php echo $view['router']->generate('_view_system', array('title' => "terms"), true); ?>">
                                <?php echo $view['translator']->trans("Terms"); ?>
                            </a>
                            <a class="item" href="<?php echo $view['router']->generate('_view_system', array('title' => "privacy"), true); ?>">
                                <?php echo $view['translator']->trans("Privacy policy"); ?>
                            </a>
                            <a class="item" href="https://www.facebook.com/<?php echo \Market\DigitalBundle\MarketDigitalBundle::$fb_acc; ?>" target="_blank">
                                <?php echo $view['translator']->trans("Facebook"); ?>
                            </a>
                            <a class="item" href="https://twitter.com/<?php echo \Market\DigitalBundle\MarketDigitalBundle::$tw_acc; ?>" target="_blank">
                                <?php echo $view['translator']->trans("Twitter"); ?>
                            </a>
                        </p>
                        <p class="footer-copyright">
                            <span class="item">
                                <?php echo $view['translator']->trans("Copyright © 2018."); ?>
                            </span>
                        </p>

                        <div class="scrollLanguage" data-toggle="tooltip" data-placement="top" title="<?php echo $view['translator']->trans("Language"); ?>">
                            <a type="padding-left: 5px;" href="<?php echo $view['router']->generate('_homepage', array(), true); ?>?lang=en">
                                <?php echo $view['translator']->trans("EN"); ?>
                            </a>
                            <span>|</span>
                            <a type="" href="<?php echo $view['router']->generate('_homepage', array(), true); ?>?lang=vi">
                                <?php echo $view['translator']->trans("VI"); ?>
                            </a>
                        </div>

                    </div>
                </div>
            </div>
        </div>
        <div id="fb-root"></div>
        <script>
            window.fbAsyncInit = function () {
                FB.init({
                    appId: '1628780407400346',
                    xfbml: true,
                    version: 'v2.4'
                });
            };
            (function (d, s, id) {
                var js, fjs = d.getElementsByTagName(s)[0];
                if (d.getElementById(id)) {
                    return;
                }
                js = d.createElement(s);
                js.id = id;
                js.src = "//connect.facebook.net/en_US/sdk.js";
                fjs.parentNode.insertBefore(js, fjs);
            }(document, 'script', 'facebook-jssdk'));
        </script>
        <script>!function (d, s, id) {
                var js, fjs = d.getElementsByTagName(s)[0], p = /^http:/.test(d.location) ? 'http' : 'https';
                if (!d.getElementById(id)) {
                    js = d.createElement(s);
                    js.id = id;
                    js.src = p + '://platform.twitter.com/widgets.js';
                    fjs.parentNode.insertBefore(js, fjs);
                }
            }(document, 'script', 'twitter-wjs');</script>
        <!-- Please call pinit.js only once per page -->
        <script type="text/javascript" async defer src="//assets.pinterest.com/js/pinit.js"></script>
        <a class="scrollup" href="javascript:" data-toggle="tooltip" data-placement="top" title="<?php echo $view['translator']->trans("Scroll To Top"); ?>"><i class="fa fa-chevron-up fa-2x"></i></a>
        <script type="text/javascript" src="<?php echo $view['assets']->getUrl('/assetic/'); ?>js/main.js"></script>
        <script type="text/javascript" src="<?php echo $view['assets']->getUrl('/assetic/'); ?>js/summernote.js"></script>
        <script type="text/javascript" src="<?php echo $view['assets']->getUrl('/assetic/'); ?>js/wysiwyg.js"></script>
    </body>
</html>
