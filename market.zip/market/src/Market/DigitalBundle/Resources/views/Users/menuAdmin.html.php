<div class="col-md-3">
    <div class="list-group">
        
        <a class="list-group-item active"><?php echo $view['translator']->trans('Helps'); ?></a>
        <a href="<?php echo $view['router']->generate('_admin_help', array(), true); ?>" class="list-group-item <?php if ($userMenu == "_admin_help") { ?>on-select<?php } ?>"><?php echo $view['translator']->trans('List Help'); ?></a>
        <a href="<?php echo $view['router']->generate('_admin_add_help', array(), true); ?>" class="list-group-item <?php if ($userMenu == "_admin_add_help") { ?>on-select<?php } ?>"><?php echo $view['translator']->trans('New Help'); ?></a>

        
        <a class="list-group-item active"><?php echo $view['translator']->trans('Categories'); ?></a>
        <a href="<?php echo $view['router']->generate('_admin_categories', array(), true); ?>" class="list-group-item <?php if ($userMenu == "_admin_categories") { ?>on-select<?php } ?>"><?php echo $view['translator']->trans('List Categories'); ?></a>
        <a href="<?php echo $view['router']->generate('_admin_add_categories', array(), true); ?>" class="list-group-item <?php if ($userMenu == "_admin_add_categories") { ?>on-select<?php } ?>"><?php echo $view['translator']->trans('New Category'); ?></a>


        <a class="list-group-item active"><?php echo $view['translator']->trans('Products'); ?></a>
        <a href="<?php echo $view['router']->generate('_admin_products', array(), true); ?>" class="list-group-item <?php if ($userMenu == "_admin_products") { ?>on-select<?php } ?>"><?php echo $view['translator']->trans('List Products'); ?></a>
        
        
        
        <a class="list-group-item active"><?php echo $view['translator']->trans('Users'); ?></a>
        <a href="<?php echo $view['router']->generate('_admin_users', array(), true); ?>" class="list-group-item <?php if ($userMenu == "_admin_users") { ?>on-select<?php } ?>"><?php echo $view['translator']->trans('List Users'); ?></a>
        
        
        <a class="list-group-item active"><?php echo $view['translator']->trans('NewsLetter'); ?></a>
        <a href="<?php echo $view['router']->generate('newsletter', array(), true); ?>" class="list-group-item <?php if ($userMenu == "admin_newsletter") { ?>on-select<?php } ?>"><?php echo $view['translator']->trans('Create NewsLetter'); ?></a>

        
        
    </div>
</div>