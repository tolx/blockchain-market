<?php
$view->extend('MarketDigitalBundle::layout_user.html.php');
?>
<div class="col-md-9">
    <form class="form-horizontal" method="POST" autocomplete="off" action="">
        <div class="panel panel-blue">
            <div class="panel-heading">
                <h2 class="panel-title"><?php echo $view['translator']->trans('E-mail Template'); ?></h2>
            </div>
            <div class="panel-body">
                <div class="col-sm-12">
                    <div class="form-group">
                        <input maxlength="50" required="" autocomplete="off" type="text" class="form-control text-center text-bold" id="subject" name="subject" placeholder="" value="<?php
                        echo $info->getEmailSubject();
                        ?>">
                    </div>
                </div>
                <div class="col-sm-12">
                    <div class="form-group">
                        <textarea class="form-control text-center" id="detail" name="detail" rows="10"><?php
                            echo $info->getEmailContent();
                            ?></textarea>
                    </div>
                </div>
            </div>
            <div class="panel-footer bg-white">
                <button type="submit" class="btn btn-danger btn-lg font14"><?php echo $view['translator']->trans("Update"); ?></button>
            </div>
        </div>
    </form>
</div>