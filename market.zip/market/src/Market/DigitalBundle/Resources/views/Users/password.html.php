<?php
$view->extend('MarketDigitalBundle::layout_user.html.php');
?>
<div class="col-md-9">
    <form role="form" method="POST" action="">
        <div class="panel panel-blue">
            <div class="panel-heading">
                <h2 class="panel-title"><?php echo $view['translator']->trans('Change Password'); ?></h2>
            </div>
            <div class="panel-body">
                <?php if ($error == 1) { ?>
                    <div class="alert alert-success alert-dismissable">
                        <button type="button" class="close" data-dismiss="alert">×</button>
                        <?php echo $view['translator']->trans('Change Password Success!'); ?>
                    </div>
                <?php } ?>
                <?php if ($error == 2) { ?>
                    <div class="alert alert-danger alert-dismissable">
                        <button type="button" class="close" data-dismiss="alert">×</button>
                        <?php echo $view['translator']->trans("Can't Change Password!"); ?>
                    </div>
                <?php } ?>
                <div class="form-group">
                    <label><?php echo $view['translator']->trans('Current password'); ?></label>
                    <input required autocomplete="off" type="password" class="form-control" id="oldpass" name="oldpass" placeholder="<?php echo $view['translator']->trans('Current password'); ?>">
                </div>
                <div class="form-group">
                    <label><?php echo $view['translator']->trans('New password'); ?></label>
                    <input required autocomplete="off" type="password" class="form-control" id="newpass" name="newpass" placeholder="<?php echo $view['translator']->trans('New password'); ?>">
                </div>
                <div class="form-group">
                    <label><?php echo $view['translator']->trans('Confirm new password'); ?></label>
                    <input required autocomplete="off" type="password" class="form-control" id="renewpass" name="renewpass" placeholder="<?php echo $view['translator']->trans('Confirm new password'); ?>">
                </div>
            </div>
            <div class="panel-footer bg-white">
                <button type="submit" class="btn blue"><?php echo $view['translator']->trans('Update password'); ?></button>
            </div>
        </div>
    </form>
</div>