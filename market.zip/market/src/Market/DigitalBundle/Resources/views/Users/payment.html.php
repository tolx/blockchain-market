<?php
$view->extend('MarketDigitalBundle::layout_user.html.php');
$userMenu = '';
?>
<div class="col-md-9">
    <form class="form-horizontal" method="POST" autocomplete="off" action="">
        <div class="panel panel-blue">
            <div class="panel-heading">
                <h2 class="panel-title"><?php echo $view['translator']->trans('Payment Option'); ?></h2>
            </div>
            <div class="panel-body">
                <div class="form-group">
                    <div class="col-sm-12">
                        <div class="alert alert-warning"><?php echo $view['translator']->trans("After each purchase payment will be sent instantly to this PayPal account."); ?></div>
                        <div class="input-group">
                            <span class="input-group-addon" id="basic-addon0"><i class="fa fa-paypal"></i></span>
                            <input type="text" autocomplete="off" class="form-control font14" id="paypal" aria-describedby="basic-addon0" maxlength="80" name="paypal" placeholder="<?php echo $view['translator']->trans("Paypal"); ?>" value="<?php
                            echo $info->getEmailPaypal();
                            ?>">
                        </div>
                    </div>
                </div>
            </div>
            <div class="panel-footer bg-white">
                <button type="submit" class="btn btn-danger btn-lg font14"><?php echo $view['translator']->trans("Update"); ?></button>
            </div>
        </div>
    </form>
</div>