<div class="col-md-3">
    <div class="list-group">
        <a class="list-group-item active"><?php echo $view['translator']->trans('Account Settings'); ?></a>
        <a href="<?php echo $view['router']->generate('_user', array(), true); ?>" class="list-group-item <?php if($userMenu == "profile"){ ?>on-select<?php } ?>"><?php echo $view['translator']->trans('Profile'); ?></a>
        <a href="<?php echo $view['router']->generate('_password', array(), true); ?>" class="list-group-item <?php if($userMenu == "password"){ ?>on-select<?php } ?>"><?php echo $view['translator']->trans('Change Password'); ?></a>
        
        
        <a class="list-group-item active"><?php echo $view['translator']->trans('Seller Settings'); ?></a>
        <a href="<?php echo $view['router']->generate('_user_payment', array(), true); ?>" class="list-group-item <?php if($userMenu == "_user_payment"){ ?>on-select<?php } ?>"><?php echo $view['translator']->trans('Payment options'); ?></a>
        <a href="<?php echo $view['router']->generate('_user_email', array(), true); ?>" class="list-group-item <?php if($userMenu == "_user_email"){ ?>on-select<?php } ?>"><?php echo $view['translator']->trans('E-mail template'); ?></a>
        
        
        <a class="list-group-item active"><?php echo $view['translator']->trans('Market States'); ?></a>
        <a href="<?php echo $view['router']->generate('_purchases', array(), true); ?>" class="list-group-item <?php if($userMenu == "_purchases"){ ?>on-select<?php } ?>"><?php echo $view['translator']->trans('My purchases'); ?></a>
        <a href="<?php echo $view['router']->generate('_sales', array(), true); ?>" class="list-group-item <?php if($userMenu == "_sales"){ ?>on-select<?php } ?>"><?php echo $view['translator']->trans('My products'); ?></a>
        <a href="<?php echo $view['router']->generate('_upload', array(), true); ?>" class="list-group-item <?php if($userMenu == "_upload"){ ?>on-select<?php } ?>"><?php echo $view['translator']->trans('Upload'); ?></a>
    </div>
</div>