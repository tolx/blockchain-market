<?php

namespace Market\DigitalBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;
use Symfony\Component\DependencyInjection\ContainerInterface;

class MarketDigitalBundle extends Bundle {

    public static $demoMode = 0;
    private static $containerInstance = null;
    public static $fb_app = null;
    public static $fb_key = null;
    public static $tw_acc = null;
    public static $fb_acc = null;
    //
    public static $paypal_sanbox = 1; // set = 0 if Live App
    //
    static function emailReceiver() {
        if (self::$paypal_sanbox) {
            $email = "";
        } else {
            $email = "";
        }
        return $email;
    }

    static function sdkConfig() {
        if (self::$paypal_sanbox) {
            return array(
                "mode" => "sandbox",
                "acct1.UserName" => "jb-us-seller_api1.paypal.com",
                "acct1.Password" => "WX4WTU3S8MY44S7F",
                "acct1.Signature" => "AFcWxV21C7fd0v3bYYYRCpSSRl31A7yDhhsPUU2XhtMoZXsWHFxu-RWy",
                "acct1.AppId" => "APP-80W284485P519543T"
            );
        } else {
            return array(
                "mode" => "live",
                "acct1.UserName" => "",
                "acct1.Password" => "",
                "acct1.Signature" => "",
                "acct1.AppId" => ""
            );
        }
    }

    static function RedirectToPayPal($paykey) {
        if (self::$paypal_sanbox) {
            $PAYPAL_URL = "https://www.sandbox.paypal.com/cgi-bin/webscr?cmd=_ap-payment&paykey=";
        } else {
            $PAYPAL_URL = "https://www.paypal.com/cgi-bin/webscr?cmd=_ap-payment&paykey=";
        }
        return $PAYPAL_URL . $paykey;
    }

    public function setContainer(ContainerInterface $container = null) {
        parent::setContainer($container);
        self::$containerInstance = $container;
    }

    public static function getContainer() {
        return self::$containerInstance;
    }

    public static function getDoctrine() {
        return self::getContainer()->get('doctrine');
    }

    public static function getManager() {
        return self::getDoctrine()->getManager();
    }

    public static function genString($len = 1) {
        $letter = substr(str_shuffle(str_repeat('ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz', 5)), 0, $len);

        return $letter;
    }

}
