/**************************Scroll Up*****************************/
$(window).scroll(function () {
    if ($(this).scrollTop() > 50) {
        $('.scrollup').fadeIn();
    } else {
        $('.scrollup').fadeOut();
    }
});
$('.scrollup').click(function () {
    $("html, body").animate({scrollTop: 0}, 600);
    return false;
});
/****************************************/
$('[data-toggle="tooltip"]').tooltip();
/****************************************/
var canClick = 1;
$(".buyNow").click(function () {
    if (canClick == 0) {
        return;
    }
    $.ajax({
        url: $(".buyNow").attr("data-bind"),
        method: "POST",
        beforeSend: function (xhr) {
            $('.faAni').removeClass("fa-cart-plus").addClass("fa-spinner").addClass("fa-spin");
            canClick = 0;
            $(".buyNow").addClass("disabled");
        }
    }).done(function (data) {
        data = jQuery.parseJSON(data);
        if (data.status) {
            $(location).attr('href', data.url);
        } else {
            $('#systemModalText').html(data.msg);
            $('#systemModal').modal('show');
            canClick = 1;
            $(".buyNow").removeClass("disabled");
            $('.faAni').addClass("fa-cart-plus").removeClass("fa-spinner").removeClass("fa-spin");
        }
    });
});